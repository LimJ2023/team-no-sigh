package shopingmall;

public abstract class Member{
	
	protected int memberNum;
	protected String name;
	protected String phone;
	protected int balance;
	protected int bonusPoint;
	protected float bonusRatio;
	
	public Member(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}
}
