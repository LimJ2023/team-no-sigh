package shopingmall;

public class item {
	String name;
	int price;
	public item(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
	
	
}
