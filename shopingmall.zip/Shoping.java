package shopingmall;

public interface Shoping {
	
	//쇼핑 관련 메서드
	void shoppingBasket(item m);
	void pay(int balance);
}
