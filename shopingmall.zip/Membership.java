package shopingmall;

public interface Membership {
	
	//회원 번호는 1000번부터 시작
	int MEMBER_ID = 1000;
	
	//회원관련 메서드
	void createAccount();
	void showMemberInfo();
	void changeMemberInfo();
}
