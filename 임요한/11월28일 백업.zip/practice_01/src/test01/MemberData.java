package test01;

public class MemberData implements ConnectData{
	
		//회원 번호는 1000번부터 시작
		public static int memberId = 1000;
		
		Member[] members;
		Member member;

		@Override
		public void getData(Member mem) { // 이 클래스에 있는 정보를 매개변수에 전달
			mem = member;
			
		}

		@Override
		public void setMember(Member mem) { // 이 클래스에 매개변수로 받은 정보를 저장
			member = mem;
		}
		
		public MemberData() {
			members = new Member[10];
		}
		
		
}
