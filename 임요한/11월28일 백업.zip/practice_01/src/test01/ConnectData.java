package test01;

public interface ConnectData {
	
	
	void getData(Member mem);
	void setMember(Member mem);
}
