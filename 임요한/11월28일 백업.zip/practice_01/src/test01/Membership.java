package test01;

import java.util.Scanner;

public interface Membership {
	
	
	
	//회원관련 메서드
	Member createAccount(Scanner sc);
	void showMemberInfo(Scanner sc);
	Member changeMemberPhone(Scanner sc);
}
