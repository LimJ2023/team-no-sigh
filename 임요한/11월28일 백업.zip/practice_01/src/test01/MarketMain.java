package test01;

import java.util.Scanner;

public class MarketMain {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		MemberData memData = new MemberData();
		MemManagement memberManage = new MemManagement();

		System.out.println("1. 회원 관리 2. 매장 관리 3. ~~~~");
		int selectMenu = scan.nextInt();
		scan.nextLine();
		if (selectMenu == 1) {
			boolean run = true;

			while (run) {

				System.out.println("회원 관리");
				System.out.println("1. 회원 가입 2. 회원 정보 3. 번호 수정 4. 돌아가기");

				selectMenu = scan.nextInt();
				scan.nextLine();

				switch (selectMenu) {
				case 1:
					if (memData.member == null)
						memData.member = memberManage.createAccount(scan);
					else {

						System.out.println("회원가입 완료됨");
						break;
					}

					break;
				case 2:
					memberManage.showMemberInfo(scan);
					break;
				case 3:
					memData.member = memberManage.changeMemberPhone(scan);
					break;
				case 4:
					System.out.println("돌아가기");
					run = false;
					break;
				default:
					break;
				}// switch
			} // while
		} else if (selectMenu == 2) {
			// 구현중
		}
	}// main
}
