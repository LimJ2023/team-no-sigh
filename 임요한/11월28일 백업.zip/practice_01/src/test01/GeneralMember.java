package test01;

public class GeneralMember extends Member{

	public GeneralMember(String name, String phone) {
		super(name, phone);
		this.bonusPoint = 3000;
	}

	
	
	

}
