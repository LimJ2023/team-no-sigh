package shopingmall;

import java.util.Scanner;

public class MemManagement implements Membership{
	
	Member member;
	
	public Member createAccount(Scanner sc) {
		System.out.println("=====회원 가입=====");
		
		System.out.println("회원 이름 입력");
		String name = sc.nextLine();
		
		System.out.println("전화번호 입력");
		String phone = sc.nextLine();
		
		member = new GeneralMember(name, phone);
		
		return member;
	}

	@Override
	public void showMemberInfo(Scanner sc) {
		System.out.println("회원 이름 : " + member.name);
		System.out.println("전화 번호 : " + member.phone);
		System.out.println("포인트 : " + member.bonusPoint);
		System.out.println("잔액  : " + member.balance);
	}

	@Override
	public Member changeMemberPhone(Scanner sc) {
		System.out.println("전화번호 수정");
		String phone =  sc.nextLine();
		member.phone = phone;
		
		return member;
	}

}
