package shopingmall;

public interface ConnectData {
	
	
	Member getData();
	void setMember(Member mem);
}
