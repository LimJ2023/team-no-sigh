package shopingmall;

public class Store {
	
	item[] inventory;
	Member member;
	double totalsale;
	
}
