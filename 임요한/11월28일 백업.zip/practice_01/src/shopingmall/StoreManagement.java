package shopingmall;

import java.util.Scanner;

public class StoreManagement implements ConnectData{
	
	Store store;
	item[] baskets;
	item[] inven;
	
	public StoreManagement() {
		init();
	}
	
	

	public void init() {
		baskets = new item[50];
		store.inventory = new item[50];
		inven = new item[50];
		
		inven[0] = new item("점퍼1",11000);
		inven[1] = new item("점퍼2",12000);
		inven[2] = new item("점퍼3",13000);
		inven[3] = new item("점퍼4",14000);
		inven[4] = new item("점퍼5",15000);
		
		store.inventory = inven;
	}

	public void shoppingBasket(Scanner sc) {
		
		System.out.println("장바구니");
		
	}
	public void pay(int balance) {
		
		int sum = calcPrice();
		store.member.balance -= sum;
	}
	
	public int calcPrice() {
		int sum = 0;
		for (int i = 0; i < baskets.length; i++) {
			sum += baskets[i].price;
		}
		return sum;
	}


	@Override
	public Member getData() {
		return store.member;
		}
	@Override
	public void setMember(Member mem) {
		store.member.name = mem.name;
		store.member.phone = mem.phone;

	}
	
}
