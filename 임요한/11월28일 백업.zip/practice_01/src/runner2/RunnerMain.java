package runner2;

public class RunnerMain {
    public static void main(String[] args) {

        RunnerGame runnerGame = new RunnerGame(50);

        runnerGame.start();
        System.out.println();
        runnerGame.showRunnerInfo();
        
    }
}
