package runner2;

import java.util.Random;

public class RunnerGame {

    Player[] players;
    Player winner;
    int winDistance;
    
    //경기장 선을 구분짓기 위한 변수들
    StringBuffer lineCol;
    StringBuffer lineRow;
    int dis;
    //랜덤 선언
    Random random = new Random();

    public RunnerGame(int winDistance){
        players = new Player[5];
        selRandRunner();
        this.winDistance = winDistance;
    }

    //3가지 러너 타입중 랜덤으로 정해지게 하는 메서드
    void selRandRunner(){

        for (int i = 0; i < players.length; i++) {
            int ran = random.nextInt(3);

            if (ran == 0) {
                players[i] = new SeonIb_Player();
            } else if (ran == 1) {
                players[i] = new SeonHaeng_Player();
            } else if(ran == 2){
                players[i] = new ChuIb_Player();
            }
        }
    }

    public void start(){
        
        //승리지점만큼 경기장 크기를 지정
        lineRow = new StringBuffer();
        lineRow.append("=".repeat(winDistance));

        while (winner == null){

            //러너 명 당 반복문
            for (Player player : players) {

                player.jump(random.nextInt(4));

                lineCol = new StringBuffer();
                //이동거리에 맞춰 목표지점을 고정 (안그럼 세로열이 뒤로 밀려남)
                dis = winDistance - player.getPlayerJump().length();
                //dis가 음수가 되었을 경우 append().repeat() 함수에 오류 발생
                //Math.max()를 이용하여 최소 0 밑의 수는 입력되지 않도록 함
                lineCol.append(" ".repeat(Math.max(0,dis)));
                System.out.println(lineCol + "|");
                
                //두 명이 동시에 도착했을 경우 윗번호가 우선으로 승자가 되는 경우가 있어
                //거리를 비교하는 코드를 추가
                if (player.getDis() >= winDistance) {
                    if (winner == null) {
                        winner = player;
                    }
                    else if (player.getDis() > winner.getDis()) {
                        winner = player;
                    }
                }
            }//for 러너 명 당 반복문
            System.out.println(lineRow);

            
            //쓰레드 일시정지
            try{
                Thread.sleep(600);
            }catch(InterruptedException e){
                e.printStackTrace();
            }

        }//while 게임 반복문

        System.out.println("승자는 " + winner.getPlayerNumber() + "번!");
    }//start

    //러너 목록과 승자를 보여주는 메서드
    public void showRunnerInfo(){
        for (int i = 0; i < players.length; i++) {
            System.out.println((i+1) + "번 " + players[i].runType + "타입" );
        }
        System.out.println();
        System.out.println("승자는 " + winner.getPlayerNumber() + "번 " + winner.runType + "타입");
    }

}
