package runner2;

public abstract class Player {

    private static int playerId = 1; // 플레이어 고유 번호 시작
    protected final int playerNumber; // 부여받은 번호
    protected final StringBuffer playerJump = new StringBuffer(); //스트링 버퍼 이용

    protected int bonusSpeed; // 추가이동거리를 위한 포인트
    protected String runType; // 선행,선입,추입 구분용

    public Player() {
        //고유한 ID 값을 가지며 생성될 때마다 증가해야 합니다.
        playerNumber =  playerId++;
    }

    //주어진 거리만큼 플레이어가 점프하는 메서드
    public void jump(int jumpDistance){

        System.out.print(playerJump);//버퍼만큼 공백이 들어가고

        for (int i = 0; i < jumpDistance; i++) {
            System.out.print("="); // 이동한 거리를 보여줌
            playerJump.append(" "); // 이동거리만큼 버퍼에 추가
        }
        System.out.print(playerNumber + "\uD83C\uDFC3"); // 번호와 아이콘 삽입

    }

    public int getPlayerNumber() {
        return playerNumber;
    }

    public StringBuffer getPlayerJump() {
        return playerJump;
    }

    public int getDis() {
        return getPlayerJump().length();
    }


}
