package runner2;

public class ChuIb_Player extends Player{

    public ChuIb_Player() {
        super();
        bonusSpeed = -18;
        runType = "추입";
    }

    @Override
    public void jump(int jumpDistance) {
        System.out.print(playerJump);
        bonusSpeed++;
        if(bonusSpeed > 0) {
            jumpDistance += 2;
        }
        for (int i = 0; i < jumpDistance; i++) {
            System.out.print("=");
            playerJump.append(" ");
        }
        System.out.print(playerNumber + "\uD83C\uDFC3");
    }
}
