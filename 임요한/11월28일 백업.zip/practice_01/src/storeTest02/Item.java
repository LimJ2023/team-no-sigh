package storeTest02;

public class Item {
	
	//제품명과 가격
	String name;
	int price;
	
	//생성자
	public Item(String name, int price) {
		this.name = name;
		this.price = price;
	}
}
