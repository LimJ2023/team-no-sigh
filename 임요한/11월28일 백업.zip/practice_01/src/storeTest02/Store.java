package storeTest02;


public class Store {

	//재품 배열과 매출 변수
	Item[] items;
	double totalsale;
	int daySales;
	
	public Store() {
		//초기 재고 생성 메서드
		itemsinit();
		//초기 매출액 설정
		totalsale = 2000000;
	}
	
	
	//초기 재고 생성 메서드
	public void itemsinit() {
		
		items = new Item[5];
		items[0] = new Item("신선품", 5000);
		items[1] = new Item("고기", 8000);
		items[2] = new Item("의류", 10000);
		items[3] = new Item("전자제품", 20000);
		items[4] = new Item("가구", 50000);
		
	}
	//재고 목록 출력
	public void showInventory() {
		
		System.out.println("=========재고 목록========");
		
		for (int i = 0; i < items.length; i++) {
			System.out.println( (i + 1) + ". " + items[i].name + ", " + items[i].price + "원" );
		}
	}
	
	//오늘의 매출
	public void showTodaySales() {
		
		for (int i = 0; i < items.length; i++) {
			daySales += items[i].price;
		}
		
		System.out.println("오늘의 매출은 " + daySales + "원 입니다.");
	}
	
	//총 매출
	public void showTotalSale() {
		
		totalsale += daySales;
		System.out.println("총 매출액은 " + totalsale + "입니다.");
	}
}
