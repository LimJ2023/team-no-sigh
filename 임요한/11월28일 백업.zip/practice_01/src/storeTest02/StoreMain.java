package storeTest02;

public class StoreMain {
	public static void main(String[] args) {
		
		Store store1 = new Store();
		
		store1.showInventory();
		System.out.println();
		store1.showTodaySales();
		store1.showTotalSale();
	}
}
