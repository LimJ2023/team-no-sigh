package activity;

import java.util.LinkedList;

public class Schadule {
	
	LinkedList<Active> act;
	
	public Schadule() {
		act = new LinkedList<Active>(); 
	}
	
	public void addActive(String name, int num) {
		act.add(new Active(name, num));
		System.out.println(act.getLast().dateNumber + " 일에 " + act.getLast().name + " 활동 추가");
	}
	
	public void change(int num, Active a) {
		//날짜를 바꾸기
		a.dateNumber = num;
		System.out.println(a.name + " 활동의 날짜를 " + a.dateNumber + "일로 수정");
	}
	
	public void showActives() {
		
		for (int i = 0; i < act.size(); i++) {
			System.out.println(act.get(i));
		}
	}
	
	
}
