package chapter14;

public class Wrapper01 {

	public static void main(String[] args) {

		
		
		// equals()함수등 사용 가능
		Integer num1 = (5); // 박싱
		Integer num2 = (5);
		
		int int1 = num1.intValue(); //언박싱
		int int2 = num2.intValue();
		double int3 = 5;
		System.out.println(int1);
		System.out.println(int2);
		
		System.out.println(num1);
		System.out.println(num2);
		
		Integer result1 = num1+num2;
		System.out.println(result1);
		
		//기본형과 래퍼클래스 비교시 자동 언박싱하여 비교해줌
		System.out.println(num1 == 5);
		//래퍼클래스끼리 비교시 다르지만 toString()이 재정의되어 있음.
		System.out.println(num1 == num2); // true
		System.out.println(num1.equals(num2));
		System.out.println(num1 == int3); // 더블형이 자동형변환
		
		Integer result2 = int1 - int2;
		System.out.println(result2);
	}

}
