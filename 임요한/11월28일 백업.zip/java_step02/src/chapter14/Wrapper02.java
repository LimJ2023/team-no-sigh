package chapter14;

public class Wrapper02 {
	public static void main(String[] args) {
			
		Integer n1 = (100);
		int n2 = 200;
		int total = n1 + n2; // 자동 언박싱
		
		Integer n3 = n2; // 박싱
		System.out.println(total);
		System.out.println(n3);
		
	}
}
