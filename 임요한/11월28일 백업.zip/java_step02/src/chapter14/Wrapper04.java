package chapter14;

public class Wrapper04 {

	public static void main(String[] args) {
		
		Integer obj = 10; //오토박싱
		
		Wrapper04 w = new Wrapper04();
		
		System.out.println(obj.intValue());//언박싱
		
		int value = obj;
		System.out.println(value);
		
		int result = obj + 200; //언박싱
		System.out.println(result);
		
		w.compare(obj);
		double num2 = 100;
		Double num2Wrap = num2;
		Long long1 = 10000l;
		String str = "100";
		int num6 = Integer.parseInt(str);
		
		
		//Integer obj = 200; //오토박싱
		Integer obj_1 = obj;
		Integer obj_2 = obj;
		obj = 50;
				
		int num = 100;
		int num_1 = num;
		int num_2 = num;
			num = 200;
			
		System.out.println(obj_1);
		System.out.println(obj_2);
		System.out.println(num_1);
		System.out.println(num_2);
		
		
	}
	
	public void compare(Number num) {
		int num2 = 10 + (Integer)num;
		System.out.println(num2);
	}
	public void compareInt(int num) {
		int num2 = 10 + (int)num;
		System.out.println(num2);
	}

}
