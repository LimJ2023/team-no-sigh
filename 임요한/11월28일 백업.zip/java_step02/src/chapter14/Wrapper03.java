package chapter14;

public class Wrapper03 {
	public static void main(String[] args) {
		
		Integer obj1 = (100); //빡싱
		Integer obj2 = (200);
		
		Integer obj3 = Integer.valueOf(300);//박싱
		
		//자동 언박싱 후 계산한 뒤 박싱하여 대입
		Integer total1 = obj1 + obj2;
		Integer total2 = obj3 + obj1;
		System.out.println(total1);
		System.out.println(total2);
		
		
		//언박싱  intValue() 메서드 사용
		int val1 = obj1.intValue();
		int val2 = obj2.intValue();
		int val3 = obj3.intValue();
		
		System.out.println(val1);
		System.out.println(val2);
		System.out.println(val3);
		
		//문자열을 받아와 int형으로 파싱가능
		String str1 = "01039207972";
		
		int obj4 = Integer.parseInt(str1);
		
		
		int sum = obj1 + obj4;
		System.out.println(obj4);
		System.out.println(sum);
		
		
		
		
	}
}
