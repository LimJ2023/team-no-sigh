package chapter14;

public class ValueCompareEx {
	//값 비교
	public static void main(String[] args) {
		
		System.out.println("[-128~ 128 초과 값일 경우");
		Integer obj1 = 300;
		Integer obj2 = 300;
		//객체이므로 각각 다른 힙에 존재
		System.out.println("결과 : " + (obj1 == obj2));
		System.out.println("언박싱한 후 결과 : " + 
				(obj1.intValue() == obj2.intValue()));
		
		System.out.println("================");
		//byte 범위값 안일 경우 상수풀에 올라감
		//같은 메모리를 참조함
		System.out.println("-128 ~ 128 범위안 값일 경우");
		Integer obj3 = 100;
		Integer obj4 = 100;
		System.out.println("결과 : " + (obj3 == obj4));
		System.out.println("언박싱한 후 결과 : " + 
				(obj3.intValue() == obj4.intValue()));
		System.out.println(obj3.equals(obj4));
		
	}
	
	
}
