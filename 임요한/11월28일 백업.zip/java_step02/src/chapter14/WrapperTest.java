package chapter14;

public class WrapperTest {
	public static void main(String[] args) {
		Integer a = 5; //자동박싱
		Integer b = 10; //자동박싱
		System.out.println(a + b); //자동 언박싱 후 계산
		
		Integer c = 15; //자동박싱
		int d = c; // 언박싱
		System.out.println(d);
		
		int e = 20;
		Integer f = e; // 박싱
		System.out.println(f);//자동 언박싱
		
		Integer num1 = 25; //자동박싱
		int num2 = num1; // 언박싱
		
		//결과 이유 설명
		Integer x = 50; //자동박싱
		Integer y = 50; //자동박싱
		
		// x,y의 값이 -128 ~ 127 안이므로 상수풀에
		// 자동 캐시해두었던 배열의 같은 메모리를 참조함
		// 결과 : true
		/*
		 * 이렇게 하면 대부분의 일반적인 경우 특히 소형 장치에서 
		 * 과도한 성능 저하를 초래하지 않고 원하는 동작이 수행됩니다. 
		 * 
		 */
		System.out.println(x == y);  
		
	}
}
