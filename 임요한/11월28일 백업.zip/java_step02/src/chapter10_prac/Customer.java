package chapter10_prac;

public class Customer {
	
	protected int cstmrID;
	protected String cstmrName;
	protected String cstmrGrade;
	public double bonusPoint;
	protected double bonusRatio;
	
	public Customer() {
		cstmrGrade = "SILVER";
		bonusRatio = 0.01;
	}

	
	//메서드
	public Customer(int cstmrID, String cstmrName) {
		this.cstmrID = cstmrID;
		this.cstmrName = cstmrName;
		cstmrGrade = "SILVER";
		bonusRatio = 0.01;
	}
	public void showCstmr() {
		System.out.println("=====" + cstmrGrade + "고객=====");
		 System.out.println(cstmrName + "님의 등급은 " + cstmrGrade + "이며 보너스 포인트는 " + 
					bonusPoint + "입니다."); 
	}
	public void showPayInfo(int price) {
		System.out.println(cstmrName + "님이 " + price + "원을 지불하셨습니다.");
	}
	
	//게터 세터
	public int calcPrice(int price) {
		bonusPoint += bonusRatio * price;
		return price;
	}

	public int getCstmrID() {
		return cstmrID;
	}

	public void setCstmrID(int cstmrID) {
		this.cstmrID = cstmrID;
	}

	public String getCstmrName() {
		return cstmrName;
	}

	public void setCstmrName(String cstmrName) {
		this.cstmrName = cstmrName;
	}

	public String getCstmrGrade() {
		return cstmrGrade;
	}

	public void setCstmrGrade(String cstmrGrade) {
		this.cstmrGrade = cstmrGrade;
	}

	public double getBonusPoint() {
		return bonusPoint;
	}

	public void setBonusPoint(double bonusPoint) {
		this.bonusPoint = bonusPoint;
	}

	public double getBonusRatio() {
		return bonusRatio;
	}

	public void setBonusRatio(double bonusRatio) {
		this.bonusRatio = bonusRatio;
	}
	
	
	
	
}
