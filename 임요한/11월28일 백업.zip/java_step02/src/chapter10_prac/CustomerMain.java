package chapter10_prac;

public class CustomerMain {

	public static void main(String[] args) {

		Customer cs1 = new Customer(100, "손님1");
		
		cs1.showCstmr();
		int pay = cs1.calcPrice(10000);
		cs1.showPayInfo(pay);
		
		VIPCustomer vipcs1 = new VIPCustomer(101, "손님2", 10);
		vipcs1.showCstmr();
		int pay2 = vipcs1.calcPrice(10000);
		vipcs1.showPayInfo(pay2);
	}

}
