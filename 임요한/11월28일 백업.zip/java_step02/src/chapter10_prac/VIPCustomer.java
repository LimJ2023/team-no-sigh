package chapter10_prac;

public class VIPCustomer extends Customer{
	
	int agentName;
	double saleRatio;
	int finalPrice;
	
	public VIPCustomer(int cstmrID, String cstmrName, int agentName) {
		super(cstmrID, cstmrName);
		this.agentName = agentName;
		bonusRatio = 0.05;
		saleRatio = 0.1;
	}

	@Override
	public int calcPrice(int price) {
		finalPrice = (price - (int)(price * saleRatio));
		bonusPoint += finalPrice * saleRatio;
		return finalPrice;
	}

	@Override
	public void showCstmr() {
		super.showCstmr();
		System.out.println("에이전트는 " + agentName);
	}

	@Override
	public void showPayInfo(int price) {
		System.out.println(cstmrName + "님이 " + finalPrice + "원을 지불하셨습니다.");
	}
	
}
