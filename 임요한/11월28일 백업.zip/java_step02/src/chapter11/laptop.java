package chapter11;

public abstract class laptop extends Computer{

	@Override
	public void display() {
		System.out.println("노트북 화면을 보여줍니다.");
		
	}
	
}
