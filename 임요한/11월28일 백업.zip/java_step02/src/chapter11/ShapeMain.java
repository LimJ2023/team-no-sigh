package chapter11;

public class ShapeMain {

	public static void main(String[] args) {

		Circle circle = new Circle(5);
		circle.display();
		System.out.println("원의 넓이 : "+ circle.calculateArea());
	}

}
