package chapter11;

public class FileDowndoadServlet extends HttpServlet{

	@Override
	public void service() {
		System.out.println("파일 다운로드 합니다.");
		
	}
	
	
}
