package chapter11;

public class AnimalMain {

	public static void main(String[] args) {

		Animal cat = new Cat();
		cat.sound(); // 구현화 된 추상 메서드
		
		Animal dog = new Dog();
		dog.sound();
		
		System.out.println("===========");
		
		animalSound(new Cat());
		animalSound(new Dog());
	}
	
	public static void animalSound(Animal ani) {
		ani.sound();
	}
	
}
