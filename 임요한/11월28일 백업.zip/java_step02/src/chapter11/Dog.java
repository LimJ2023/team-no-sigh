package chapter11;

public class Dog extends Animal{
	
	public Dog() {
		this.kind = "포유류";
	}
	@Override
	public void sound() {
		System.out.println("나는 수업이 세상에서 제일 좋아");
	}
}
