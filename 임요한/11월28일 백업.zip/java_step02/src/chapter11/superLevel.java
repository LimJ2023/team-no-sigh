package chapter11;

public class superLevel extends PlayLevel{

	@Override
    public void run() {
        System.out.println("상급자용 매우 빠른 달리기");
    }

    @Override
    public void jump() {
        System.out.println("아주 높이 뛰기");
    }

    @Override
    public void turn() {
        System.out.println("상급자용 한바퀴 돌기");
    }

    @Override
    public void showLevelMessage() {
        System.out.println("=====상급자 레벨입니다.=====");
    }
}
