package chapter11;

public class HttpServletMain {

	public static void main(String[] args) {
		
		method(new LoginServlet());
		method(new FileDowndoadServlet());
		
		HttpServlet http = null;
		http = new LoginServlet();
		http.service();
		
		http = new FileDowndoadServlet();
		http.service();
	}
	
	public static void method(HttpServlet http) {
		http.service();
	}

}
