package chapter11;

public class MainBoard {

	public static void main(String[] args) {
		
		//초급자
		Player player1 = new Player();
		player1.play(1);
		//중급자
		PlayLevel adLevel = new advancedLevel();
		player1.upgradeLevel(adLevel);
		player1.play(2);
		//상급자
		PlayLevel superLevel = new superLevel();
		player1.upgradeLevel(superLevel);
		player1.play(3);
		
	}
}
