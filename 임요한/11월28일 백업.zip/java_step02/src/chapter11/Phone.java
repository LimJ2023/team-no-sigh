package chapter11;

public abstract class Phone {
	//폰 이름 멤버변수
	String phoneName;
	
	//메서드
	public  void turnOn() {
	System.out.println(phoneName + "을 켭니다.");
	}
	public  void turnOff() {
		System.out.println(phoneName + "을 끕니다.");
	}
	//추상 메서드
	public abstract void charge();
} // Phone
