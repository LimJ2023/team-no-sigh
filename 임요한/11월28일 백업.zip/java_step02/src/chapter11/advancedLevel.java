package chapter11;

public class advancedLevel extends PlayLevel{

	@Override
    public void run() {
        System.out.println("중급자용 빠른 달리기");
    }

    @Override
    public void jump() {
        System.out.println("중급자용  높이 뛰기");
    }

    @Override
    public void turn() {
        System.out.println("중급자용 돌기");
    }

    @Override
    public void showLevelMessage() {
        System.out.println("=====중급자 레벨입니다.=====");
    }
}
