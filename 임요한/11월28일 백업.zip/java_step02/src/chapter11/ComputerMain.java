package chapter11;

public class ComputerMain {

	public static void main(String[] args) {

		//Computer c1 = new Computer(); // 추상 클래스는 객체 생성 불가
		
		Computer desktop = new DeskTop(); // 업캐스팅
		desktop.turnOn();
		desktop.display(); // 구현된 오버라이드 메서드
		desktop.typing();
		desktop.turnOff();
		
		Computer mylaptop = new MyLaptop();
		mylaptop.turnOn();
		mylaptop.display();
		mylaptop.typing();
		mylaptop.turnOff();
	}

}
