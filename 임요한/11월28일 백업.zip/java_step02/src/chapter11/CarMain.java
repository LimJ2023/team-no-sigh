package chapter11;

public class CarMain {

	public static void main(String[] args) {

		Car car1 = new ManualCar();
		Car car2 = new AICar();
		
		System.out.println("======수동 주행=====");
		car1.run();
		System.out.println("======자율 주행=====");
		car2.run();
	}

}
