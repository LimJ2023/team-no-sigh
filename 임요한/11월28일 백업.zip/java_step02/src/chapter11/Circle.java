package chapter11;

public  class Circle extends Shape{

	private double radius;
	
	
	public Circle(double radius) {
		this.radius = radius;
	}


	@Override
	double calculateArea() {
		
		return Math.PI * Math.pow(radius, 2);
	}
	@Override
	void display() {
		//super.display();
		System.out.println("원을 그립니다.");
	}
	

}
