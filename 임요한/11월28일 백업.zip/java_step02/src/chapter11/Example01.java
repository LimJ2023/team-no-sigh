package chapter11;

/* Food 클래스 생성
 * 추상 메서드 cook, eat 생성
 * 
 * Pizza클래스를 Food에게 상속받기 구현은 마음대로
 * */

abstract class Food{
	
	//추상 메서드
	public abstract void cook();
	public abstract void eat();
}

class Pizza extends Food{

	@Override
	public void cook() {
		System.out.println("피자를 굽습니다.");
	}

	@Override
	public void eat() {
		System.out.println("피자를 먹습니다.");
	}
}


public class Example01 {
	
	public static void main(String[] args) {
		
		Food pizza = new Pizza();
		pizza.cook();
		pizza.eat();
		System.out.println();
		foods(new Pizza());
		
	}//main
	public static void foods(Food food) {
		food.cook();
		food.eat();
	}
}
