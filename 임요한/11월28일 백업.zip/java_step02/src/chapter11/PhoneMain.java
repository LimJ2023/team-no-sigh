package chapter11;
	

//추상 클래스 Phone iPhone,갤럭시에 상속
// PhoneMain 출력화면을 보고 유추하여 클래스 다이어그램 빈칸을 추측
// 출력화면이 결과같이 되도록 3개의 클래스 구현
public class PhoneMain {
	public static void main(String[] args) {
		
		IPhone iphone = new IPhone();
		GalaxyPhone samsung = new GalaxyPhone();
		
		iphone.turnOn();
		samsung.turnOn();
		System.out.println("===============");
		iphone.charge();
		samsung.charge();
		System.out.println("===============");
		iphone.takePic();
		samsung.samsungPay();
		System.out.println("===============");
		iphone.turnOff();
		samsung.turnOff();
	}//main
}
