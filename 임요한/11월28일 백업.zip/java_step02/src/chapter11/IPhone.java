package chapter11;

public class IPhone extends Phone{

	//생성자
	public IPhone() {
		this.phoneName = "아이폰";
	}
	
	//메서드
	public void takePic() {
		System.out.println("아이폰으로 사진을 찍습니다.");
	}

	//오버라이드 메서드
	@Override
	public void charge() {
		System.out.println("아이폰을 충전합니다.");
	}
}//IPhone
