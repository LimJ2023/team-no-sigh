package chapter11;

public class GalaxyPhone extends Phone{

	//생성자
	public GalaxyPhone() {
		this.phoneName = "삼성 핸드폰";
	}
	//메서드
	public void samsungPay() {
		System.out.println("삼성 페이로 결제 합니다.");
	}
	//오버라이드 메서드
	@Override
	public void charge() {
		System.out.println("삼성 핸드폰을 충전합니다.");
	}
}//GalaxyPhone
