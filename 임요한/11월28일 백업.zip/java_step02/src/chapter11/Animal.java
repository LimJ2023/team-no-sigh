package chapter11;

public abstract class Animal {
	
	//멤버변수
	public String kind;
	
	public void breathe() {
		System.out.println("숨을 쉽니다.");
	}
	
	//추상 메서드
	public abstract void sound();
}
