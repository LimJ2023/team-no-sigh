package chapter11;

public class AICar extends Car {

	@Override
	public void drive() {
		System.out.println("자율주행을 합니다.");
		System.out.println("스스로 방향을 전환 합니다.");

	}

	@Override
	public void stop() {
		System.out.println("스스로 멈춥니다.");

	}

}
