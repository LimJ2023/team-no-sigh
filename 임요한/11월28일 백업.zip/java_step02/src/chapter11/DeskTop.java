package chapter11;

public class DeskTop extends Computer{

	@Override
	public void display() {
		System.out.println("데스크톱 화면을 보여줍니다.");
		
	}
	@Override
	public void typing() {
		System.out.println("데스크톱으로 타이핑 합니다.");
		
	}
	
}
