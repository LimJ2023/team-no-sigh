package chapter11;

public class MyLaptop extends laptop{
	
	@Override
	public void typing() {
		System.out.println(" my 노트북으로 타이핑 합니다.");
	}
}
