package chapter11;

public abstract class Computer { // 단 하나라도 추상 메서드가 있으면 추상 클래스
	
	//추상메서드 : 구현부가 없음 (비어있다 x)
	public abstract void display(); 
	public abstract void typing(); 
	// 하위 클래스에 구현을 위임한다.
	// 하위 클래스는 구현에 책임이 있다.
	
	public void turnOn() {
		System.out.println("전원을 켭니다.");
	}
	
	public void turnOff() {
		System.out.println("전원을 끕니다.");
	}
	
}


