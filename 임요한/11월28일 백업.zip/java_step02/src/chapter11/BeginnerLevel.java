package chapter11;

public class BeginnerLevel  extends PlayLevel{
	
	@Override
    public void run() {
        System.out.println("초보자용 달리기");
    }

    @Override
    public void jump() {
        System.out.println("초보자용 뛰기");
    }

    @Override
    public void turn() {
        System.out.println("초보자용 돌기");
    }

    @Override
    public void showLevelMessage() {
        System.out.println("=====초보자 레벨입니다.=====");
    }
}
