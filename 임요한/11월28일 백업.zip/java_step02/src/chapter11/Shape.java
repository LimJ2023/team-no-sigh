package chapter11;

public abstract class Shape { //추상 클래스 선언
	
	abstract double calculateArea(); //추상 메서드 선언
	
	void display() {
		System.out.println("도형을 표시합니다.");
	}
}
