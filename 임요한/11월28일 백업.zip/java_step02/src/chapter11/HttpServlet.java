package chapter11;

public abstract class HttpServlet {
	
	//추상 메서드
	public abstract void service();
	
}
