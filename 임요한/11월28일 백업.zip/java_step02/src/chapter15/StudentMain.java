package chapter15;

public class StudentMain {

	public static void main(String[] args) {

		//학번 같은 두개의 객체 생성
		Student stdKim1 = new Student("12345");
		Student stdKim2 = new Student("12345");
		
		//equals()비교
		System.out.println(stdKim1.equals(stdKim2));
		//hashCode()비교
		System.out.println(stdKim1.hashCode() == stdKim2.hashCode());
		//hashCode()출력
		System.out.println(stdKim1.hashCode());
		System.out.println(stdKim2.hashCode());
	}//main

}
