package chapter15;

public class StringTest2 {

	public static void main(String[] args) {
		
		String javaStr = new String("java"); //heap
		String andoroidStr = new String("androidStr"); //heap
		String javaStr_1 = javaStr;
		//String 클래스 toString()메서드는 재정의 되어있음.
		System.out.println(javaStr);
		System.out.println(andoroidStr);
		
		System.out.println("해시코드 " + javaStr.hashCode());
		System.out.println("처음 문자열 주소 " + System.identityHashCode(javaStr));
		
		System.out.println("안녕" + javaStr + "하세요");
		
		javaStr = javaStr.concat(andoroidStr);//concat 메서드로 두 문자열 연결
		
		//새로 생성해준것
		System.out.println(javaStr);
		System.out.println("연결된 문자열 주소 : " + System.identityHashCode(javaStr));
		
		System.out.println("해시코드 " + javaStr_1.hashCode());
		System.out.println("처음 문자열 주소 " + System.identityHashCode(javaStr_1));
		
	
	}

}
