package chapter15;

import java.util.LinkedList;

/*
 * StringBuffer의 append()메서드 사용하여 효율적인 코드로 변경
 * */
public class Example01 {

	public static void main(String[] args) {

		String str = "";
		
		StringBuffer buf = new StringBuffer();
		
		for (int i = 1; i <= 100; i++) {
			buf.append(i);
		}
		System.out.println(buf);
		
		
	}

}
