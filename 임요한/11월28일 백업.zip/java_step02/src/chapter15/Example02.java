package chapter15;


/*
 * 문자열 100을 정수로 반환하는 코드와
 * 
 * 숫자 200을 문자열로 변환하는 코드 작성
 * */
public class Example02 {

	public static void main(String[] args) {

		String str1 = "100";
		int num = Integer.parseInt(str1);
		System.out.println(num);
		
		
		int num2 = 200;
		String str2 = String.valueOf(num2);
		String str3 = Integer.toString(num2);
		
		System.out.println(str2);
		System.out.println(str3);
		System.out.println(str2.getClass().getName());
		System.out.println(str3.getClass().getName());
		
	}

}
