package chapter15;

import java.util.Objects;

/*
 * 멤버변수 String studentNum
 * Object의 equals()와 hashCode() 오버라이딩
 * 
 * Student의 학번 studentNum이 같으면 같은 객체가 될 수 있도록. equals()
 * 
 * 
 * */
public class Student {
	
	String studentNum;
	

	public Student(String studentNum) {
		this.studentNum = studentNum;
	}

	@Override
	public int hashCode() {
		return studentNum.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		//제네릭으로 받은 obj의 타입이 Student일 경우
		if (obj instanceof Student) {
			Student std = (Student)obj;
			//studentNum과 매개변수로 받은 obj의 studentNum을 비교
			if(studentNum == std.studentNum) {
				//같을시 트루 
				return true;
			}
		}
		return false;
			
	}
}//Student
