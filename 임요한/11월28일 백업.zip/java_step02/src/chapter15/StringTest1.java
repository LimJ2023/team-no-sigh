package chapter15;

public class StringTest1 {

	public static void main(String[] args) {

		String s1 = new String("candy");
		String s2 = new String("candy");
		
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		
		String s3 = "candy"; 
		//상수풀에 이 단어는 없음
		//jvm이 확인해봐서 없는 단어면 상수풀에 추가함
		
		String s4 = "candy";
		//어 있네? 그냥 써
		System.out.println(s3 == s4);
		
		//최적화 문제때문에 -128~127인 것이지 고치면 int만큼가능
	}

}
