package chapter15;

import java.text.SimpleDateFormat;
import java.util.Date;

/*SimpleDateFormat 클래스를 사용하여 날짜를
 *  2023년 11월 24일 금요일 _시 _분 오전 시간 입니다~! 로 출력
 *  
 *  
 * */

public class Example03 {

	public static void main(String[] args) {
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(
				"YYYY년 MM월 d일 E요일 HH시 mm분 a 시간 입니다~!");
		
		System.out.println(dateFormat.format(new Date()));
	}

}
