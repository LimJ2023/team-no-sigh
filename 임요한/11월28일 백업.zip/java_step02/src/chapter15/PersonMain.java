package chapter15;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class PersonMain {

	public static void main(String[] args) throws ClassNotFoundException{

		//방법 1
		Person person = new Person();
		
		Class<? extends Person> pClass1 = person.getClass();
		
		System.out.println(pClass1.getName());
		
		//방법 2
		Class<Person> pClass2 = Person.class;
		System.out.println(pClass2.getName());
		
		//방법 3
		Class<?> pClass3 = Class.forName("chapter15.Person");
		System.out.println(pClass3.getName());
		
		ArrayList<Integer> l = new ArrayList<Integer>();
		l.add(10);
		
		System.out.println(l.get(0));
		
		
		
	}

}
