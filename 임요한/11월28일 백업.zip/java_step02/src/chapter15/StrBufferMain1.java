package chapter15;

public class StrBufferMain1 {

	public static void main(String[] args) {

		StringBuffer buf = new StringBuffer("Nice day");
		System.out.println(buf.toString());
		System.out.println(buf.length());
		
		//StringBuffer의 기본 용량 16 + 8 = 24
		System.out.println(buf.capacity()); //24
		
		buf.insert(0, "Hi! ");
		System.out.println(buf);
		
		buf.insert(12, " EveryBody");
		System.out.println(buf);
		
		buf.delete(0, 4);
		System.out.println(buf);
		
		
		//StringBuilder
		StringBuilder sb = new StringBuilder();
		sb.ensureCapacity(50); // 최소 용량 50으로 설정
		
		
	}

}
