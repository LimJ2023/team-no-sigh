package practice01;

class Node {
	Node next; // 다음 노드의 주소 저장
	Node prev; // 이전 노드의 주소 저장
	int data; // 데이터 필드
}
