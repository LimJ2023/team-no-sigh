package chapter11_test;

public class Salad extends Food {

	@Override
	public void getTaste() {
		System.out.println("샐러드 맛을 봅니다.");

	}

	@Override
	public void cook() {
		System.out.println("신선한 야채를 손질하여 드레싱으로 마무리 합니다.");

	}

	@Override
	public void serve() {
		System.out.println("메인메뉴 보다 전에 서빙 됩니다.");

	}

}//salad
