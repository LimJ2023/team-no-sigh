package chapter11_test;


/*
	 * static 변수를 갖는 point를 Guide 클래스 생성
	 * 이름과 성별을 갖는 Guest 클래스 생성
	 * 
	 * 아래의 결과가 나오도록 하는 로직 구현
	 * */
public class Guide {
	
	static String point; //목적지
	Guest[] guests;
	
	// 관광객 수 입력
	public void inputGuestNumber(int num) { 
		guests = new Guest[num];
		for (int i = 0; i < guests.length; i++) {
			guests[i] = new Guest();
		}
	}
	
	//관광객 정보
	public void showGuestInfo() { 
		for (int i = 0; i < guests.length; i++) {
			System.out.println((i+1)  + ". 이름 : " + guests[i].getName());
			System.out.println((i+1)  + ". 성별 : " + guests[i].getGender());
			System.out.println((i+1)  + ". 목적지 : " + point);
			if(i != guests.length - 1)
				System.out.println("--------------------------------------");
		}
		System.out.println("========================================");
	}
}//Guide
