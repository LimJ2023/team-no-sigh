package chapter11_test;


/* prepare 메서드 "재료를 준비합니다." 생성
 * process 템플릿 메서드 생성
 * 
 * prepare : 재료준비
 * getTaste : 맛을 반환
 * cook : 조리하는 메서드
 * serve : 서빙하는 메서드
 * 
 * */
public abstract class Food {
	
	//공통 메서드
	public void prepare() {
		System.out.println("재료를 준비합니다.");
	}
	
	//추상 메서드
	public abstract void getTaste();
	public abstract void cook();
	public abstract void serve();
	
	//템플릿 메서드
	final public void process() {
		prepare();
		cook();
		serve();
		getTaste();
	}
}//Food


