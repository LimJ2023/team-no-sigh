package chapter11_test;

public class Pizza extends Food {

	@Override
	public void getTaste() {
		System.out.println("피자 맛을 봅니다.");
	}

	@Override
	public void cook() {
		System.out.println("소스를 바르고 치즈와 재료를 올립니다.");

	}

	@Override
	public void serve() {
		System.out.println("피자를 서빙 할 때는 수제 피클이 함께 제공됩니다.");

	}

}// Pizza
