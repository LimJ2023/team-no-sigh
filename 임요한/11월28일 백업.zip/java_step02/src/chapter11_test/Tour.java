package chapter11_test;

import java.util.Scanner;

public class Tour {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		Guide guide = new Guide();
		boolean run = true; //while문 실행 트리거

		System.out.print("관광객 수 : ");
		int GuestNum = scan.nextInt();
		scan.nextLine();
		//관광객 수 입력
		guide.inputGuestNumber(GuestNum);
		
		//관광객 등록
		System.out.println("관광객 등록");
		for (int i = 0; i < GuestNum; i++) {
			System.out.print((i+1) + ". 이름 : ");
			String name = scan.nextLine();
			guide.guests[i].setName(name);
			
			System.out.print((i+1) + ". 성별 : ");
			String gender = scan.nextLine();
			guide.guests[i].setGender(gender);
			System.out.println("--------------------------");
		}
		Guide.point = "호주";
		
		//메뉴 실행
		while (run) {
			System.out.println("1. 관광객 정보");
			System.out.println("2. 목적지 변경");
			System.out.println("3. 종료");
			
			System.out.print("선택 >>");
			int selectMenu = scan.nextInt();
			scan.nextLine();
			
			switch (selectMenu) {
			case 1: // 관광객 정보
				guide.showGuestInfo();
				break;
			case 2: // 목적지 변경
				System.out.print("어디로 변경하시겠습니까? : ");
				String changePoint = scan.nextLine();
				Guide.point = changePoint; // 스테틱 변수 대입
				System.out.println(Guide.point + "로 목적지 변경");
				System.out.println("========================================");
				break;
			case 3:// 종료
				System.out.println("종료");
				run = false; // while문 종료
				break;
			default:
				System.out.println("잘못된 메뉴 선택입니다.");
				break;
			}// switch
		} // while
		scan.close();
	}// main
}
