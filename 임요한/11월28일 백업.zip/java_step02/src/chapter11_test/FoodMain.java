package chapter11_test;

public class FoodMain {

	public static void main(String[] args) {
		
		System.out.println("=====피자=====");
		Food pizza = new Pizza();
		pizza.process();
		
		System.out.println("=====샐러드=====");
		Food salad = new Salad();
		salad.process();
		
		System.out.println("=====파스타=====");
		Food pasta = new Pasta();
		pasta.process();

	}//main

}
