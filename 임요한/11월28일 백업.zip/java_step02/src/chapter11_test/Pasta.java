package chapter11_test;

public class Pasta extends Food {

	@Override
	public void getTaste() {
		System.out.println("파스타 맛을 봅니다.");

	}

	@Override
	public void cook() {
		System.out.println("파스타를 끓는 물에 삶고 소스를 만들어 파스타를 완성합니다.");

	}

	@Override
	public void serve() {
		System.out.println("플레이팅 된 파스타를 포크와 서빙합니다.");

	}

}//pasta
