package chapter08;

public class StaticFunctionMain {

	public static void main(String[] args) {
		
		StaticFunction sf = new StaticFunction();
		
		
		sf.str1 = "vip";
		StaticFunction.str2 = "vvip";
		String s = StaticFunction.getStatic();
		String s2 = sf.str1;
		System.out.println(sf.str1);
		System.out.println(s);
		
	}

}
