package chapter08;

public class CardCompany {
	
	//멤버변수
	private static CardCompany instance = new CardCompany();
	public Card card;
	
	//메서드
	
	//싱글톤 객체 생성 메서드
	public static CardCompany getInstance() {
		if(instance == null) {
			instance = new CardCompany();
		}
		return instance;
	}
	
	
	  public Card issueCard() {
		  card = new Card();
		  return card;
	  }
	 
	public void showCardInfo() { //카드 번호 조회 메서드
		System.out.println("카드 번호 : " + card.getCardNumber());
	}
	
	
	public static void main(String[] args) {

		//싱글톤 패턴의 컴파니 2개 생성(같은 객체 참조중)
		CardCompany company1 = CardCompany.getInstance();
		CardCompany company2 = CardCompany.getInstance();
		
		//컴파니1의 카드생성
		/*
		 * company1.issueCard(); company1.showCardInfo(); // 메서드 호출로 조회
		 * company1.issueCard(); company1.showCardInfo(); //컴파니2의 카드생성
		 * company2.issueCard(); //컴파니2의 객체안의 멤버변수 카드에 접근후 메서드 호출.
		 * System.out.println("카드 번호 : " + company2.card.getCardNumber());
		 * company2.issueCard(); System.out.println("카드 번호 : " +
		 * company2.card.getCardNumber());
		 */
		
		//카드변수 생성후 대입하는 방법(카드확인용)
		
		  Card card1 = company1.issueCard();
		  Card card2 = company2.issueCard();
		  
		  
		  System.out.println(card1); 
		  System.out.println(card2);
		  System.out.println("카드 번호 : " + card1.getCardNumber());
		  System.out.println("카드 번호 : " + card2.getCardNumber());
		 
		
	}//main
}// CardCompany class
