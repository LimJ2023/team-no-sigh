package chapter08;
/*카드를 발급받을 때마다 카드 고유번호 획득
 * 카드가 생성될 때마다 카드번호가 자동으로 증가하는 카드 클래스 생성
 * 카드회사 cardCompany를 싱글톤 패턴으로 작성.
 * */

public class Card {
	private static int cardConuter = 1000; //카드의 시작 번호
	private int cardNumber; // 발급받을 번호
	
	public Card() {
		cardNumber =  ++cardConuter;
	}
	
	public int getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(int cardNumber) {
		this.cardNumber = ++cardNumber;
	}

	public static int getCardConuter() {
		return cardConuter;
	}

	public static void setCardConuter(int cardConuter) {
		Card.cardConuter = cardConuter;
	}
	
	
	
}
