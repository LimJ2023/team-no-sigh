package chapter08;

public class BankMain {

	public static void main(String[] args) {

		Bank bank1 = new Bank("1호점", "2222-3333");
		// 스테틱 변수는 클래스가 만들어질 때 생성됨.
		bank1.interest = 0.2f; 
		bank1.getBank();
		System.out.println("=====================");
		
		Bank bank2 = new Bank("2호점", "4444-5555");
		bank2.getBank();
		System.out.println("=====================");
		
		// 클래스에 직접 접근도 가능
		Bank.interest = 0.5f; 
		bank2.getBank();
		
	}

}
