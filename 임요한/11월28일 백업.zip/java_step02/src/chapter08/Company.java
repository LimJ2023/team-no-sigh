package chapter08;

public class Company {
	
	//객체를 단 하나만 생성하는 클래스
	
	private static Company instance = new Company();
	
	//기본생성자
	public Company() {

	}
	
	//싱글톤 객체 생성 메서드
	public static Company getInstance() {
		//맨처음 객체가 없을시 초기화 작업.
		if(instance == null) {
			instance = new Company();
		}
		return instance;
	}
	
}
