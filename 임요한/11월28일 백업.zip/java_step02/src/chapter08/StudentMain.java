package chapter08;

public class StudentMain {

	public static void main(String[] args) {
		
		Student stdKim = new Student();
		stdKim.setStudentName("김수한");
		System.out.print("이름 : " + stdKim.getStudentName());
		System.out.println(" 아이디 : " + stdKim.studentID);
		
		Student stdLee = new Student();
		stdLee.setStudentName("이용대");
		System.out.print("이름 : " + stdLee.getStudentName());
		System.out.println(" 아이디 : " + stdLee.studentID);
		
		Student stdLim = new Student();
		stdLim.setStudentName("임예진");
		System.out.print("이름 : " + stdLim.getStudentName());
		System.out.println(" 아이디 : " + stdLim.studentID);
		
	}

}
