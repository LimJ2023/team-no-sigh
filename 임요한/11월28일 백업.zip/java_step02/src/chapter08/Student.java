package chapter08;

public class Student {
	
	
	//멤버변수
	private static int serialNum = 9999;
	int studentID;
	String StudentName; // 아마도 상수로 쓸 예정
	int grade;
	String adress;
	
	//생성자
	public Student() {
		serialNum++;
		this.studentID = serialNum;
	}
	
	//게터 세터
	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}

	public static int getSerialNum() {
		return serialNum;
	}

	public static void setSerialNum(int serialNum) {
		Student.serialNum = serialNum;
	}
	
	
	
	
}
