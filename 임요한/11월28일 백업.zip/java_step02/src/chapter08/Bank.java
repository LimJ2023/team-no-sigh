package chapter08;

public class Bank {
	
	private String name;
	private String tel;
	static float interest;//이자
	
	
	public Bank(String name, String tel) {
		this.name = name;
		this.tel = tel;
	}
	
	public void getBank() {
		System.out.println("지점 : " + name + "\n" + "번호 :" + tel + "\n" + 
				"이자 : " + interest);
	}
	
}
