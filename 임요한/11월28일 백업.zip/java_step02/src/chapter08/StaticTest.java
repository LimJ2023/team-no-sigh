package chapter08;


class StVal{
	int a;
	static int b;
	
}


public class StaticTest {

	public static void main(String[] args) {
		
		StVal obj1 = new StVal();
		StVal obj2 = new StVal();
		
		obj1.a = 10;
		obj1.b = 20;
		System.out.println(obj1.a + " " + obj1.b);
		
		obj2.a = 100;
		obj2.b = 200;
		System.out.println(obj2.a + " " + obj2.b);
		
		//obj1의 스태틱 변수가 덮어씌워짐
		System.out.println(obj1.b);
		
		StVal.b = 300;
		//클래스에 직접 접근시 둘 다 덮어쓰기됨.
		System.out.println(obj1.b +" "+  obj2.b);
		
	}

}
