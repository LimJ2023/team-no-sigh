package chapter08;

public class Family {
	
	private static Family instance = new Family();
	
	public Family() {
		// TODO Auto-generated constructor stub
	}
	
	public static Family getInstance() {
		//만일 객체가 초기화 되지 않았다면
		if(instance == null) {
			//생성해줌
			instance = new Family();
		}
		//Family타입의 instance를 반환
		//생성된 instance가 있을시 그 객체를 반환.
		return instance;
	}
	
}
