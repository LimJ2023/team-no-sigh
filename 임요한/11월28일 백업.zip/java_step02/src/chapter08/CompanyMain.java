package chapter08;

public class CompanyMain {

	public static void main(String[] args) {

		//일반적인 객체 생성은 heap 메모리에 저장.
		Company company1 = new Company();
		Company company2 = new Company();
		
		System.out.println(company1);
		System.out.println(company2);
		//Company.getInstance();
		
		System.out.println("=======싱글톤========");
		//정적(고정되어 있는) 메서드인 getInstance()를 호출하여 싱글톤 객체 생성.
		Company myCompany1 = Company.getInstance();
		Company myCompany2 = Company.getInstance();
		
		//두 참조변수의 주소가 같음. 동일한 객체를 참조한다.
		System.out.println(myCompany1);
		System.out.println(myCompany2);
	}

}
