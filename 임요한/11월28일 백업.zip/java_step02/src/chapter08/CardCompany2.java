package chapter08;

public class CardCompany2 {
	
	//멤버변수
	private static CardCompany2 instance = new CardCompany2();
	public Card card;
	
	public CardCompany2() {
		// TODO Auto-generated constructor stub
	}
	//메서드
	
	//싱글톤 객체 생성 메서드
	public static CardCompany2 getInstance() {
		if(instance == null) {
			instance = new CardCompany2();
		}
		return instance;
	}
	
	public Card issueCard() {//카드 발급 메서드
		
		return new Card();
	}
	
	
	public void showCardInfo() { //카드 번호 조회 메서드
		System.out.println("카드 번호 : " + card.getCardNumber());
	}
	
	
	public static void main(String[] args) {

		//싱글톤 패턴의 컴파니 2개 생성(같은 객체 참조중)
		CardCompany2 company1 = CardCompany2.getInstance();
		CardCompany2 company2 = CardCompany2.getInstance();
		
		//컴파니1의 카드생성
		company1.issueCard();
		company1.showCardInfo(); // 메서드 호출로 조회
		company1.issueCard();
		company1.showCardInfo();
		//컴파니2의 카드생성
		company2.issueCard();
		//컴파니2의 객체안의 멤버변수 카드에 접근후 메서드 호출.
		System.out.println("카드 번호 : " + company2.card.getCardNumber());
		company2.issueCard();
		System.out.println("카드 번호 : " + company2.card.getCardNumber());
		
		//카드변수 생성후 대입하는 방법(카드확인용)
		Card card1 = company1.issueCard();
		System.out.println("카드 번호 : " + card1.getCardNumber());
		
	}//main
}// CardCompany class
