package chapter08;

public class FamilyMain {

	public static void main(String[] args) {

		Family fam1 = Family.getInstance();
		Family fam2 = Family.getInstance();
		
		System.out.println(fam1);
		System.out.println(fam2);
		
		
	}

}
