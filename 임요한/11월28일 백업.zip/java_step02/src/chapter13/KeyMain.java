package chapter13;

import java.util.HashMap;

public class KeyMain {

	public static void main(String[] args) {

		//링크드 리스트?
		HashMap<Key, String> hashmap = new HashMap<Key, String>();
		
		hashmap.put(new Key(1), "홍길동");
		hashmap.put(new Key(2), "홍길동");
		hashmap.put(new Key(5), "홍길동");
		hashmap.put(new Key(5), "홍길동");
		//중복 저장이 안됐음
		System.out.println(hashmap);
	}

}
