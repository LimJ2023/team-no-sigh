package chapter13;

import java.util.Date;

public class ToStringEx0 {
	
	public static void main(String[] args) {
		
		Object obj1 = new Object();
		
		Date obj2 = new Date();
		
		System.out.println(obj1.toString()); //인스턴스의 이름과 주소값을 확인 가능
		System.out.println(obj2.toString());
		
		System.out.println("===============");
		//재정의 하지 않은 toString()은 원형과 같다.
		System.out.println(obj1);
		System.out.println(obj2);
	}
}
