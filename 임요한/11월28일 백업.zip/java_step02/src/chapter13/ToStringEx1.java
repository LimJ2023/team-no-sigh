package chapter13;


class Book{
	String title;
	String author;
	
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
	}

	//문자열로 출력해주는 toString() 재정의
	@Override
	public String toString() {
		return title + ", " + author;
	}
	
}
public class ToStringEx1 {
	public static void main(String[] args) {
		Book book = new Book("홍길동전", "미상");
		//원형을 부르면 toString()메서드 호출
		System.out.println(book);
		
		//String 클래스는 재정의 되어있음.
		String str = new String("왜일까요");
		String str2 = "왜일까요2";
		String str3 = "왜일까요2";
		System.out.println(str);
		System.out.println(str2);
		System.out.println(str == str2);
		System.out.println(str2 == str3);
		// 새 객체 생성과 이미 있는 타입을 불러온 것의 차이
	}
}
