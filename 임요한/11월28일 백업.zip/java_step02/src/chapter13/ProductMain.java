package chapter13;

public class ProductMain {

	public static void main(String[] args) {

		Product smartPhone = new Product("스마트폰", 70);
		System.out.println(smartPhone);
		System.out.println(smartPhone.toString());
	}//main
}
