package chapter13;

public class StudentMain {

	public static void main(String[] args) {

		Student std1 = new Student(1234, "임요한");
		Student std2 = new Student(1234, "임요한");
		Student std3 = std1;

		System.out.println(std1 == std2);
		System.out.println(std1.equals(std2));
		System.out.println(std1 == std3);

		if (std1 == std2) {
			System.out.println("std1 == std2 객체는 같습니다.");
		} else {
			System.out.println("std1 == std2 객체는 다릅니다.");
		}
		
		//equals로 논리적 동일성 확인할 수 있다.
		if (std1.equals(std2)) {
			System.out.println("std1 == std2 학번은 같습니다.");
		} else {
			System.out.println("std1 == std2 학번은 다릅니다.");
		}

		if (std1 == std3) {
			System.out.println("std1 == std3 객체는 같습니다.");
		} else {
			System.out.println("std1 == std3 객체는 다릅니다.");
		}
		
		
		System.out.println(std1);
		System.out.println(std2);
		
		System.out.println("=====데이터 값 출력=====");
		System.out.println("std1의 hashCode(학번) : " + std1.hashCode());
		System.out.println("std2의 hashCode(학번) : " + std2.hashCode());
		System.out.println("std3의 hashCode(학번) : " + std3.hashCode());

		
		System.out.println("std1의 실제 주소값 : " + System.identityHashCode(std1));
		System.out.println("std2의 실제 주소값 : " + System.identityHashCode(std2));
		System.out.println("std3의 실제 주소값 : " + System.identityHashCode(std3));
	}//main

}
