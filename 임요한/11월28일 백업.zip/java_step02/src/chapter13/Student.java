package chapter13;

public class Student {

	int studentId;
	String studentName;

	public Student(int studentId, String studentName) {
		this.studentId = studentId;
		this.studentName = studentName;
	}

	// 학번이 같으면 같은 학생으로 판단
	// equals를 재정의
	@Override
	public boolean equals(Object obj) {

		if (obj instanceof Student) {
			Student std = (Student) obj;
			if (studentId == std.studentId) {
				return true;
			} else
				return false;
		}
		return false;
	}

	@Override
	public String toString() {
		return "학번 : " + studentId + " 이름 : " + studentName;
	}

	// 해시코드 값으로 학번을 반환하도록 재정의

	@Override
	public int hashCode() {
		return studentId;
	}

}
