package chapter13;

public class StringEqualsEx {

	public static void main(String[] args) {

		String str = new String("임요한정보1");
		String str2 = "임요한정보1"; // 상수풀에 존재
		String str3 = "임요한정보1";
		
		String str4 = str;
		System.out.println(str);
		System.out.println(str2);
		System.out.println(str == str2);
		System.out.println(str2 == str3);
		System.out.println(str4 == str);
		
		
		if(str == str2) { // 객체 메모리 비교
			System.out.println("같은 String 객체 참조");
		}else {
			System.out.println("다른 String 객체 참조");
		}
		
		if(str.equals(str2)) {//논리적 문자열 비교
			System.out.println("같은 문자열을 가짐");
		}else {
			System.out.println("다른 문자열을 가짐");
		}
	}

}
