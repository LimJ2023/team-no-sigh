package chapter13;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateExample {

	public static void main(String[] args) {

		Date now = new Date();
		System.out.println(now);
		String strNow1 = now.toString();
		System.out.println("=====DATA=====");
		System.out.println(strNow1);
		
		//Date 함수의 포멧을 변경
		SimpleDateFormat simple = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초 입니다.");
		//Date타입 넣어줌
		String strNow2 = simple.format(now);
		//출력
		System.out.println(strNow2);
		
		System.out.println(simple.format(now));
		System.out.println(simple.format(new Date()));
	
	}

}
