package chapter13;

public class HashCode {

	public static void main(String[] args) {

		String str1 = new String("abc");
		String str2 = new String("abc");
		
		System.out.println(str1.equals(str2));
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		
		Integer num1 = 42;
		Integer num2 = 42;
		
		System.out.println(num1.equals(num2));
		System.out.println(num1.hashCode());
		System.out.println(num2.hashCode());
	}

}
