package chapter13;

public class StringEquals {

	public static void main(String[] args) {

		String str1 = new String("test");
		String str2 = new String("test");
		
		System.out.println(str1 == str2); //메모리 주소 동일성 확인
		System.out.println(str1.equals(str2)); // 논리적 문자열 동일성 확인
		
		//상수풀
		String str3 = "abc";
		String str4 = "abc";
		System.out.println(str3 == str4);
		
		/*
		 * Integer i1 = new Integer(100); Integer i2 = new Integer(100);
		 * 
		 * System.out.println(i1 == i2); System.out.println(i1.equals(i2));
		 */
		
		Integer i3 = 10; // 상수풀
		Integer i4 = 10;
		
		System.out.println(i3 == i4);
		
	}

}
