package chapter13;


/*
 * Produduct 클래스와 ProductMain 클래스 생성
 * 멤버변수 name, price.
 * Product 클래스의 toString() 메서드를 오버라이딩하여
 * 결과를 출력
 * 
 * 스마트폰은 70만원 입니다.
 * */
public class Product {
	
	//멤버변수
	public String name;
	public int price;
	
	//생성자
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}

	
	//오버라이드 메서드
	@Override
	public String toString() {
		return name + "은 " + price + "만원 입니다.";
	}
	
	
}//Product
