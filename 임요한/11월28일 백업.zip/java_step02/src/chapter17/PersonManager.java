package chapter17;

import java.util.ArrayList;

public class PersonManager {
	
	ArrayList<Person> personArr = new ArrayList<Person>();
	
	
}
