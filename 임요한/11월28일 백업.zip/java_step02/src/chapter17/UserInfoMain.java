package chapter17;

import java.util.ArrayList;
import java.util.Scanner;

public class UserInfoMain {

	public static void main(String[] args) {

		ArrayList<UserInfo> arrList = new ArrayList<UserInfo>();
		
		outher : while (true) {
			System.out.print("아이디 생성 : ");
			Scanner sc = new Scanner(System.in);
			UserInfo ui = new UserInfo();
			ui.setId(sc.next());
			
			for (int i = 0; i < arrList.size(); i++) {
				if(ui.getId().equals(arrList.get(i).getId())) {
					System.out.println("아이디가 중복됩니다.");
					continue outher;
				}
			}
			
			System.out.print("패스워드를 입력하세요. : ");
			ui.setPwd(sc.nextInt());
			arrList.add(ui);
			
			for (int i = 0; i < arrList.size(); i++) {
				System.out.println(arrList.get(i).getId());
				System.out.println(arrList.get(i).getPwd());
				System.out.println("--------------------------");
			}
			//sc.close();
		}
	}

}
