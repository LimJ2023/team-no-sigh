package chapter17;

import java.util.Vector;

public class VectorTest {

	public static void main(String[] args) {

		Object obj;
		Vector<Object> vec = new Vector<Object>(1); //1<-초기용량설정
		
		obj = 231127;
		vec.addElement(obj);
		//vec의 용량
		System.out.println("용량은 #1 : " + vec.capacity());
		//저장된 실제 요소 개수
		System.out.println("크기는 #1 : " + vec.size());
		System.out.println(vec);
		
		obj = "choco";
		vec.addElement(obj);
		System.out.println("용량은 #2 : " + vec.capacity());
		//저장된 실제 요소 개수
		System.out.println("크기는 #2 : " + vec.size());
		System.out.println(vec);
		
		obj = "jelly and candy";
		vec.addElement(obj);
		System.out.println("용량은 #3 : " + vec.capacity());
		//저장된 실제 요소 개수
		System.out.println("크기는 #3 : " + vec.size());
		System.out.println(vec);
		
		
	}

}
