package chapter17;

import java.util.LinkedList;

public class LinkedListTest {

	public static void main(String[] args) {

		LinkedList<String> myList = new LinkedList<String>();
		
		myList.add("A");
		myList.add("B");
		myList.add("C");
		
		System.out.println(myList);
		
		myList.add(3, "D");
		
		System.out.println(myList);
		myList.addFirst("K");
		System.out.println(myList);
		myList.addLast("M");
		System.out.println(myList);
		myList.removeLast();
		System.out.println(myList);
		
		
		
	}

}
