package chapter17;

import java.util.ArrayList;
import java.util.List;

public class ArrayListTest {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		
		list.add("Java");
		list.add("Oracle");
		list.add("JSP");
		list.add(2,"Spring");
		list.add("Python");
		
		int size = list.size();
		
		System.out.println(size);
		String skill = list.get(2);
		System.out.println(skill);
		for(String str : list) {
			System.out.println(str);
		}
		list.remove(2);
		for(String str : list) {
			System.out.println(str);
		}
		list.remove("Python");
		for(String str : list) {
			System.out.println(str);
		}
		
	}

}
