package chapter17;

public class Member {
	
	private int memId;
	private String memName;
	
	public Member(int memId, String memName) {
		this.memId = memId;
		this.memName = memName;
	}
	
	
	@Override
	public String toString() {
		return memName + " 회원님의 아이디는 " + memId + "입니다";
	}


	public int getMemId() {
		return memId;
	}

	public void setMemId(int memId) {
		this.memId = memId;
	}

	public String getMemName() {
		return memName;
	}

	public void setMemName(String memName) {
		this.memName = memName;
	}
	
	
	
	
}
