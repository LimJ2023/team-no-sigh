package chapter17;

import java.util.Iterator;
import java.util.LinkedList;

public class MemberLinkedList {
	
	
	LinkedList<Member> linkedList;
	
	public MemberLinkedList() {
		linkedList = new LinkedList<Member>();
	}
	
	public void addMember(Member mem) {
		linkedList.add(mem);
	}
	
	//회원 삭제
		public boolean removeMember(int memId) {
			Iterator<Member> it = linkedList.iterator();
			while (it.hasNext()) {
				Member mem = it.next();
				int tempId = mem.getMemId();
				if(tempId == memId) {
					linkedList.remove(mem);
					return true;
				}
			}
			System.out.println(memId + "가 존재하지 않습니다.");
			return false;
		}
		
		
		//회원 조회
		public void showAllMember() {
			for (Member member : linkedList) {
				System.out.println(member);
			}
			System.out.println();
		}
}
