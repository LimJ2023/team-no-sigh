package chapter17;

public class MemberArrListMain {

	public static void main(String[] args) {
		
		MemberArrayList memArrList = new MemberArrayList();
		
		Member memLee = new Member(1001, "이지원");
		Member memSon = new Member(1002, "손흥민");
		Member memParck = new Member(1003, "박지성");
		Member memHong = new Member(1004, "홍길동");
		Member memHong2 = new Member(1004, "홍길동");
		
		memArrList.addMember(memLee);
		memArrList.addMember(memSon);
		memArrList.addMember(memParck);
		memArrList.addMember(memHong);
		memArrList.addMember(memHong2);
		
		
		memArrList.showAllMember();
		memArrList.removeMember(memHong.getMemId());
		memArrList.removeMember(memHong.getMemId());
		memArrList.showAllMember();
		memArrList.removeMember(1000);
		
		
	}

}
