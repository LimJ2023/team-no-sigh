package chapter17;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListTest {
	public static void main(String[] args) {
		
		//List 구조를 갖는 ArrayList 객체 생성
		List<String> ls = new ArrayList<String>();
		
		ls.add("Hi!");
		ls.add("Happy!");
		ls.add("Nice!");
		
		for (int i = 0; i < ls.size(); i++) {
			System.out.println(i + ": " + ls.get(i).toString());
		}
		
		System.out.println("데이터 추가 후");
		//순서를 뒤로 밀수도 있음
		ls.add(2,"Good!");
		System.out.println(ls);
		
		ls.remove(0);
		System.out.println(ls);
		
		//역순 출력
		ListIterator<String> iterator = ls.listIterator(ls.size());
		while (iterator.hasPrevious()) {
			System.out.print(iterator.previous() + " ");
		}
		
	}
}
