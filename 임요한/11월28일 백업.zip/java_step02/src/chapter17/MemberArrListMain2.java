package chapter17;

public class MemberArrListMain2 {

	public static void main(String[] args) {
		
		MemberArrayList list = new MemberArrayList();
		
		Member memLee = new Member(1001, "이지원");
		Member memSon = new Member(1002, "손흥민");
		Member memPark = new Member(1003, "박지성");
		Member memHong = new Member(1004, "홍길동");
		Member memHong2 = new Member(1004, "홍길동");
		
		list.addMember2(memLee);
		list.addMember2(memSon);
		list.addMember2(memPark);
		list.addMember2(memHong);
		list.addMember2(memHong2);
		
		list.showAllMember();
	}

}
