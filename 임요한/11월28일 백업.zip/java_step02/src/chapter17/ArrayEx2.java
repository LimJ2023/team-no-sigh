package chapter17;

import java.util.ArrayList;

//ArrayList를 사용하여 홍길동, 이순신, 강감찬, 을지문덕, 김유신을 추가
public class ArrayEx2 {

	public static void main(String[] args) {
		ArrayList<String> list = new ArrayList<String>();
		
		list.add("홍길동");
		list.add("이순신");
		list.add("강감찬");
		list.add("을지문덕");
		list.add("김유신");
		
		for (String string : list) {
			System.out.print(string + " ");
		}
		
		System.out.println();
		System.out.println(list.get(0));
		System.out.println(list.get(2));
		
	}

}
