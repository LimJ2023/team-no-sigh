package chapter17;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class ArrayEx1 {

	public static void main(String[] args) {

		ArrayList<Integer> list = new ArrayList<Integer>();
		
		System.out.println("list.size() :" + list.size());
		
		list.add(100);
		list.add(20);
		list.add(50);
		list.add(200);
		System.out.println("list.size() :" + list.size());
		
		//오름차순 정렬
		list.sort(Comparator.naturalOrder());
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}
		
		Iterator<Integer> it = list.iterator();
		//목록 반복자
		while (it.hasNext()) {
			System.out.println(it.next());
		}
		
	}

}
