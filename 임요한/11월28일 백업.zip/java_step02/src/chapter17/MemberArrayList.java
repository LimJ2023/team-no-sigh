package chapter17;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class MemberArrayList {
	
	private ArrayList<Member> arrList;
	HashMap<Integer,Member> set;
	
	public MemberArrayList() {
		arrList = new ArrayList<Member>();
		set = new HashMap<Integer,Member>();
	}
	
	//회원 추가
	public void addMember(Member mem) {
		arrList.add(mem);
	}
	
	public void addMember2(Member mem) {
		set.put(mem.getMemId(), mem);
		arrList.add(mem);
	}
	//회원 삭제
	public boolean removeMember(int memId) {
		Iterator<Member> it = arrList.iterator();
		while (it.hasNext()) {
			Member mem = it.next();
			int tempId = mem.getMemId();
			if(tempId == memId) {
				arrList.remove(mem);
				return true;
			}
		}
		System.out.println(memId + "가 존재하지 않습니다.");
		return false;
	}
	
	public boolean removeMember2(int memId) {
		 if(set.containsKey(memId)) {
			 set.remove(memId);
			 return true;
		 }
		 return false;
		
		
		
		
	}
	
	//회원 조회
	public void showAllMember() {
		for (Member member : arrList) {
			System.out.println(member);
		}
		System.out.println();
	}
}
