package chapter17;

public class MemLinkListMain {

	public static void main(String[] args) {

		//순서,중복 o
		MemberLinkedList memLinkedList = new MemberLinkedList();
		
		Member memLee = new Member(1001, "이지원");
		Member memSon = new Member(1002, "손흥민");
		Member memParck = new Member(1003, "박지성");
		Member memHong = new Member(1004, "홍길동");
		Member memHong2 = new Member(1004, "홍길동");
		
		memLinkedList.addMember(memLee);
		memLinkedList.addMember(memSon);
		memLinkedList.addMember(memParck);
		memLinkedList.addMember(memHong);
		memLinkedList.addMember(memHong2);
		
		memLinkedList.showAllMember();
	}

}
