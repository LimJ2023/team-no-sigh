package chapter17;

import java.util.List;
import java.util.Vector;

public class BoardMain {

	public static void main(String[] args) {

		List<Board> vec = new Vector<Board>();
		
		vec.add(new Board("제목1", "내용1", "글쓴이1"));
		vec.add(new Board("제목2", "내용2", "글쓴이2"));
		vec.add(new Board("제목3", "내용3", "글쓴이3"));
		vec.add(new Board("제목4", "내용4", "글쓴이4"));
		vec.add(new Board("제목5", "내용5", "글쓴이5"));
		
		for (int i = 0; i < vec.size(); i++) {
			Board board = vec.get(i);
			System.out.println(board.subject + "\t" + 
			board.content + "\t" + board.writer);
		}
		
		System.out.println("================");
		vec.remove(2);
		vec.remove(2);
		
		for (int i = 0; i < vec.size(); i++) {
			Board board = vec.get(i);
			System.out.println(board.subject + "\t" + 
			board.content + "\t" + board.writer);
		}
	}

}
