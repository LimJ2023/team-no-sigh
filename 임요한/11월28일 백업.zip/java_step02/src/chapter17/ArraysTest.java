package chapter17;

import java.util.Arrays;
import java.util.List;

public class ArraysTest {

	public static void main(String[] args) {

		int iArray[] = {50,40,30,20,10};
		String sArray[] = new String[5];
		
		System.out.println(Arrays.toString(iArray));
		//오름차순 정렬
		Arrays.sort(iArray);
		System.out.println(Arrays.toString(iArray));
		
		sArray[0] = "Miss";
		//fill을 사용하면 전부 덮어씌움
		Arrays.fill(sArray, "Good");
		System.out.println(Arrays.toString(sArray));
		
		List<String> city = Arrays.asList("서울", "인천", "부산","대구","대전");
		for (int i = 0; i < city.size(); i++) {
			System.out.println(city.get(i));
		}
		
		
		
		
		
	}

}
