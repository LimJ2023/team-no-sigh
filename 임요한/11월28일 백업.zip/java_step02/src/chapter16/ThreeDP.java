package chapter16;

public class ThreeDP {

	public static void main(String[] args) {

		Plastic pl = new Plastic();
		pl.doPrinting();
		
		Powder pw = new Powder();
		pw.doPrinting();
	}

}
