package chapter16;

public abstract class Material2 {
	
	abstract void doPrinting();
}
