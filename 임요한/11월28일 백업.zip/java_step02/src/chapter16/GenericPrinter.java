package chapter16;

public class GenericPrinter <T extends Material2> {
	
	T material;

	public T getMaterial() {
		return material;
	}

	public void setMaterial(T material) {
		this.material = material;
	}
	
	public void printing() {
		
		material.doPrinting();
	}
	
	
}
