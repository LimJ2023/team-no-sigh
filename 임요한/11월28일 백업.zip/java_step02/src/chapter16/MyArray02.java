package chapter16;

class MyarrayG<E>{ // 제네릭 선언
	
	private Object[] array = new Object[10];
	int i;
	
	public void add(Object obj) {
		//제네릭 클래스이므로 어떤 타입 객체도 받을 수 있다.
		array[i++]= obj;
	}
	
	@SuppressWarnings("unchecked")
	public E get(int index) {
		return (E)array[index] ;
	}
	
}

public class MyArray02 {

	public static void main(String[] args) {

		MyarrayG<String> arrG = new MyarrayG<String>();
		MyarrayG<Integer> arrInt = new MyarrayG<>();
		arrG.add(new String("test"));
		String str = arrG.get(0);
		System.out.println(str);
		
		arrInt.add(300);
		int num1 = arrInt.get(0);
		System.out.println(num1);
		
		//Integer num2 = arrG.get(0); 
		//Object와는 다르게 다운캐스팅이 안됨
		//타입의 안정성 상승
		
	}

}
