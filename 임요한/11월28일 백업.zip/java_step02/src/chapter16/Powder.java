package chapter16;

public class Powder extends Material2{
	
	
	public void doPrinting() {
		System.out.println("Powder 재료로 출력합니다.");
	}

	@Override
	public String toString() {
		return "재료는 Powder 입니다.";
	}
}
