package chapter16;

public class GenericPrinterMain {

	public static void main(String[] args) {

		GenericPrinter<Powder> powGen1 = new GenericPrinter<Powder>();
		powGen1.setMaterial(new Powder());
		Powder pow1 = powGen1.getMaterial();
		System.out.println(pow1);
		
		
		GenericPrinter<Plastic> plaGen1 = new GenericPrinter<Plastic>();
		plaGen1.setMaterial(new Plastic());
		Plastic pla1 = plaGen1.getMaterial();
		System.out.println(pla1);
		
		
		powGen1.printing();
		plaGen1.printing();
		
		/*
		 * GenericPrinter<Water> printerWater = new GenericPrinter<Water>();
		 * printerWater.setMaterial(new Water());
		 * System.out.println(printerWater.getMaterial());
		 */
		
	}

}
