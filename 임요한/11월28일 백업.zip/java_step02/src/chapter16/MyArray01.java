package chapter16;


class MyArray{
	//Object : 호환성 좋음
	
	private Object[] array = new Object[10];
	int i;
	
	public void add(Object obj) {
		array[i++]= obj;
	}
	
	public Object get(int index) {
		return array[index];
	}
	
	
}



public class MyArray01 {

	public static void main(String[] args) {

		MyArray myArray01 = new MyArray();
		myArray01.add(new String("test"));
		String str = (String) myArray01.get(0);
		Object str2 = myArray01.get(0);
		System.out.println(str);
		System.out.println(str2);
		
		// 다운캐스팅시 발생하는 문제가 있음
		/*
		 * Integer num1 = (Integer)myArray01.get(0); System.out.println(num1);
		 */
		
		MyArray myArray02 = new MyArray();
		myArray02.add(100);
		Integer num = (Integer) myArray02.get(0);
		System.out.println(num);
		
		//Object 타입 안전성 떨어짐
		
	}

}
