package chapter16;

public class ThreeDPinterMain {

	public static void main(String[] args) {

		ThreeDPrinter prntPowder = new ThreeDPrinter();
		Powder p1 = new Powder();
		
		prntPowder.setMaterial(p1);
		System.out.println(prntPowder.getMaterial());
		
		//다운캐스팅
		Powder p2 = (Powder)prntPowder.getMaterial();
		System.out.println(p2);
		
		ThreeDPrinter prntPlastic = new ThreeDPrinter();
		
		Plastic p3 = new Plastic();
		prntPlastic.setMaterial(p3);
		System.out.println(prntPlastic.getMaterial());
		
		
		
		//다운캐스팅 이슈 확인
		ThreeDPrinter printerPla2 = new ThreeDPrinter();
		Plastic mate1 = new Plastic();
		Powder mate2 = new Powder();
		
		printerPla2.setMaterial(mate1);
		printerPla2.setMaterial(mate2);
		System.out.println(mate2);
		
		
	}

}
