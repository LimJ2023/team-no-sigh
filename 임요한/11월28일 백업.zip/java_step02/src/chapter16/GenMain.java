package chapter16;

public class GenMain {

	public static void main(String[] args) {

		Gen<Integer> intGen = new Gen<Integer>();
		Gen<Double> dbleGen = new Gen<Double>();
		Gen<Character> charGen = new Gen<Character>();
		
		Integer[] iArr = {1,2,3,4,5};
		Double[] dArr = {1.1,2.2,3.3,4.4,5.5};
		Character[]	cArr = {'A','B','C','D','E'};
		
		intGen.printArr(iArr);
		dbleGen.printArr(dArr);
		charGen.printArr(cArr);
		charGen.printArr(cArr);
		
		System.out.println();
		
	}

}
