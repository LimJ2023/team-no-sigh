package chapter16;

public class GenExMain {

	public static void main(String[] args) {

		GenEx<String> v1 = new GenEx<String>();
		
		v1.setValue("100");
		System.out.println(v1.getValue());
		
		GenEx<Integer> v2 = new GenEx<Integer>();
		
		v2.setValue(100);
		System.out.println(v2.getValue());
		
		GenEx<Double> v3 = new GenEx<Double>();
		
		v3.setValue(123.1);
		System.out.println(v3.getValue());
		
		GenEx<Character> v4 = new GenEx<Character>();
		
		v4.setValue('A');
		System.out.println(v4.getValue());
		
	}

}
