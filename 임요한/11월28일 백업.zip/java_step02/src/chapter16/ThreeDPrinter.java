package chapter16;

public class ThreeDPrinter {
	
	private Object material; // 재료

	
	
	public Object getMaterial() {
		return material;
	}

	public void setMaterial(Object material) {
		this.material = material;
	}

	@Override
	public String toString() {
		return super.toString();
	}
	
	
}
