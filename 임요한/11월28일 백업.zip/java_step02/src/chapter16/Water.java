package chapter16;

public class Water {
	
	public void doPrinting() {
		System.out.println("물 재료는 불가능합니다..");
	}

	@Override
	public String toString() {
		return "재료는 Water 입니다.";
	}
	
}
