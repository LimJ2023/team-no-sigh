package chapter09;

public class ChildMain {

	public static void main(String[] args) {

		Child child = new Child();
		
		//부모 메서드
		child.method1();
		//오버라이딩 메서드
		child.method2();
		//자식 메서드
		child.method3();
		
		System.out.println();
		Parent parent2 = child; // 업 캐스팅
		//부모 메서드
		parent2.method1();
		//오버라이딩 된 메서드
		parent2.method2();
		
		Parent parent1 = new Parent();
		parent1.method1();
		parent1.method2();
	}

}
