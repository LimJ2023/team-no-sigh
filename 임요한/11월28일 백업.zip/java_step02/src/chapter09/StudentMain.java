package chapter09;

public class StudentMain {

	public static void main(String[] args) {

		Student stdLim = new Student("임요한", "3920-7972", 100);
		System.out.println("이름 : "+ stdLim.name);
		System.out.println("번호 : "+ stdLim.phone);
		System.out.println("학번 : "+ stdLim.studentNo);
		
	}

}
