package chapter09;

public class DmbCellPhoneMain {
	public static void main(String[] args) {
		
		DmbCellPhone dmbPhone = new DmbCellPhone("java폰","검정",11);
		
		//상속받은 필드
		System.out.println("모델 : " + dmbPhone.model);
		System.out.println("색상 : " + dmbPhone.color);
		//자신의 필드
		System.out.println("채널 : " + dmbPhone.channel);
		//부모클래스의 메서드를 사용하기
		
		dmbPhone.powerOn();
		dmbPhone.bell();
		dmbPhone.sendVoice("여보세요");
		dmbPhone.receiveVoice("나야 나");
		dmbPhone.sendVoice("?");
		dmbPhone.hangUP();
		
		//자식클래스의 메서드 이용하기
		dmbPhone.turnOnDmb();
		dmbPhone.changeChannelDmb(100);
		dmbPhone.turnOffDmb();
	}
}
