package chapter09;

public class SportCar extends Car{

	
	@Override
	public void speedUp() {
		speed += 10;
		System.out.println("speed : " + speed);
	}

	public static void main(String[] args) {
		
		SportCar car = new SportCar();
		Car car2 = new SportCar(); //업캐스팅
		
		
		
		car.speedUp();
		car.speedUp();
		car.stop();
		
		car2.speedUp();
	}

}
