package chapter09;

public class Student1 {
	
	void display() {
		System.out.println("부모 클래스의 메서드");
	}
}
