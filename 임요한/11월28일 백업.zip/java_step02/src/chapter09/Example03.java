package chapter09;

/*부모 클래스 Pe(Person)과 자식 클래스 Stu(Student), Teacher를 생성
 * Pe 클래스에 이름과 나이를 저장하는 멤버변수와 출력하는 메서드 구현
 * Stu Teacher 클래스에 각각 학번과 과목을 추가로 저장하고 출력하는 메서드 추가
 * 
 * 구현화면 
 * 이름: 홍길동
 * 나이: 12
 * 학번: 12345
 * 
 * 이름: 김선생
 * 나이: 50
 * 담당과목: 수학
 * */



class Pe {
	//멤버변수
	private String name;
	public int age;
	
	//생성자
	public Pe(String name, int age) {
		this.name = name;
		this.age = age;
	}
	//메서드
	public void showInfo() {
		System.out.println("이름: " + name);
		System.out.println("나이: " + age);
	}
}//Pe

class Stu extends Pe {

	int stuNumber;
	//생성자
	public Stu(String name, int age, int stuNumber) {
		super(name, age);
		this.stuNumber = stuNumber;
	}
	//오버라이드 메서드
	@Override
	public void showInfo() {
		super.showInfo();
		System.out.println("학번: " + stuNumber);
	}
}//Stu

class Teacher extends Pe{
	//학번
	public String subject;
	
	//생성자
	public Teacher(String name, int age, String subject) {
		super(name, age);
		this.subject = subject;
	}
	//오버라이드 메서드
	@Override
	public void showInfo() {
		super.showInfo();
		System.out.println("담당과목: " + subject);
	}
}//Teacher

public class Example03{
	public static void main(String[] args) {
		Stu stdHong = new Stu("홍길동", 12, 12345);
		Teacher teaKim = new Teacher("김선생", 50, "수학");
		stdHong.showInfo();
		teaKim.showInfo();
	}//main
}
