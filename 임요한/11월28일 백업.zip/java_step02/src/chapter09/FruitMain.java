package chapter09;

public class FruitMain {

	public static void main(String[] args) {

		StrawBerry strawBerry = new StrawBerry();
		
		strawBerry.Set1("베리류", "겨울");
		strawBerry.Set2("딸기", "특대");
		strawBerry.Set3("빨강", 15000);
		
		strawBerry.Disp1();
	}

}
