package chapter09;
/*책 이름과 책 저자를 멤버변수로 갖는 Book 클래스 생성
 * 이를 출력하는 메서드 구현
 * Book클래스를 상속받는 EBook클래스 생성
 * (String format)과 메서드를 추가
 * 메서드 오버라이딩 가능
 * 구현화면 : 
 * 제목: 위대한 개츠비
 * 저자: 스콧 피츠제럴드
 * 
 * 제목: 앵무새 죽이기
 * 저자: 하퍼 리
 * 형식: PDF
 * */

class Book{
	
	//멤버변수
	public String title;
	public String author;
	
	//생성자
	public Book(String bookName, String author) {
		this.title = bookName;
		this.author = author;
	}
	
	//메서드
	public void showBookInfo() {
		System.out.println("제목 : " + title);
		System.out.println("저자 : " + author);
	}
}//Book

class EBook extends Book{
	//멤버변수
	public String format;
	
	//생성자
	public EBook(String bookName, String author, String format) {
		super(bookName, author);
		this.format = format;
	}

	//오버라이드 한 메서드
	@Override
	public void showBookInfo() {
		super.showBookInfo();
		System.out.println("형식 : " + format);
	}
}//EBook

public class Example02 {
	
	public static void main(String[] args) {
		Book book1 = new Book("위대한 개츠비", "스콧 피츠제럴드");
		EBook book2 = new EBook("앵무새 죽이기", "하퍼 리", "PDF");
		
		book1.showBookInfo();
		book2.showBookInfo();
	}
}
