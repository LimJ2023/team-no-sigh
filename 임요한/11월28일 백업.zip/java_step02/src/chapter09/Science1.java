package chapter09;

public class Science1 extends Student1{
	
	void show() {
		System.out.println("자식 클래스의 메서드");
	}

	@Override
	void display() {
		System.out.println("상속받은 메서드를 오버라이딩 (재정의)");
	}
	
	
	
}
