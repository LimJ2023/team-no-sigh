package chapter09;

public class PaChMain {

	public static void main(String[] args) {

		Pa pa = new Pa();
		Ch ch = new Ch();
		
		pa.display();
		ch.show();
		ch.display();
		
		//Pa pa2 = new Ch(); 
		//묵시적 업캐스팅
		//ch의 재정의 된 메서드 호출(만든 객체가 ch니까)
		//pa2.display();
	}
	

}
