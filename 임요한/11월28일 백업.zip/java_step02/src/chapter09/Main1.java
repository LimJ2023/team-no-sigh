package chapter09;

public class Main1 {

	public static void main(String[] args) {
		
		Student1 std1 = new Student1();
		Science1 std2 = new Science1();
		std1.display();
		std2.show();
		std2.display();
		
		Student1 std3 = new Science1(); 
		//객체는 Science1으로 생성
		//즉 재정의 된 display를 호출하게 됨
		std3.display();
	}

}
