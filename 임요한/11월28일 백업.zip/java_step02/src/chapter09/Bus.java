package chapter09;

public class Bus extends Vehicle{

	@Override
	void start() {
		super.start();//부모 클래스 메서드 호출
		System.out.println("버스 운전 시작.");
		
	}
	
	
}
