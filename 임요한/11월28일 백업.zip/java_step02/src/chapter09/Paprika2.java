package chapter09;

public class Paprika2 extends Paprika{
	String name;
	
	public void show(String a) {
		name = a;
		System.out.println(name);
		System.out.println(super.name);
		System.out.println();
	}
}
