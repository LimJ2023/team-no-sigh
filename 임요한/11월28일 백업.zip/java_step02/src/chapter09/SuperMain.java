package chapter09;

public class SuperMain {

	public static void main(String[] args) {
		
		Paprika paprika = new Paprika();
		Paprika2 pa2 = new Paprika2();
		
		
		paprika.Set1("고추과", "여름", "파프리카");//부모
		paprika.Set2("빨강",2000,"빨강 파프리카");//자식
		paprika.Disp1();
		paprika.Disp2();
		
		pa2.show("파프2");
		
	}

}
