package chapter09;

public class Pa {
	
	void display() {
		System.out.println("부모 클래스의 메서드");
	}
	
}
