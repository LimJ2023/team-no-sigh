package chapter09;

public class ChildExam extends ParentExam{
	
	private String car = "벤츠";

	
	@Override
	public int getMoney() {
		//super.setMoney(50000);
		return super.getMoney();
	}

	@Override
	public String getStr() {
		//super.setStr("종로 더블 코아");
		return super.getStr();
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}
	
	
}
