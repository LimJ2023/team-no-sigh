package chapter09;

public class RideMain {

	public static void main(String[] args) {
		
		Bus bus = new Bus();
		
		bus.start();
	}

}
