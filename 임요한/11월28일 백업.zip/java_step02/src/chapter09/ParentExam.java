package chapter09;

public class ParentExam {
	
	private int money = 20000; //부모 재산
	private String str = "코아빌딩"; // 부모 부동산
	
	
	//게터 세터
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getStr() {
		return str;
	}
	public void setStr(String str) {
		this.str = str;
	}
}
