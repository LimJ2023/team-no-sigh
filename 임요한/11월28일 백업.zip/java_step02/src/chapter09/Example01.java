package chapter09;
/*Shape 클래스를 상속받는 Circle, Square만들기
 * draw 메서드 오버라이딩
 * "그림을 그립니다." "원을 그립니다" "네모를 그립니다." 를 출력
 * */

class Shape {
	
	public void draw() {
		System.out.println("그림을 그립니다.");
	}
}//Shape
class Circle extends Shape {

	@Override
	public void draw() {
		System.out.println("원을 그립니다.");
	}
}//Circle
class Square extends Shape{

	@Override
	public void draw() {
		System.out.println("네모를 그립니다.");
	}
}//Square

class Nemo extends Shape{

	@Override
	public void draw() {
		System.out.println("네모를 그립니다.2");
	}
}

public class Example01 {
	
}
