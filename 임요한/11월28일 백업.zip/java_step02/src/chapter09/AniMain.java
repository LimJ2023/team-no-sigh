package chapter09;

public class AniMain {

	public static void main(String[] args) {
		
		Ani animal = new Ani();
		Dog dog = new Dog();
		Ani animal2 = new Dog();
		
		animal.makeSound();
		dog.makeSound();
		animal2.makeSound();
	}
}
