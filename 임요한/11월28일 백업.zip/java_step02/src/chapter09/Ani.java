package chapter09;

public class Ani {
	
	void makeSound() {
		System.out.println("Some sound");
	}
}


class Dog extends Ani{

	@Override
	void makeSound() {
		
		//super.makeSound();
		System.out.println("멍멍!");
	}

	
}
