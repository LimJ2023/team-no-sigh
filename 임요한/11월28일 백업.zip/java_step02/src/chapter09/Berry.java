package chapter09;

public class Berry extends Fruit{
	
	private String name;
	private String size;
	
	public void Set2(String a, String b) {
		name = a;
		size = b;
	}
	
	public void Disp2() {
		System.out.println("이름 : " + name);
		System.out.println("크기 : " + size);
	}

	@Override
	public void Disp1() {
		// TODO Auto-generated method stub
		super.Disp1();
		System.out.println("이름 : " + name);
		System.out.println("크기 : " + size);
	}
	
	
	
}
