package chapter09;

public class Car {
	
	public int speed;
	
	public void speedUp() {
		speed++;
		System.out.println("speed : " + speed);
	}
	
	//final 메서드는 재정의 불가.
	public final void stop() {
		System.out.println("자동차가 멈춥니다.");
		speed = 0;
	}
}
