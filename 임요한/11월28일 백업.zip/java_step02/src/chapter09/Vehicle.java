package chapter09;

public class Vehicle {
	
	void start() {
		System.out.println("차량 시동을 켭니다.");
	}
	
}
