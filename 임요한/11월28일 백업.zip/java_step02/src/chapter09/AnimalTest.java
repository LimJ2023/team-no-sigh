package chapter09;


public class AnimalTest{
	public static void main(String[] args) {
			
		AnimalTest aTest = new AnimalTest();
		aTest.moveAnimal(new Human());
		aTest.moveAnimal(new Tiger());
		aTest.moveAnimal(new Eagle());
		
	}
	public void moveAnimal(Animal2 ani) {
		ani.move();
	}
}

class Animal2{
	public void move() {
		System.out.println("동물이 움직입니다.");
	}
}

class Human extends Animal2{

	@Override
	public void move() {
		System.out.println("사람은 두발로 걷습니다.");
	}
	public void readBook() {
		System.out.println("사람은 책을 읽습니다.");
	}
}

class Tiger extends Animal2{

	@Override
	public void move() {
		System.out.println("호랑이가 네 발로 걷습니다.");
	}
	public void hunting() {
		System.out.println("호랑이는 사냥을 합니다.");
	}
	
}

class Eagle extends Animal2{

	@Override
	public void move() {
		System.out.println("독수리가 하늘을 납니다.");
	}
	public void flying() {
		System.out.println("독수리는 날개로 날아다닙니다.");
	}
	
}
