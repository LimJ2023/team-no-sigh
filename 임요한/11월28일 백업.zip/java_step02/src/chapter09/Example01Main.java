package chapter09;

public class Example01Main {

	public static void main(String[] args) {
		Shape shape = new Shape();
		Circle circle = new Circle();
		Square square = new Square();
		
		shape.draw();
		circle.draw();
		square.draw();
		
		//Shape타입으로 하위클래스 생성 되는지 확인
		Shape shape2 = new Shape();
		Shape shape3 = new Circle();
		Shape shape4 = new Square();
		
		shape2.draw();
		shape3.draw();
		shape4.draw();
	}//main

}
