package chapter09;

public class Student extends People{

	public int studentNo;

	public Student(String name, String phone, int studentNo) {
		super(name, phone); //상위 클래스인 People생성자를 호출.
		this.studentNo = studentNo;
	}
	
	
	
}
