package chapter09;

public class ChildExamMain {

	public static void main(String[] args) {

		ChildExam c1 = new ChildExam();
		
		System.out.println(c1.getMoney());
		System.out.println(c1.getStr());
		System.out.println(c1.getCar());
		
		
		System.out.println();
		
		ChildExam c2 = new ChildExam();
		ParentExam p1 = new ParentExam();
		
		c2.setMoney(80000);
		p1.setMoney(70000);
		
		System.out.println(p1.getMoney());
		System.out.println(p1.getStr());
		
		p1 = c2;
		System.out.println(p1.getMoney());
		System.out.println(p1.getStr());
		
		
	}

}
