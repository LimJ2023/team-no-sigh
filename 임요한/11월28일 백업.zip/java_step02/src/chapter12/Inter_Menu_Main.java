package chapter12;

public class Inter_Menu_Main implements Inter_Menu3{

	

	@Override
	public String jajang() {
		

		return "짜장면";
	}

	@Override
	public String jjambbong() {
		

		return "짬뽕";
	}

	@Override
	public String tangsuyug() {
		

		return "탕수육";
	}

	@Override
	public String boggembab() {
		

		return "볶음밥";
	}
	
	public static void main(String[] args) {
	
		Inter_Menu_Main menu = new Inter_Menu_Main();
		
		menu.jajang(); //menu1
		menu.jjambbong(); //menu1
		menu.tangsuyug(); //menu2
		menu.boggembab(); //menu3
		
		Inter_Menu1 im1 = menu;
		Inter_Menu2 im2 = menu;
		Inter_Menu3 im3 = menu;
		System.out.println("메뉴 1");
		im1.jajang();
		im1.jjambbong();
		im1.show();
		System.out.println("메뉴 2");
		im2.tangsuyug();
		//im2.show(); //menu1을 상속받지 못해 불가.
		
		System.out.println("메뉴 3");
		im3.boggembab();
		im3.show();
	}

}
