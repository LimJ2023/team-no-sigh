package chapter12;

public class Printer implements Printable{

	@Override
	public void print() {
		System.out.println("프린터로 출력합니다.");
	}
}//Printer
