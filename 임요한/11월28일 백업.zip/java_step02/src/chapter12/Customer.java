package chapter12;

public class Customer implements Buy, Sell{

	@Override
	public void sell() {
		System.out.println("물건 판매");
		
	}

	@Override
	public void buy() {
		System.out.println("물건 구매");
		
	}

	//같은 메서드명이 존재하면 오버라이딩 필수
	@Override
	public void order() {
		System.out.println("고객 판매 주문");
	}
}
