package chapter12;


/* Flyable, Animal 인터페이스를 각각 정의
 * Flyable : takeOff(), land() 추상메서드 생성
 * Animal : eat(), sleep() 추상메서드 생성
 * 
 * airplane 클래스와 Bird 클래스를 작성
 * Airplane 클래스는 Flyable 인터페이스를 구현,
 * Bird 클래스는 Flyable,Animal을 동시에 구현
 * 
 * AnimalMain에서 메서드를 구현하여  동작을 출력.
 * */
public interface Flyable {
	
	void takeOff();
	void land();
}

interface Animal{
	void eat();
	void sleep();
}//Flyable

class Airplane implements Flyable {

	@Override
	public void takeOff() {
		System.out.println("비행기가 이륙 합니다.");
		
	}

	@Override
	public void land() {
		System.out.println("비행기가 착륙 합니다.");
	}
	
	
	final public void airplaneprocess(){
		takeOff();
		land();
	}
	
}//Airplane

class Bird implements Flyable, Animal {

	@Override
	public void eat() {
		System.out.println("새가 음식을 먹습니다.");
		
	}

	@Override
	public void sleep() {
		System.out.println("새가 잠을 잡니다.");
		
	}

	@Override
	public void takeOff() {
		System.out.println("새가 날아오릅니다.");
		
	}

	@Override
	public void land() {
		System.out.println("새가 땅으로 내려옵니다.");
		
	}
	
	final public void birdprocess(){
		eat();
		takeOff();
		land();
		sleep();
	}
}//Bird

