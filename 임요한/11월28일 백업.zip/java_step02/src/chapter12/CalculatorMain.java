package chapter12;

public class CalculatorMain {

	public static void main(String[] args) {

		int num1 = 10, num2 = 5;
		
		// 인터페이스 타입의 참조변수로 
		// CompleteCalc2(하위 클래스)의 객체를 참조
		Calc calc = new CompleteCalc2(); 
		
		System.out.println("-----디폴트 메서드 호출-----");
		calc.description();
		System.out.println("-----스태틱 메서드 호출-----");
		int[] arr = {1,2,3,4,5 };
		System.out.println("1~5까지의 합 : " + Calc.total(arr));
		
		System.out.println("-----인터페이스 메서드 호출-----");
		System.out.println("더하기 " +calc.add(num1, num2));
		System.out.println("빼기 " +calc.minus(num1, num2));
		System.out.println("곱하기 " +calc.muliply(num1, num2));
		System.out.println("나누기 " +calc.divide(num1, num2));
		System.out.println();
		
		//CompleteCalc2에서 새로 만든 메서드를 호출하는 방법
		CompleteCalc2 calc2 = new CompleteCalc2();
		calc2.showInfo();
	}

}
