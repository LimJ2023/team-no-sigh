package chapter12;

public interface InterTest1 {
	
	//public static final int A = 100;
	//final 선언시 public static 자동생성해줌
	final int A = 100; 
	
	//public abstract int getA(); 
	// 추상 메서드의 선언을 생략 가능. (인터페이스이기 떄문)
	int getA();
}
