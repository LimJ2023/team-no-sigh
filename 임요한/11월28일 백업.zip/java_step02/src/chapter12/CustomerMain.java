package chapter12;

public class CustomerMain {

	public static void main(String[] args) {

		Customer customer = new Customer();
		
		System.out.println("===========Buy============");
		Buy buyer = customer;
		buyer.buy();
		buyer.order();
		
		System.out.println("===========Buy============");
		Sell seller = customer;
		seller.sell();
		seller.order();
		
		System.out.println(buyer == customer);
		System.out.println(seller == customer);
		System.out.println(buyer == seller);
		
	}

}
