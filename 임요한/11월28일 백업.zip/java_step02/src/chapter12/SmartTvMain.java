package chapter12;

public class SmartTvMain {

	public static void main(String[] args) {

		SmartTv tv = new SmartTv();
		
		tv.turnOn();
		tv.setVolume(10);
		tv.turnOff();
		tv.search("네이버");
		System.out.println("=================");
		
		Remote rc = tv;
		rc.turnOn();
		rc.setVolume(10);
		rc.turnOff();
		// search() 함수 호출 불가능( Remote 타입이 되었으므로)
		
		//인터페이스Searchable의 형태로 참조. search()메서드만 호출가능
		Searchable sc = tv;
		sc.search("구글");
	}

}
