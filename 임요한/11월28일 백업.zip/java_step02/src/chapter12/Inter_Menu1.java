package chapter12;

public interface Inter_Menu1 {
	
	abstract String jajang();
	String jjambbong();
	
	default void show() {
		System.out.println("메뉴판!");
	}
	
}
