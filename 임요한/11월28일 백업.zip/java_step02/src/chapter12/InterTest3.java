package chapter12;

public class InterTest3 implements InterTest1{

	@Override
	public int getA() {
		//인터페이스에서 생성한 상수는 
		//구현 클래스에서 클래스명 없이 바로 접근 가능.
		return A;
	}

}
