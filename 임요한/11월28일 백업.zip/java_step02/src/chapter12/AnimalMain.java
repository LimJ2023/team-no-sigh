package chapter12;

public class AnimalMain {

	public static void main(String[] args) {
		
		Airplane ap = new Airplane();
		ap.airplaneprocess();
		
		System.out.println("========");
		Bird bird = new Bird();
		bird.birdprocess();

	}//main
}
