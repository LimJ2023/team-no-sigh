package chapter12;

public class Screen implements Printable{

	@Override
	public void print() {
		System.out.println("스크린에 보이게 합니다.");
	}

}//Screen
