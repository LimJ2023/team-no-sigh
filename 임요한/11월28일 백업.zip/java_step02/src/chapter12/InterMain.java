package chapter12;

public class InterMain {

	public static void main(String[] args) {

		//인터페이스는 생성 불가
		//InterTest1 it = new InterTest1();
		
		InterTest2 it = new InterTest2();
		System.out.println(it.getA());
		//인터페이스에서 상수 바로 접근 가능
		System.out.println(InterTest1.A);
	}

}
