package chapter12;

public class SmartTv implements Searchable, Remote {

	private int volume;

	@Override
	public void turnOn() {
		System.out.println("전원을 켭니다.");

	}

	@Override
	public void turnOff() {
		System.out.println("전원을 끕니다.");
	}

	@Override
	public void setVolume(int volume) {
		this.volume = volume;
		System.out.println("볼륨은 " + this.volume);
	}

	@Override
	public void search(String url) {
		System.out.println(url + "을 찾음");
	}
}
