package chapter12;

import java.util.Scanner;

public class SchedulerMain {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		// R L P
        System.out.println("전화 상담 배분 방식을 선택 R, L, P");
        char ch = scan.next().charAt(0);

        Scheduler scheduler = null;

        if( ch == 'R' || ch == 'r') {
            scheduler = new RoundRobin();
        }
        else if ( ch == 'L' || ch == 'l') {
            scheduler = new LeastJob();
        }
        else if ( ch == 'P' || ch == 'p') {
            scheduler = new PriorityAllocation();
        }
        else {
            System.out.println("지원하지 않는 기능입니다.");
            scan.close();
            return;
        }
        
        scheduler.getNextCall();
        scheduler.sendCallToAgent();
        
        scan.close();
	}//main

}
