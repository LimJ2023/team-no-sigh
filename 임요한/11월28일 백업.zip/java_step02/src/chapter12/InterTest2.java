package chapter12;

public class InterTest2 implements InterTest1{

	@Override
	public int getA() {
		return InterTest1.A; // 인터페이스의 상수에 접근
	}
	
	
}
