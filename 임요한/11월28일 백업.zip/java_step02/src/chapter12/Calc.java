package chapter12;

public interface Calc {
	
	//상수
	double PI = 3.14;
	int ERROR = -999999;
	
	//추상 메서드
	int add(int num1, int num2);
	int minus(int num1, int num2);
	int muliply(int num1, int num2);
	int divide(int num1, int num2);
	
	//디폴트 메서드
	default void description() {
		System.out.println("정수 계산기를 구현합니다.");
		myMethod();
	}
	static int total(int[] arr) {
		int total = 0;
		for (int i : arr) {
			total += i;
		}
		myStaticMethod();
		return total;
	}
	
	//private 메서드
	private void myMethod() {
		System.out.println("private 메서드");
	}
	
	//static 메서드
	private static void myStaticMethod() {
		System.out.println("private static 메서드");
	}
	
}
