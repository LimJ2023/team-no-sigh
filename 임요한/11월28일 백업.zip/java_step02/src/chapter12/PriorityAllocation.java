package chapter12;

public class PriorityAllocation implements Scheduler{

	@Override
    public void getNextCall() {
        System.out.println("등급 높은 고객을 먼저 받습니다.");
    }

    @Override
    public void sendCallToAgent() {
        System.out.println("업무 skill이 높은 상담원을 대기열 앞에 배분합니다.");
    }
}
