package chapter12;

public class CompleteCalc2 extends CompleteCalc1 {

	@Override
	public int muliply(int num1, int num2) {
		return num1 * num2;
	}

	@Override
	public int divide(int num1, int num2) {
		if(num2 != 0) {
			return num1 / num2;
		}
		else {
			return Calc.ERROR; // 나누는 수가 0일 경우 에러
		}
	}
	
	public void showInfo() {
		System.out.println("Calc 인터페이스를 구현 하였습니다.");
	}

	//디폴트 메서드 재정의
	@Override
	public void description() {
		System.out.println("완성된 계산기 입니다.");
	}
	

}
