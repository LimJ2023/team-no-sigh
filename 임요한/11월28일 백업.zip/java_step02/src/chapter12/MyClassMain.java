package chapter12;

public class MyClassMain {

	public static void main(String[] args) {

		MyClass mClass = new MyClass();
		
		X xClass = mClass;
		Y yClass = mClass;
		MyInterface inter = mClass;
		
		xClass.x();
		yClass.y();
		
		inter.myMethod();
		inter.x();
		inter.y();
		
		mClass.x();
		mClass.y();
		mClass.myMethod();
		
		System.out.println(xClass == mClass);
	}

}
