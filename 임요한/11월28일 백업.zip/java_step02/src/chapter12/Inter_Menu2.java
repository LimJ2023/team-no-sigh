package chapter12;

public interface Inter_Menu2 {
	
	abstract String tangsuyug();
}
