package chapter12;

public class PrinterMain {

	public static void main(String[] args) {
		
		Printable print = new Printer();
		Printable screen = new Screen();

		print.print();
		screen.print();
	}//main
}
