package chapter12;


/*인터페이스는 추상 메서드 print()생성
 * Printer 클래스와 Screen 클래스가 인터페이스를 구현함
 * PrinterMain에서 각각 객체 생성하고 메서드 호출하여 출력
 * */
public interface Printable {
	void print();
}//Printable
