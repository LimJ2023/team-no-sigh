package chapter08_prac;

public class Family {
	private static Family instance = new Family();
	
	public Family() {
		// TODO Auto-generated constructor stub
	}
	
	public static Family getInstance() {
		if(instance == null) {
			instance = new Family();
		}
		return instance;
	}
}
