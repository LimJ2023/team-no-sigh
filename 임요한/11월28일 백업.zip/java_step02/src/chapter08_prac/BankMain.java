package chapter08_prac;

public class BankMain {

	public static void main(String[] args) {
		
		Bank b1 = new Bank("기업1호", "0000-1111");
		
		Bank.interest = 0.2f;
		
		b1.getBank();
		System.out.println("===============");
		
		Bank b2 = new Bank("2호점", "3333-4444");
		b2.getBank();
		System.out.println("==============");
		
		
	}

}
