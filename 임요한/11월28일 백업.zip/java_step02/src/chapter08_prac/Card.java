package chapter08_prac;

public class Card {
	
	private static int cardCounter = 1000;
	private int cardNumber;
	
	//생성자
	public Card() {
		cardNumber = ++cardCounter;
	}
	
	
	//게터 세터
	public static int getCardCounter() {
		return cardCounter;
	}

	
	
	public static void setCardCounter(int cardCounter) {
		Card.cardCounter = cardCounter;
	}

	public int getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(int cardNumber) {
		this.cardNumber = cardNumber;
	}
	
	
}
