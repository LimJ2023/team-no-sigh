package chapter08_prac;

public class StudentMain {

	public static void main(String[] args) {
		Student stdKim = new Student();
		stdKim.setStudentName("김김김");
		System.out.println("이름 : " + stdKim.getStudentName());
		System.out.println("아이디 : " + stdKim.studentID);

		Student stdLee = new Student();
		stdLee.setStudentName("이이이");
		System.out.println("이름 : " + stdLee.getStudentName());
		System.out.println("아이디 : " + stdLee.studentID);

		Student stdPark = new Student();
		stdPark.setStudentName("박박박");
		System.out.println("이름 : " + stdPark.getStudentName());
		System.out.println("아이디 : " + stdPark.studentID);
		
		
	}

}
