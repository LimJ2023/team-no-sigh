package chapter08_prac;

public class Student {
	
	private static int serialNum = 9999;
	int studentID;
	String studentName;
	int grade;
	String address;
	
	//생성자
	public Student() {
		serialNum++;
		this.studentID = serialNum;
	}

	
	//게터 세터
	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
}
