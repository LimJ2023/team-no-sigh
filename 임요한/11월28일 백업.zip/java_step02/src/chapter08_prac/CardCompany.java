package chapter08_prac;

public class CardCompany {
	
	//멤버변수
	private static CardCompany instance = new CardCompany();
	public Card card;
	
	//싱글톤 객체 생성 메서드
	public static CardCompany getInstance() {
		if(instance == null) {
			instance = new CardCompany();
		}
		return instance;
	}
	
	public Card issueCard() {
		Card card = new Card();
		return card;
	}
	
	public static void main(String[] args) {
		
		CardCompany company1 = CardCompany.getInstance();
		CardCompany company2 = CardCompany.getInstance();
		
		Card card1 = company1.issueCard();
		Card card2 = company2.issueCard();
		
		System.out.println("카드 번호 : " + card1.getCardNumber());
		System.out.println("카드 번호 : " + card2.getCardNumber());
	}
	
}
