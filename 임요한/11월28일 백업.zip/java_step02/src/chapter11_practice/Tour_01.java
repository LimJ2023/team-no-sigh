package chapter11_practice;

import java.util.Scanner;

public class Tour_01 {
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		Guide_01 guide = new Guide_01();
		
		
	}

}
