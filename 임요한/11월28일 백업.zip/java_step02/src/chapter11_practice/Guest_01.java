package chapter11_practice;

public class Guest_01 {
	
	//멤버변수
	public String name;
	public String gender;
	
	//생성자
	
	// 목적지 가져오기
	public String getPoint() { 
		return Guide_01.point;
	}

	public Guest_01(String name, String gender) {
		this.name = name;
		this.gender = gender;
	}
	
}
