package chapter11_practice;


public class Guide_01 {
	
	static public String point = "호주"; // 목적지
	Guest_01[] guests;
	
	
	//관광객 수 입력
	public void inputGeustNumber(int num) {
		guests = new Guest_01[num];
	}
	
	//관광객 정보 입력
	public void RegesterGeust(int num, String name, String gender) {
			guests[num] = new Guest_01(name, gender);
	}
	
	//관광객 정보
		public void showGuestInfo() { 
			for (int i = 0; i < guests.length; i++) {
				System.out.println((i+1)  + ". 이름 : " + guests[i].name);
				System.out.println((i+1)  + ". 성별 : " + guests[i].gender);
				System.out.println((i+1)  + ". 목적지 : " + point);
				if(i != guests.length - 1)
					System.out.println("--------------------------------------");
			}
			System.out.println("========================================");
		}
	
	
	
}
