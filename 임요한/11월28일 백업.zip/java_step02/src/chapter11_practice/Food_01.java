package chapter11_practice;

public class Food_01 {
	
	
	
}
