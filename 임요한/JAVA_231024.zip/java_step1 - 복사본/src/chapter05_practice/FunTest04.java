package chapter05_practice;

public class FunTest04 {
	
	public String channel;
	public int channelInt;
	public int volume;
	
	public FunTest04() {
		
	}
	
	public void channelUp(int volume) {
		System.out.println("소리를 " + volume + "만큼 올립니다.");
	}
	public void channelDown(int volume) {
		System.out.println("소리를 " + volume + "만큼  내립니다.");
	}
	
	public void channelChange(String channel) {
		System.out.println("tv 채널을 " + channel + "로 바꿉니다.");
	}
	public void channelChange(int channelInt) {
		System.out.println("채널을 " + channel + "로 바꿉니다.");
	}
	
	public static void main(String[] args) {
		
		
		FunTest04 tv = new FunTest04();
		
		tv.channelUp(3);
		tv.channelDown(4);
		
		tv.channelChange(100);
		tv.channelChange("ebs");
	}

}
