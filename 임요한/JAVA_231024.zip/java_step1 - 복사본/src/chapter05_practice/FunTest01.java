package chapter05_practice;

import javax.swing.JOptionPane;

public class FunTest01 {

	
	public static void sum(int num1, int num2) {
		int total = num1 + num2;
		System.out.println(total);
	}
	
	
	
	public static void main(String[] args) {

		int a,b;
		a = Integer.parseInt(JOptionPane.showInputDialog("값1"));
		b = Integer.parseInt(JOptionPane.showInputDialog("값2"));
		
		sum(a,b);
	}

}
