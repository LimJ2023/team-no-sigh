package chapter05_practice;

public class FunTest05 {

	
	
	public static void Edustep(int edu) {
		
		if(edu == 1) {
			System.out.println("현재 스터디 단계는 step1입니다.");
		}else if (edu == 2) {
			System.out.println("현재 스터디 단계는 step" + edu + "입니다.");
		}else if (edu == 3) {
			System.out.println("현재 스터디 단계는 step" + edu + "입니다.");
		}else {
			System.out.println("해당하는 스터디 단계가 없습니다.");
		}
	}
	
	public static void main(String[] args) {
		int number = 2;
		
		Edustep(number);
	}
}
