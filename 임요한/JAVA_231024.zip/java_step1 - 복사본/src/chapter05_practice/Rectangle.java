package chapter05_practice;

public class Rectangle {
	
	public int calculateArea(int width, int height) {
		return width * height;
	}
	public int calculateArea(int length) {
		return length * length;
	}
	
	public static void main(String[] args) {
		Rectangle cal = new Rectangle();
		
		int result = cal.calculateArea(10,5);
		int result2 = cal.calculateArea(30);
		
		System.out.println("사각형 넓이 계산 : " + result);
		System.out.println("사각형 넓이 계산2 : " + result2);
	}
	
	
}
