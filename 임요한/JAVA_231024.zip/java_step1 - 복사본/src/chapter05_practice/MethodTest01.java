package chapter05_practice;

public class MethodTest01 {

	public static void main(String[] args) {
		
		printHello();
	}
	
	public static void printHello() {
		System.out.println("Hello World");
	}

}
