package chapter05_practice;

import java.lang.reflect.Array;

public class FunTest03 {

	
	public static void swap(int x, int y) {
		int temp = x;
		x = y;
		y = temp;
		System.out.println("swap() 결과 값 x : " + x + " y : " + y);
	}
	public static void swap2(Array arr, int x, int y) {
		int temp = x;
		x = y;
		y = temp;
		System.out.println("swap() 결과 값 x : " + x + " y : " + y);
	}
	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		System.out.println("swap 호출 전 a,b = " + a + ", " + b);
		System.out.println("===========================");
		
		swap(a, b);
		System.out.println("==========================");
		System.out.println("swap 호출 후 : a : " + a + " b : " + b);
		
		int[] arr = new int[2];
		arr[0] = a;
		arr[1] = b;
		
		System.out.println(arr[0] + " " + arr[1]);
		swap(arr[0], arr[1]);	
		System.out.println(arr[0] + " " + arr[1]);
				
		
	}

}
