package chapter05_practice;

public class Car {
	
	//멤버 변수 = 필드
	String carName;
	String carColor;
	int carNumber = 01;
	
	boolean isCre;
	
	//메서드
	public void showCarInfo() {
		System.out.println(carName + "," + carColor);
	}

	public String getCarName() {
		return carName;
	}

	public void setCarName(String carName) {
		this.carName = carName;
	}

	public String getCarColor() {
		return carColor;
	}

	public void setCarColor(String carColor) {
		this.carColor = carColor;
	}

	public int getCarNumber() {
		return carNumber;
	}

	public void setCarNumber(int carNumber) {
		this.carNumber = carNumber;
	}
	
	

}
