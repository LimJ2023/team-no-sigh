package chapter05_practice;

import javax.swing.JOptionPane;

public class star_Test1 {

	public static void main(String[] args) {
		
		
		//System.out.println("홀수를 입력해주세요.");
		int num = Integer.parseInt(JOptionPane.showInputDialog("홀수 입력"));
		
		for (int i = 1; i <= num; i++) { // 마름모 위쪽
			for (int j = 0; j < num-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2*i) - 1; j++) {
				System.out.print("*");
			}System.out.println();
		}
		
		for (int i = num-1; i > 0; i--) { // 마름모 아래쪽
			for (int j = 0; j < num-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2*i) - 1; j++) {
				System.out.print("*");
			}System.out.println();
		}
	}

}
