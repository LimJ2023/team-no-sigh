package chapter05_practice;

public class CarMain {

	
	String carName;
	String carColor;
	int carNumber;
	
	public String getCarName() {
		return carName;
	}
	public static void main(String[] args) {

		//참조 변수 : 힙 메모리에 할당된 객체가 저장되어 있는
		// 주소를 가진 변수.
		Car myCar = new Car();
		
		myCar.carName = "k5";
		myCar.setCarName("차1");
		
		System.out.println("멤버 변수를 호출 : " + myCar.carName);
		System.out.println("게터 메소드를 호출 : " + myCar.getCarName());
	}

}
