package chapter05_practice;

public class FunTest_Overloading {
	
	//오버로딩 : 메서드를 정의할 때 사용
	// 메서드명은 같지만 메서드의 매개변수 종류, 개수를 다르게하여 구현
	public void getResult(int n) {
		System.out.println(n + "는 int 입니다.");
	}
	public void getResult(String n) {
		System.out.println(n + "는 String 입니다.");
	}
	public void getResult(char n) {
		System.out.println(n + "는 char 입니다.");
	}
	public void getResult(int n, String str) {
		System.out.println(n + "는 int 입니다." + str + "은 String 입니다.");
	}
}
