package chapter05_practice;

import javax.swing.JOptionPane;

public class FunTest02 {

	
	public void sum(int num1, int num2) {
		int total = num1 + num2;
		System.out.println(total);
	}
	public static void main(String[] args) {

		int a, b;
		a = Integer.parseInt(JOptionPane.showInputDialog("값1"));
		b = Integer.parseInt(JOptionPane.showInputDialog("값2"));
		
		FunTest02 obj = new FunTest02();
		obj.sum(3, 5);
	}

}
