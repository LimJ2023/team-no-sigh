package chapter05_practice;

public class MethodTest05 {
	
	public static int add(int a, int b) {
		return a + b;
	}
	public static int subtract(int a, int b) {
		return a - b;
	}
	public static int multiply(int a, int b) {
		return a * b;
	}
	public static double divide(double a, double b) {
		return a / b;
	}
	
	public static void main(String[] args) {
		
		int add = add(3, 5);
		System.out.println(add);
		System.out.println(subtract(2, 4));
		System.out.println(multiply(8, 7));
		System.out.println(divide(10, 5));
	}
	
}
