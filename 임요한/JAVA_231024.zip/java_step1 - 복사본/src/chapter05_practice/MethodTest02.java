package chapter05_practice;

public class MethodTest02 {

	public static void main(String[] args) {
		
		greet("임요한");
		String name = "Alice";
		greet(name);
	}
	
	
	public static void greet(String name) {
		System.out.println("hello" + name + "!");
	}

}
