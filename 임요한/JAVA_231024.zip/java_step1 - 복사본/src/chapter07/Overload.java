package chapter07;

public class Overload {
	
	
	private String name;
	private int age;
	private float height;
	
	public Overload() {
		name = "익명";
		age= 40;
		height = 180;
	}
	
	public  Overload(int a, float ki) {
		name = "익명";
		age = a;
		height = ki;
	}
	public  Overload(int a, float ki, String n) {
		name = n;
		age = a;
		height = ki;
	}
	
	public void display() {
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("키 : " + height);
	}
	
	
	
	
}
