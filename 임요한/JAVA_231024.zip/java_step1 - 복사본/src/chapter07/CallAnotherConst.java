package chapter07;

class Person2{
	
	String name;
	int age;
	
	//생성자 체이닝. 객체 초기화. 
	//기본생성자 호출시 내부에서 2번째 생성자를 호출. 
	//미리정해둔 매개변수 이용.
	public Person2() {
		this("임요한", 30);
	}

	public Person2(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	//자기 객체. 자기자신의 주소 반환
	Person2 returnSelf() {
		return this;
	}
	
}

public class CallAnotherConst {

	
	public static void main(String[] args) {
		
		Person2 p1 = new Person2();//내부에서 두번째 생성자 호출함
		
		System.out.println(p1.name + p1.age);
		System.out.println(p1.returnSelf());
		
		System.out.println("==============");
		
		Person2 p2 = new Person2();
		System.out.println(p2);
		
		System.out.println("==============");
		
		//p1과 p3이 동일한 객체를 참조중.
		Person2 p3 = p1.returnSelf();
		
		System.out.println(p3);
		
	}

}
