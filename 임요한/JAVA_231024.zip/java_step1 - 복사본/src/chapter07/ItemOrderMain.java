package chapter07;

public class ItemOrderMain {
	
	public static Item[] a = null;
	public Item[] b = null;
	
	public static void main(String[] args) {
		
		//멤버변수 2개받는 객체 생성
		Order order1 = new Order(12345, 231116);
		order1.init();
		order1.outOrder();
		
		//Item 배열 생성
		Item[] items = new Item[4];
		/*items[0] = new Item("음료수", 1000);
		items[1] = new Item("레몬", 2000);
		items[2] = new Item("코코넛", 3000);
		items[3] = new Item("콜라", 1900);*/
		
		//Item의 배열을 멤버변수로 받는 Order 객체 생성
		Order order2 = new Order(543, items, 230101);
		order2.order2();
		//order2.outOrder();
	}
}
