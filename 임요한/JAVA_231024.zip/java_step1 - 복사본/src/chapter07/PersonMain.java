package chapter07;

public class PersonMain {

	public static void main(String[] args) {

		Person p1 = new Person();
		Person p2 = new Person("사람1");
		Person p3 = new Person("사람3", 200, 120);
		
		
		p1.name = "사람0";
		p1.height = 100f;
		p1.weight = 200f;
		
		p2.height = 300;
		p2.weight = 400;
		
		
		System.out.println("이름 : " + p1.name);
		System.out.println("키 : " + p1.height + " 몸무게 : " + p1.weight);
	
		System.out.println("이름 : " + p2.name);
		System.out.println("키 : " + p2.height + " 몸무게 : " + p2.weight);
	
		System.out.println("이름 : " + p3.name);
		System.out.println("키 : " + p3.height + " 몸무게 : " + p3.weight);
	
		
	}

}
