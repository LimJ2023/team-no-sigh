package chapter07;

public class KoreanMain {

	public static void main(String[] args) {
		
		Korean k1 = new Korean("임요한", "2222");
		Korean k2 = new Korean("한국인2", "4444");
		
		System.out.println("nation :" + k1.nation + " 이름 : " + k1.name
				+ " 번호 : " + k1.phone);
		System.out.println("nation :" + k2.nation + " 이름 : " + k2.name
				+ " 번호 : " + k2.phone);
	}

}
