package chapter07;

public class ColorMain {

	public static void main(String[] args) {

		int val = 10; // 변수 val의 타입(자료형)은 int형. val의 밸류(값) = 10
		int red = 5;
		int green = 20;
		int blue = 30; 
		double a;
		
		Color color3 = new Color(blue);// 초기화
		Color color4 = new Color(blue); //
		//변수 color4의 타입(자료형은)은 Color
		
		color3.getColors(); // 호출한다.
		
		Color color1 = new Color(blue); //초기화한다.
		//변수의 한 형태인 참조변수. <- 얘 자체가 값을 가진게 아님... 
		//힙메모리 (창고)에 저장된 Color타입의 생성된 객체가 가진 주소(위치)를 가지고있는 변수. 참조(포인터,ref)
		//만들어진 객체에 접근할 방법이 이거밖에 없어
		
		Color color2 = new Color(red, green, blue);//초기화
		//객체가 생성됐음.
		Color color5 = new Color(30, 40, 50);
		
		
		System.out.println(color1.blue);
		System.out.println(color2.blue);
		System.out.println(color2.green);
		System.out.println(color2.red);
		
		
		
		
		/*
		 * color2.getColors();//호출한다. 부른다. 가져온다...사용한다.. color1.getColors();
		 * System.out.println("======="); color2.getColors();
		 */
		
	}

}
