package chapter07;

public class ChatMessageMain {
	public static void main(String[] args) {
		
		ChatMessage message = new ChatMessage();
		
		message.setSender("나");
		message.setReceiver("옆자리");
		message.setContent("나는짱");
		message.setSendTime("2023-11-16");
		
		System.out.println("보낸사람 : " + message.getSender());
		System.out.println("받는사람 : " + message.getReceiver());
		System.out.println("내용 : " + message.getContent());
		System.out.println("보낸 시간 : " + message.getSendTime());
	}

}
