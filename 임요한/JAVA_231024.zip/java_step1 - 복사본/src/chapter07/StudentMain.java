package chapter07;

public class StudentMain {

	public static void main(String[] args) {
		
		Student stdLim = new Student();
		stdLim.setName("임요한");
		stdLim.setAge(30);
		//System.out.println("이름 : " + stdLim.getName());
		//System.out.println("나이 : " + stdLim.getAge());
		stdLim.showInfo();
		Student stdKim = new Student();
		stdKim.setName("김김김");
		stdKim.setAge(-10);
		//System.out.println("이름 : " + stdKim.getName());
		//System.out.println("나이 : " + stdKim.getAge());
		stdKim.showInfo();
	}

}
