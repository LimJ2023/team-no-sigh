package chapter07;

public class ThisExam {

	//멤버변수
	int day;
	int month;
	int year;
	
	//생성자
	public ThisExam() {
	}
	
	
	public ThisExam(int day, int month, int year) {
		this.day = day;
		this.month = month;
		this.year = year;
	}

	
	//게터,세터
	public int getDay() {
		return day;
	}


	public void setDay(int day) {
		this.day = day;
	}


	public int getMonth() {
		return month;
	}


	public void setMonth(int month) {
		this.month = month;
	}


	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}

	
	public void printThis() {
		System.out.println(this);
	}
		
	public static void main(String[] args) {

		ThisExam birth1 = new ThisExam(16, 11, 2023);
		
		birth1.printThis();//참조변수가 가르키는 주소 반환
		
		System.out.println(birth1.day + "/" + birth1.month + "/" + birth1.year);
		
		System.out.println("===============");
		
		ThisExam birth2 = new ThisExam(16, 11, 2023);
		birth2.printThis();
		System.out.println(birth2.getDay() + "/" + birth2.getMonth() + "/" + birth2.getYear());
		
	}

}
