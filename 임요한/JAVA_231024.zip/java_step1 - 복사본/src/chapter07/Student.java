package chapter07;


/* name, age변수를 private로 선언
 * get 메서드 생성후 이름과 나이 반환, set메서드로 이름 나이 대입
 * 나이가 음수일 경우 유효하지 않은 메세지 출력*/
public class Student {
	
	private String name;
	private int age;
	public boolean isageOk = true;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		if(age < 0) {
			System.out.println("유효하지 않은 나이입니다.");
			isageOk = false;
			
		}else 
			this.age = age;
	}
	
	public void showInfo() {
		if(isageOk) {
			System.out.println("이름 : " + getName());
			System.out.println("나이 : " + getAge());
		}else {
			System.out.println("이름 : " + getName());
		}
	}
}
