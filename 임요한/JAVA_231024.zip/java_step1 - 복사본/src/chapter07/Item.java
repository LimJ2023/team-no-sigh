package chapter07;

public class Item {
	
	//멤버 변수는 private로 itemName,price변수 생성
	private String itemName;
	private int price;
	
	// 생성자 : 모든 멤버변수를 받음
	public Item(String itemName, int price) {

		this.itemName = itemName;
		this.price = price;
	}
	
	//멤버변수 게터
	public String getItemName() {
		return itemName;
	}
	public int getPrice() {
		return price;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
