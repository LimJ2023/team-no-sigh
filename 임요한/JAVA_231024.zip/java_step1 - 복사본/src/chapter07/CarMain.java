package chapter07;

public class CarMain {

	public static void main(String[] args) {

		Car myCar = new Car("검정", 3000);
		
		//멤버변수 직접 접근해서 출력
		System.out.println("차색상 : " +myCar.color + 
				" cc :" + myCar.cc); 
		//메서드 이용하여 출력
		System.out.println("차 색상 : " + myCar.getColor());
		System.out.println("cc : " + myCar.getCc());
	}
}
