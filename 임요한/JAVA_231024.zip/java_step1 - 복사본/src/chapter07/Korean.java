package chapter07;

public class Korean {
	
	String nation = "대한민국";
	String name;
	String phone;
	

	public Korean(String name, String phone) {
		this.name = name;
		this.phone = phone;
	}
	
	
}
