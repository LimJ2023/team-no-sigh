package chapter07;

public class OverloadMain {
	
	
	
	
	
	
	public static void main(String[] args) {
		
		Overload over1 = new Overload();
		over1.display();
		System.out.println("==============");
		Overload over2 = new Overload(10, 100);
		over2.display();
		System.out.println("==============");
		
		Overload over3 = new Overload(20, 200, "사람3");
		over3.display();
		System.out.println("==============");
		
	}

}
