package chapter07;

import java.util.Scanner;

public class Order {
	
	//private 변수, 
	private int orderNumber;
	private Item[] items;
	private int orderDate;
	public String inputMenu;
	
	public void init() { // 아이템들 초기화
		items = new Item[3];
		items[0] = new Item("음료수", 1000);
		items[1] = new Item("레몬", 2000);
		items[2] = new Item("코코넛", 3000);
	}
	
	//모든 멤버변수를 받는 생성자.
	public Order(int orderNumber, Item[] items, int orderDate) {
		this.orderNumber = orderNumber;
		this.items = items;
		this.orderDate = orderDate;
		
	}
	
	//아이템즈를 제외한 멤버변수를 받는 생성자 
	public Order(int orderNumber, int orderDate) {
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
	}
	public void order2() {
		Scanner scan = new Scanner(System.in);
		for (int i = 0; i < items.length; i++) {
			System.out.print("음료 입력 : ");
			inputMenu = scan.nextLine();
			items[i] = new Item(inputMenu, 1000);
			if(inputMenu.equals("")) {
				System.out.println("주문 종료");
				break;
			}
			
		}
		scan.close();
	}

	//주문 목록 제출
	public void outOrder() {
		
		System.out.println("Order Number:" + orderNumber);
		System.out.println("Order Date:" + orderDate);
		System.out.println("====Items====");
		for (int i = 0; i < items.length; i++) {
			System.out.println(items[i].getItemName() + " " + items[i].getPrice() + "원");
		}
	}
}
