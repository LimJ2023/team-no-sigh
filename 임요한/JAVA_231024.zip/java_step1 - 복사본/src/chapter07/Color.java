package chapter07;


/*생성자 오버로딩
 * 1.int value로 받고 blue에 대입
 * 2.멤버변수를 모두 받고 인스턴스(객체) 자기자신에 대입
 * 각각 객체 만들어 대입한 값 출력.
 * */


public class Color {
	
	
	public int red;
	public int green;
	public int blue;
	public int value;
	
	
	public Color(int value) { // 매개변수
		this.blue = value;
	}

	public Color(int red, int green, int blue) {
		this.red = red;
		this.green = green;
		this.blue = blue;
	}

	public void getColors() {
		System.out.println("red의 값 : " + red);
		System.out.println("blue의 값 : " + blue);
		System.out.println("green의 값 : " + green);
	}

}
