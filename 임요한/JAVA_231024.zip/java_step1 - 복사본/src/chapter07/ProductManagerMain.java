package chapter07;

public class ProductManagerMain {

	public static void main(String[] args) {
		
		ProductManager Yu = new ProductManager();
		ProductManager Jang = new ProductManager();
		
		Yu.addProduct("과자", 1200);
		Jang.addProduct("초콜렛", 1500, 3);
		
	}

}
