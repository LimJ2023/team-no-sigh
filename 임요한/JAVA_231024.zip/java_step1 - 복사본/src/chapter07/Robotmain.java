package chapter07;

import javax.swing.JOptionPane;

public class Robotmain {

	public static void main(String[] args) {
		Robot robot1 = new Robot();
		
		robot1.move();
		robot1.move();
		
		System.out.println("=================");
		robot1.robotAge();
		System.out.println("=================");
		
		int r_speed = Integer.parseInt(JOptionPane.showInputDialog("속도 입력"));
		int r_age = Integer.parseInt(JOptionPane.showInputDialog("나이 입력"));
		String r_name = JOptionPane.showInputDialog("이름 입력");
		String r_number = JOptionPane.showInputDialog("번호 입력");
		
		
		Robot robot2 = new Robot(r_speed, r_age, r_name, r_number);
		
		int speed = robot2.getSpeed();
		
		System.out.println("속도 : " + speed);
		System.out.println("나이 : " + robot2.getAge());
		System.out.println("이름 : " + robot2.getRobotName());
		System.out.println("번호 : " + robot2.getRobotNum());
		
		
		
	}

}
