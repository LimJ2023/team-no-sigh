package chapter07;

public class ProductManager {
	
	//메서드 오버로딩
	public void addProduct(String name, int price) {
		System.out.println(name + "의 가격을 " + price + "원으로 추가합니다.");
		
	}
	
	public void addProduct(String name, int price, int quantity) {
		System.out.println(name + "의 가격을 " + price + "원으로 " + quantity+"개 추가합니다.");
	}
	
}
