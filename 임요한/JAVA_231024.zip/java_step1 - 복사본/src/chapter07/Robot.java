package chapter07;

public class Robot {
	
	private int speed;
	private int age;
	private String robotName;
	private String robotNum;
	
	public Robot() {
	}

	public Robot(int speed, int age, String robotName, String robotNum) {
		this.speed = speed;
		this.age = age;
		this.robotName = robotName;
		this.robotNum = robotNum;
	}
	
	public void move() {
		speed += 20;
		System.out.println("로봇속도 : " + speed);
	}
	public void stop() {
		speed = 0;
		System.out.println("로봇속도 : " + speed);
	}
	public void robotAge() {
		age++;
		System.out.println("로봇나이 : " + age);
	}
	public void robotName() {
		System.out.println("로봇이름 : " + robotName);
	}
	public void robotNumber() {
		System.out.println("로봇번호" + robotNum);
	}

	public int getSpeed() {
		return speed;
	}

	public int getAge() {
		return age;
	}

	public String getRobotName() {
		return robotName;
	}

	public String getRobotNum() {
		return robotNum;
	}
	
	
}
