package chapter07;

import javax.swing.JOptionPane;

public class EncapsulationMain {
	
	public static void main(String[] args) {
		
		int side;
		int height;
		int area;
		
		side = Integer.parseInt(JOptionPane.showInputDialog("밑변"));
		height = Integer.parseInt(JOptionPane.showInputDialog("높이"));
		
		Encapsulation capsul = new Encapsulation();
		
		area = capsul.Cal_Area(side, height);
		
		System.out.println("사각형의 넓이 : " + area);
		
		JOptionPane.showInternalMessageDialog(null, "사각형의 넓이 : " + area);
	}
	
}
