package chapter05;

public class MethodTest03 {
	
	public static void main(String[] args) {
		
		int sum;
		sum = add(5, 10);
		System.out.println(sum);
		System.out.println(add(3, 5));
	}
	
	public static int add(int a, int b) {
		return a + b;
	}
}
