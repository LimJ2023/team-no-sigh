package chapter05;

public class CarMain {
	
	//멤버 변수 = 필드
	String carName;
	String carColor;
	int carNumber;
	
	int number = 100; // 초기화한다.

	//타입(자료형)	변수명
	public String getCarName() {
		return carName;
	}
			
	public static void main(String[] args) {
		//참조변수 : 힙 메모리에 할당된 객체(인스턴스)가 저장되어있는 
		//주소를 가진 변수.
		Car myCar = new Car();
		
		myCar.carName = "k5"; //클래스 멤버변수에 직접 대입
		
		myCar.setCarName("차1");
		
		System.out.println("멤버 변수를 호출 : " + myCar.carName );
		System.out.println("게터 메소드를 호출 : " + myCar.getCarName());
		
	}

}
