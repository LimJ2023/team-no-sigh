package chapter05;

public class FunTest_OverloadingMain {

	public static void main(String[] args) {
		
		//객체 생성
		FunTest_Overloading overloading = new FunTest_Overloading();
		int num = 10;
		String str = "hello";
		char ch = 'A';
		
		overloading.getResult(num);
		overloading.getResult(str);
		overloading.getResult(ch);
		overloading.getResult(num, str);
	}
}
