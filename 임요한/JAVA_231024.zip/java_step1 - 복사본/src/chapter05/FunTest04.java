package chapter05;


public class FunTest04 {

	// 멤버변수 = 필드
	public String channel;
	public int channelInt;
	public int volume;

	// 생성자
	public FunTest04() {

	}

	// 메소드
	public void channelUp(int volume) {
		System.out.println("소리를" + volume + "만큼 올립니다.");
	}

	public void channelDown(int volume) {
		System.out.println("소리를" + volume + "만큼 내립니다.");
	}

	// 메소드 오버로딩 (이름은 같으면서 매개변수의 타입,개수가 다름)
	public void channelChange(String channel) {
		System.out.println("tv 채널을 " + channel + "로 바꿉니다.");
	}

	// 메소드 오버로딩
	public void channelChange(int channelInt) {
		System.out.println("채널을 " + channelInt + "로 바꿉니다.");
	}

	public static void main(String[] args) {

		FunTest04 tv = new FunTest04();

		//int[] arr = new int[3];
		tv.channelUp(3);
		tv.channelDown(4);

		tv.channelChange(120);
		tv.channelChange("212");

		/*
		 * for (int i = 0; i < 3; i++) { // 행 개수 row for (int j = 0; j < 3; j++) { // 칸
		 * 개수 col System.out.print("*"); } System.out.println(); }
		 * 
		 * 
		 * for (int i = 0; i < 5; i++) { // 5칸..다음칸으로 넘어가고... i 늘어나고..0->1->2 for (int j
		 * = 0; j < 4-i; j++) { System.out.print(" "); } for (int j = 0; j < 2*i + 1;
		 * j++) { System.out.print("*"); } System.out.println(); }
		 */

		for (int i = 0; i < 3; i++) { 
			for (int j = 0; j < 1 + i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

		for (int i = 0; i < 5; i++) {

			for (int j = 0; j < i + 1; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < 9 - i * 2; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		for (int i = 1; i <= 5; i++) {
			for (int j = 0; j < 5-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2*i) - 1; j++) {
				System.out.print("*");
			}System.out.println();
		}
		
		for (int i = 4; i > 0; i--) {
			for (int j = 0; j < 5-i; j++) {
				System.out.print(" ");
			}
			for (int j = 0; j < (2*i) - 1; j++) {
				System.out.print("*");
			}System.out.println();
		}
	} //main

}
