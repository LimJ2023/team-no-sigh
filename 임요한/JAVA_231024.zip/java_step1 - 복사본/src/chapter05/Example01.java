package chapter05;

import javax.swing.JOptionPane;

public class Example01 {

	//두 정수를 입력받아 그 합을 계산하여 반환하는 메서드 구현
	public static int add(int a, int b) {
		return a + b;
	}
	public static int add2(int a, int b) {
		return a + b;
	}
	public static void main(String[] args) {

		int num1 = Integer.parseInt(JOptionPane.showInputDialog("첫번째 정수 입력"));
		int num2 = Integer.parseInt(JOptionPane.showInputDialog("두번째 정수 입력"));
		int sum = add(num1, num2);
		System.out.println(sum);
		
		System.out.println("정수 덧셈 결과 : " + add2(5,3));
	}

}
