package chapter05;

import java.util.Scanner;

public class FunTest05 {

	//멤버 변수 = 필드
	//생성자
	//메서드
	
	//매개변수를 int edu로 하는 Edustop메서드 만들기
	// edu==1 이면 스터디 단계는 step1
	// edu==2 이면 스터디 단계는 step2
	public static void Edustep(int edu) {
		
		if(edu == 1) {
			System.out.println("현재 스터디 단계는 step1 입니다.");
		}else if(edu == 2) {
			System.out.println("현재 스터디 단계는 step" + edu +" 입니다.");
		}else if(edu == 3) {
			System.out.println("현재 스터디 단계는 step" + edu + " 입니다.");
		}else {
			System.out.println("해당하는 스터디 단계가 없습니다.");
		}
	}
	
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("스터디 단계를 입력하세요. : ");
		int number = scan.nextInt();
		Edustep(number);
		scan.close();
	}

}
