package chapter05;

public class MethodTest04 {

	
	//메소드 오버로딩
	public static int add(int a, int b) {
		return a + b;
	}
	public static double add(double a, double b) {
		return a + b;
	}
	
	public void name() {
		System.out.println("1234");
	}
	public static void main(String[] args) {
		
		double a = 10.0, b = 5.0;
		int sum = add(5, 10);
		double sumDouble = add(3, 5);
		System.out.println("합계(int)" + sum);
		System.out.println("합계(double)" + sumDouble);
		System.out.println(add(3.0, 5));
		System.out.println(a + b);
		
		
		sum = add(3, 6);
		
	}

}
