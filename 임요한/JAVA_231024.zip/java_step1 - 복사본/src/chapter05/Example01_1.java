package chapter05;

//방법 2
public class Example01_1 {

	public int add(int a, int b) {
		return a + b;
	}
	
	
	public static void main(String[] args) {

		Example01_1 math = new Example01_1();
		int sum = math.add(3, 5);
		
		System.out.println("정수 덧셈 결과 : " + sum);
		
	}

}
