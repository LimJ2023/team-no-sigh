package chapter05;

public class Rectangle {

	
	/*사각형 넓이를 계산하는 메서드 calculateArea를 오버로딩하여
	 * 가로와 세로길이, 그리고 한 변의 길이를 받아서 계산할 수 있게 만들어보세요.
	 * 사각형 넓이 계산(1) = 가로 x 세로
	 * 사각형 넓이계산(2) = 한 변의 길이 x 한 변의 길이
	 * */
	public  int calculateArea(int width, int height) {
		return width * height;
	}
	public  int calculateArea(int length) {
		return length * length;
	}
	public static void main(String[] args) {
		
		Rectangle cal = new Rectangle();
		
		int result = cal.calculateArea(10, 10);
		int result2 = cal.calculateArea(10);
		
		System.out.println("사격형 넓이 계산 : " + result);
		System.out.println("사격형 넓이 계산2  : " + result2);
		
	}

}
