package chapter06;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class CanMain {
	
	
	public static void main(String[] args) {
		
		String canName = "";
		int money = 0;
		
		Vending vending1 = new Vending();//초기화
		//객체 생성이 됨.
		
		
		Scanner scan = new Scanner(System.in);
		
		vending1.init();
		
		System.out.print("금액을 입력하세요.");
		money = scan.nextInt();
		vending1.showCans(money);
		
		scan.nextLine();
		System.out.print("음료 이름을 입력해주세요.");
		canName = scan.nextLine();
		vending1.outCan(canName);
		
		scan.close();
	}

}
