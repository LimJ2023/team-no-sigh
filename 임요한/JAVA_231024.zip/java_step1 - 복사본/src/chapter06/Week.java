package chapter06;

public enum Week {
	
	MONDAY,
	TUESDAY,
	WENSDAY,
	THURSDAY,
	FRIDAY,
	SATURDAY,
	SUNDAY
	
}

