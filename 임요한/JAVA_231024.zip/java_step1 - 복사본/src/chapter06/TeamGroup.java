package chapter06;

public class TeamGroup {
	
	private TeamMember[] member = new TeamMember[5];
	
	//기본 생성자
	
	//초기화 메서드
	public void init() {
		member[0] = new TeamMember("이지수", "여");
		member[1] = new TeamMember("임요한", "남");
		member[2] = new TeamMember("김진훈", "남");
		member[3] = new TeamMember("박현수", "남");
		member[4] = new TeamMember("최민기", "남");
	}
	
	//출력 메서드
	public void display() {
		for (int i = 0; i < member.length; i++) {
			System.out.print("성별 : " + member[i].getGender());
			System.out.println("이름 : " + member[i].getName());
		}
	}
}
