package chapter06;

public class TeamMain {

	public static void main(String[] args) {

		TeamGroup team = new TeamGroup();
		TeamMember t = new TeamMember();
		
		t.setTeamName("team no sigh");
		System.out.println("팀명 : " + t.getTeamName());
		
		System.out.println("------팀원 명단----------");
		team.init();
		team.display();
		
		System.out.println();
		
		t.setmName("이지수");
		System.out.println("팀장이름 : " + t.getmName());
		t.setmPhone("010-2222-2222");
		System.out.println("팀장 번호 : " + t.getmPhone());
		t.setsName("박현수");
		System.out.println("부팀장이름 : " + t.getsName());
		
		
	
	}

}
