package chapter06;

public class Cafe {
	//멤버변수
	public String name;
	public int sales; //매출
	int account;
	
	//생성자
	public Cafe(String name) {
		this.name = name;
	}
	
	//메서드
	public void sell(int amount) {
		sales += amount;
	}
	
	public void showInfo() {
		System.out.println(name + " 카페의 총 매출은 : " + sales+"원 입니다.");
		System.out.println("총 고객수는 " + account + "명 입니다.");
	}
	
	
	
}
