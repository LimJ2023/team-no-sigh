package chapter06;

public class TeamMember {
	
	//멤버 변수 = 필드
	public String teamName;
	public String mName; // 팀장
	public String mPhone; // 팀장 번호
	public String sName; // 부팀장
	public String name; // 팀원
	public String gender; // 팀원 성별
	
	//기본 생성자
	public TeamMember() {
	}
	
	//생성자 오버로딩
	public TeamMember(String name, String gender) {
		this.name = name;
		this.gender = gender;
	}
	
	
	//메서드
	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmPhone() {
		return mPhone;
	}

	public void setmPhone(String mPhone) {
		this.mPhone = mPhone;
	}

	public String getsName() {
		return sName;
	}

	public void setsName(String sName) {
		this.sName = sName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
	
}
