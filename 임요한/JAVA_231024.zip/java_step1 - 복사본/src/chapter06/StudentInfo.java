package chapter06;

public class StudentInfo {
	
	//멤버변수 = 필드
	int studentID; //디폴트 접근제어자 -> 같은 패키지
	private String studentName;
	int grade;
	String address;
	
	
	
	//메서드
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	public void Info() {
		System.out.println("이름 :" + studentName);
		System.out.println("학년 :" + grade);
		System.out.println("주소 :" + address);
	}
	
}
