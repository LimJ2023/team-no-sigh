package chapter06;

public class StdInfo {
	
	public String studentName;
	public int grade;
	public int money;
	public static int sin;
	
	//생성자
	public StdInfo(String studentName, int money) {
		this.studentName = studentName;
		this.money = money;
	}
	
	//메서드
	public void takeBus(Bus bus) {// <-실행코드에서 버스 객체를 투입해주면 그 버스의 돈이 바뀜
		bus.take(1000);
		this.money -= 1000;
	}
	
	public void takeSubway(Subway sub) {
		sub.take(1500);
		this.money -= 1500;
	}
	
	public void showStdInfo() {
		System.out.println(studentName + "님의 잔액은 : " + money + "원 입니다.");
	}
	
	
}
