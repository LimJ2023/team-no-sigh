package chapter06;

import java.util.Scanner;

public class GuGuDanMain {

	public static void main(String[] args) {

		GuGuDan gugu = new GuGuDan();
		
		Scanner scan = new Scanner(System.in);
		System.out.print("출력할 단을 입력하세요 : ");
		int num = scan.nextInt();
		
		gugu.showTable(num);
		
		scan.close();
		
	}

}
