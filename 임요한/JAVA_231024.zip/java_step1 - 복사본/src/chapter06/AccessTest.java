package chapter06;

public class AccessTest {

	
	//필드 = 멤버변수
	private int aa;
	
	public int bb;
	int cc; // 디폴트 default (동일 패키지에서 접근 가능)
	
	//생성자
	
	//메서드
	public void setAa(int aa) {
		this.aa = aa;
	}

	public void setBb(int bb) {
		this.bb = bb;
	}

	public void setCc(int num1) {
		cc = num1;
	}
	
	
	public void display() {
		System.out.println("aa값 : " + aa + "\nbb값 : " + bb + "\ncc값 : " + cc);
	}

	public static void main(String[] args) {
		
		AccessTest obj = new AccessTest();
		
		obj.setAa(1);
		obj.setBb(2);
		obj.setCc(3);
		obj.aa = 10;
		
		
		obj.setCc(5);
		obj.display();
		
		
		
	}

}
