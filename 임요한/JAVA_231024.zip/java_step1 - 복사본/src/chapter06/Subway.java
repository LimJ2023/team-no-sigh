package chapter06;

public class Subway {
	
	
	int subwayNumber;
	public String lineNumber;
	int passengerCount;
	int money;
	
	//생성자 
	public Subway(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	
	//메서드
	public void take(int money) { //승객이 낸 돈
		this.money += money; // 열차 수입 증가
		passengerCount++; // 승객수 증가
	}
	
	public void showSubwayInfo() { //열차 정보 출력
		System.out.println("열차 " + lineNumber + "번의 승객은 " + passengerCount + "명이고,"
		 + " 수입은 " + money + "원 입니다." );
	}
}
