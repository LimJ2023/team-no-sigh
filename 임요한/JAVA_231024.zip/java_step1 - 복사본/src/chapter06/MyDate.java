package chapter06;

public class MyDate {

	public int day;
	public int month;
	public int year;
	
	//생성자
	
	//메서드
	

}
