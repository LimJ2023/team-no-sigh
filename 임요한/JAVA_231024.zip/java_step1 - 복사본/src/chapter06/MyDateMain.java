package chapter06;


public class MyDateMain {

	public static void main(String[] args) {

		//Mydate 참조변수 이름 date로 객체 생성
		//멤버변수 값 할당. 오늘 날짜. 2023/11/14
		
		MyDate date = new MyDate();
		
		date.day = 14;
		date.month = 11;
		date.year = 2023;
		
		System.out.println(date.year + "/" + date.month + "/" + date.day);
	}

}
