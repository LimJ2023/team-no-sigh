package chapter06;

public class User {
	
	/* 사용자의 이름과 나이 정보를 출력하는 메서드 printinfo를 구현
	 * 이름만 입력받거나 이름과 나이를 입력받을 수 있는 생성자
	 * main에서 객체 만들고 메서드 호출.
	 */
	
	//멤버 변수
	private String name;
	private int age;
	
	//생성자
	public User(String name) {
		this.name = name;
	}
	public User(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	//메서드
	public void printInfo() {
		
		if(age == 0) {
			System.out.println("이름 : " + name);
		}else {
			System.out.println("이름 : " + name + " 나이 : " + age);
		}
	}

	//메인
	public static void main(String[] args) {
		
		User user1 = new User("이지수");
		User user2 = new User("임요한", 29);
		
		user1.age = user2.age;
		
		user1.printInfo();
		user2.printInfo();
	}
}
