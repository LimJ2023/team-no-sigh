package chapter06;

public class BuyCoffee {
	public static void main(String[] args) {
		
		//고객 2명 생성
		//customerPark 10000
		// 카페이름 cafeA 2명 카페 방문
		// 카페 정보 확인 손님,카페 둘 다.
		Cafe cafeA = new Cafe("cafeA");
		Cafe cafeb = new Cafe("카페b");
		
		Customer customerKim = new Customer("김민재", 12000);
		Customer customerPark = new Customer("박지성", 10000);
		CustomerVIP customerLim = new CustomerVIP("임요한", 10000);
		
		customerKim.visitCafe(cafeA, 12000);
		customerPark.visitCafe(cafeA, 4500);
		customerPark.visitCafe(cafeb, 1000);
		
		//카페 정보 확인
		//손님 정보 확인
		cafeA.showInfo();
		cafeb.showInfo();
		customerKim.showInfo();
		customerPark.showInfo();
		
		System.out.println(customerLim.money + "원");
		System.out.println(customerLim.bonus); 
		
		customerLim.bonusPlus(100);
		System.out.println(customerLim.bonus); 
		
	}
}
