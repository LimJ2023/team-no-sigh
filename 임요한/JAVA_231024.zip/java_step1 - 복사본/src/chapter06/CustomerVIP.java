package chapter06;

public class CustomerVIP extends Customer{
	
	int bonus;
	
	
	public CustomerVIP(String customerName, int money) {
		super(customerName, money);
		bonus = 100;
	}
	
	public void bonusPlus(int point) {
		bonus += point;
	}

	
	
	

}
