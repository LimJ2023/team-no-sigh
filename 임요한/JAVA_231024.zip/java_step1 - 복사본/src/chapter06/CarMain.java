package chapter06;

public class CarMain {

	public static void main(String[] args) {

		//객체 생성
		Car myCar = new Car();
		
		System.out.println("회사 : " + myCar.company);
		System.out.println("모델명 : " + myCar.model);
		System.out.println("색상 : " + myCar.color);
		System.out.println("최고속도 : " + myCar.maxSpeed);
		System.out.println("현재속도 : " + myCar.speed);
		
		
		
		myCar.speed = 800;
		
		System.out.println(myCar.speed);
	}

}
