package chapter06;

public class StudentInfoMain {

	public static void main(String[] args) {
		
		StudentInfo stdKim = new StudentInfo();
		
		stdKim.studentID = 202;
		stdKim.grade = 3;
		stdKim.address = "서울시 종로구";
		
		stdKim.setStudentName("홍길동");
		String name = stdKim.getStudentName();
		System.out.println(name);
		
		stdKim.Info();
		
	}

}
