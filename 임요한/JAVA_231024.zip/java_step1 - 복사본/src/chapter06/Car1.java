package chapter06;

public class Car1 {
	//멤버 변수 = 필드
	private String model;
	
	//메서드
	public String getModel() {
		return model;
	}
	
	public void setModel(String m) {
		model = m;
	}
	
	public static void main(String[] args) {
		
		Car1 car1 = new Car1();
		
		car1.setModel("버스");
		System.out.println("차 모델 : " + car1.getModel());
		
		
	}
}
