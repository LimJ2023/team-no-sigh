package chapter06;

public class Student {
	
	int studentID;
	public String studentName;
	int grade;
	String address;
	
	//디폴트 생성자
	public Student() {
		
	}
	//생성자 오버로딩
	public Student(String studentName, String address) {
		this.studentName = studentName;
		this.address = address;
	}
	
	//메서드
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public void showStudentInfo() {
		System.out.println(studentName + ", " + address);
	}
	
	
	
	
}
