package chapter06;

public class Car {
	
	//멤버변수 = 필드
	String company = "현대자동차";
	String model = "그랜저";
	String color = "검정";
	int maxSpeed = 250;
	int speed;
	
	
	
}
