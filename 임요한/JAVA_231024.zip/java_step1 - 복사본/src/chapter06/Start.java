package chapter06;

import java.util.Random;

public class Start {
	
	private int pcNum = new Random().nextInt(50)+1; //1~50까지 정수 추출
	
	private int count = 0;
	
	private String result = "FAIL";
	
	public String check(int myNumber) {
		count++;
		
		//랜덤 값보다 작으면 up,크면 down, 일치하면 석세스
		if(myNumber < pcNum) {
			System.out.println("숫자를 올려주세요.");
		}else if (myNumber > pcNum) {
			System.out.println("숫자를 내려주세요.");
		}else {
			System.out.println(count + "회 만에 정답");
			result = "SUCCESS";
		}
		
		return result;
	}
	
}
