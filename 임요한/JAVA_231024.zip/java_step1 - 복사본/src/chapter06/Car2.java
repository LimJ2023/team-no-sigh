package chapter06;

public class Car2 {

	public static String model; //정적 멤버 변수
	
	public static void main(String[] args) {

		Car2.model = "현대";
		System.out.println(Car2.model);
		
		System.out.println(model);
	}

}
