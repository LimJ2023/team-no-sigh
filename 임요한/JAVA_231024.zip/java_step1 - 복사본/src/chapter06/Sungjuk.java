package chapter06;

import javax.swing.JOptionPane;

public class Sungjuk {

	//멤버 변수 = 필드
	private String std_num;
	private String std_name;
	private int java,oracle,spring;
	
	//기본 생성자(생략 가능)
	//클래스와 이름이 같은 메서드, 생성자를 이용하여 객체를 초기화함.
	
	
	//메서드
	public void Sum() {
		int total = java + oracle + spring;
		System.out.println("총 합계 : " + total);
	}
	
	public void avg() {
		int avg = (java + oracle + spring) / 3;
		System.out.println("평균 : " + avg);
	}
	
	public static void main(String[] args) {

		Sungjuk record = new Sungjuk();
		
		record.std_num =  JOptionPane.showInputDialog("학번");
		record.std_name =  JOptionPane.showInputDialog("성명");
		
		record.java = Integer.parseInt(JOptionPane.showInputDialog("자바 성적"));
		record.oracle = Integer.parseInt(JOptionPane.showInputDialog("오라클 성적"));
		record.spring = Integer.parseInt(JOptionPane.showInputDialog("스프링 성적"));
		
		System.out.println("학번 -" + record.std_num + " 성명 -" + record.std_name);
		System.out.println("===========================================");
		
		record.Sum();
		record.avg();
		
		System.out.println("자바 성적 : " + record.java + "오라클 성적 : " + record.oracle 
				+ "스프링 성적 : " + record.spring);
	}

}
