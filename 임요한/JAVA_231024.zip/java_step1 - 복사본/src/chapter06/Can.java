package chapter06;

public class Can {
	
	//멤버변수
	private String canName;
	private int price;
	
	public Can(String canName, int price) {
		this.canName = canName;
		this.price = price;
	}

	//메서드
	public String getCanName() {
		return canName;
	}

	public int getPrice() {
		return price;
	}
	
	
	
}
