package chapter06;

public class TakeTransMain {

	public static void main(String[] args) {

		StdInfo studentJames = new StdInfo("James", 5000);
		StdInfo studentTom = new StdInfo("Tom", 10000);
		Bus bus273 = new Bus(273);
		
		
		
		studentJames.takeBus(bus273);
		studentJames.showStdInfo();
		bus273.showBusInfo();
		
		
		
		
		System.out.println("=====================");
		
		//버스 987번에 tom을 태우세요.
		Bus bus987 = new Bus(987);
		studentTom.takeBus(bus987);
		studentTom.showStdInfo();
		bus987.showBusInfo();
		
		System.out.println("=====================");
		
		Subway subway7 = new Subway("7호선");
		studentTom.takeSubway(subway7);
		
		studentTom.showStdInfo();
		subway7.showSubwayInfo();
		
		
		Subway subway1 = new Subway("1호선");
		studentJames.takeSubway(subway1);
		subway1.showSubwayInfo();
		studentJames.showStdInfo();
	}//main

}
