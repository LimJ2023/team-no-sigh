package chapter06;

public class Bus {
		
	//멤버변수 필드
	int busNumber;
	int passengerCount;
	int money;
	
	//생성자 
	public Bus(int busNumber) {
		this.busNumber = busNumber;
	}
	
	//메서드
	public void take(int money) { //승객이 낸 돈
		this.money += money; // 버스 수입 증가
		passengerCount++; // 승객수 증가
	}
	
	public void showBusInfo() { //버스정보 출력
		System.out.println("버스 " + busNumber + "번의 승객은 " + passengerCount + "명이고,"
		 + "수입은 " + money + "원 입니다." );
	}
	
	
}
