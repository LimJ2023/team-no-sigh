package chapter06;

public class StudentMain {

	public static void main(String[] args) {

		//멤버 변수를 직접 수정
		Student std1 = new Student();
		std1.studentName = "민지";
		std1.address = "서울시 종로구";
		std1.showStudentInfo();
		
		System.out.println("====================");
		
		//세터를 사용하여 대입
		Student std2 = new Student();
		std2.setStudentName("강감찬");
		std2.setAddress("제주도");
		std2.showStudentInfo();
		
		System.out.println("====================");
		
		//초기화시 대입                                                                                                                                                                                                                                                                                                                                       
		Student stdLim = new Student("임요한", "서울시 동대문구");
		stdLim.grade = 3;
		
		stdLim.showStudentInfo();
	}

}
