package chapter06;

public class Car2_Test {

	public static void main(String[] args) {

		System.out.println(Car2.model);
		
		System.out.println();
	}

}
