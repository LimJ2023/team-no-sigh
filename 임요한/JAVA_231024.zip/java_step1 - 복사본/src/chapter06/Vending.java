package chapter06;

public class Vending {
	
	//멤버변수
	private Can[] cans = new Can[5];
	private int money;
	
	//메서드
	public void init() { //init 초기화 메서드
		cans[0] = new Can("환타", 1300); // 초기화.
		cans[1] = new Can("사이다", 1200);
		cans[2] = new Can("오렌지", 1100);
		cans[3] = new Can("바나나우유", 1400);
		cans[4] = new Can("콜라", 1000);
	}
	
	//사용가능한 음료만 보여주는 메서드
	public void showCans(int m) {
		money = m; //돈
		for (int i = 0; i < cans.length; i++) {
			if(cans[i].getPrice() <= money) {
				System.out.println(cans[i].getCanName() + "-" + cans[i].getPrice() + "원");
				//money -= cans[i].getPrice();
			}
		}
		
	}
	
	//선택한 음료수 제공과 잔액을 보여주는 메서드
	public void outCan(String name) {
		for (int i = 0; i < cans.length; i++) {
			if(cans[i].getCanName().equals(name)) {
				System.out.println(cans[i].getCanName() + "를 선택하셨습니다.");
				money -= cans[i].getPrice();
				System.out.println("잔액은 :" + money + "입니다.");
			}
		}
	}
	
}
