package chapter06_practice;


public class FuncTest01 {

	
	public int func1(int x) {//재귀함수 이용
		if(x == 0 || x == 1) {
			return x = 1;
		}
		else if(x > 0){
			return func1(x - 1) + func1(x - 2); //재귀함수 호출
		}
		else {
			System.out.println("음수 입력입니다.");
			return x;
		}
	}
	
	
	static int[] fibo = new int[100]; // 동적할당용 배열
	
	public int func2(int x) { // 배열 이용
		if(x == 1 || x == 0) {
			return 1;
		}
		else if(fibo[x] > 1) { //배열 내에 값이 있다면 바로 반환
			return fibo[x];
		}
		else if (x < 0) {
			System.out.println("음수 입력입니다.");
			return x;
		}
		else{
			fibo[x] = func2(x - 1) + func2(x - 2);// 재귀함수 호출
			return fibo[x];
		}
	}
	
	public static void main(String[] args) {
		
		FuncTest01 test = new FuncTest01();
		
		System.out.println(test.func1(10)); 
		System.out.println(test.func2(10));
	}

}
