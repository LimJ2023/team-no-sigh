package chapter06_practice;

public class AccessTest {
	
	
	private int aa;
	public int bb;
	int cc;
	
	public void setAa(int aa) {
		this.aa = aa;
	}
	public void setBb(int bb) {
		this.bb = bb;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	
	public void display() {
		System.out.println("aa값 : " + aa + "\nbb값 : " + bb + "\ncc값 : " + cc);
	}
	
	public static void main(String[] args) {
		
		AccessTest obj = new AccessTest();
		
		obj.setAa(1);
		obj.setBb(2);
		obj.setCc(3);
		obj.aa = 10;
		
		obj.setCc(5);
		obj.display();
	}
}
