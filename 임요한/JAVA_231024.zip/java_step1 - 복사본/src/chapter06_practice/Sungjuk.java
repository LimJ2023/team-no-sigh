package chapter06_practice;

import javax.swing.JOptionPane;

public class Sungjuk {
	
	private String std_num;
	private String std_name;
	private int java,oracle,spring;
	
	public void sum() {
		int total = java + oracle + spring;
		System.out.println("총 합계 : " + total);
	}
	
	public void avg() {
		int avg = (java + oracle + spring) / 3;
		System.out.println("평균 : " + avg);
	}
	
	public static void main(String[] args) {
		
		Sungjuk record = new Sungjuk();
		
		record.std_num = JOptionPane.showInputDialog("학번");
		record.std_name = JOptionPane.showInputDialog("이름");
		
		record.java = Integer.parseInt(JOptionPane.showInputDialog("자바 성적"));
		record.oracle= Integer.parseInt(JOptionPane.showInputDialog("오라클 성적"));
		record.spring = Integer.parseInt(JOptionPane.showInputDialog("스프링 성적"));
		
		System.out.println("학번 -" + record.std_num + " 성명 -" + record.std_name);
		System.out.println("=============================");
		
		record.sum();
		record.avg();
		
		
		System.out.println("자바 성적 : " + record.java + " 오라클 성적 : " + record.oracle 
				+ " 스프링 성적 : " + record.spring);
	}//main

}
