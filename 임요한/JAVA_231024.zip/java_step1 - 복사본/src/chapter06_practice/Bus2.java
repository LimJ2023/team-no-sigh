package chapter06_practice;

public class Bus2 {
	int busNumber;
	int passengerCount;
	int money;
	
	public Bus2(int busNumber) {
		this.busNumber = busNumber;
	}
	
	public void take(int money) {
		this.money = money;
	}
	
	public void showBusInfo() {
		System.out.println("버스 " + busNumber + "번의 승객은 " + passengerCount + "명이고,"
				 + "수입은 " + money + "원 입니다." );
	}
	
	
	
}
