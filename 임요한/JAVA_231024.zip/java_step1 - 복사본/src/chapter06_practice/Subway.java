package chapter06_practice;

public class Subway {
	
	int subWayNumber;
	public String lineNumber;
	int passengerCount;
	int money;
	
	public Subway(String lineNumber) {
		this.lineNumber = lineNumber;
	}
	
	public void take(int money) {
		this.money += money;
		passengerCount++;
	}
	
	public void showSubwayInfo() {
		System.out.println("열차 " + lineNumber + "번의 승객은 " + passengerCount + "명이고,"
				 + " 수입은 " + money + "원 입니다." );
	}
	
	
}
