package chapter06_practice;

public class StdInfo {
	
	public String studentName;
	public int grade;
	public int money;
	
	public StdInfo(String studentName, int money) {

		this.studentName = studentName;
		this.money = money;
	}
	
	public void takeBus(Bus2 bus) {
		bus.take(1000);
		this.money -= 1000;
	}
	
	public void takeSubway(Subway sub) {
		sub.take(1500);
		this.money -= 1500;
	}
	
	public void showStdInfo() {
		System.out.println(studentName + "님의 잔액은 : " + money + "원 입니다.");
	}
	
	
	

}
