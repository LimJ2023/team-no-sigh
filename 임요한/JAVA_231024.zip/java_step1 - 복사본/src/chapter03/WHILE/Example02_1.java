package chapter03.WHILE;

import java.util.Scanner;

public class Example02_1 {

	public static void main(String[] args) {

		boolean run = true;
		
		int balance = 0;
		int inputMoney = 0;
		
		Scanner scan = new Scanner(System.in);
		
		while(run) {
			System.out.println("========================");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("=======================");
			System.out.print("선택 > ");
			
			int menuNumber = scan.nextInt();
			// 문제점 -> 예금을 0원,-로 가능한점, 출금이 마이너스 통장이 되는점,
			switch (menuNumber) {
			case 1:
				System.out.print("예금하기 > ");
				inputMoney = scan.nextInt();
				if(inputMoney <= 0) { // 입금액이 0이거나 - 일 때의 예외처리
					System.out.println("예금 불가능한 금액입니다.");
					break;
				}
				balance += inputMoney;
				System.out.println("입금 완료");
				break;
			case 2:
				System.out.print("출금하기 > ");
				inputMoney = scan.nextInt();
				if(inputMoney > balance || inputMoney <= 0) { // 출금액이 예금보다 크거나 
															//0,- 금액을 넣었을 때의 예외처리 
					System.out.println("출금 불가능한 금액입니다.");
					break;
				}
				balance -= inputMoney;
				System.out.println("출금 완료");
				break;
			case 3:
				System.out.print("잔고확인 : ");
				System.out.println(balance);
				break;
			case 4:
				System.out.println("종료");
				run = false;
				break;

			default:
				System.out.println("잘못된 번호입니다.");
				break;
			}//switch
		}//while
		System.out.println("프로그램 종료");
		scan.close();
	}//main

}
