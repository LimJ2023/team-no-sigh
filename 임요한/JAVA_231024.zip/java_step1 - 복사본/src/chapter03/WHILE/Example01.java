package chapter03.WHILE;

import java.util.Scanner;

public class Example01 {

	public static void main(String[] args) {

		/*
		 * 사용자가 no를 입력하기 전까지 계속해서 메시지를 입력받고 출력하는 프로그램을 만들어보세요.
		 * 
		 */

		Scanner scan = new Scanner(System.in);
		String no = "no";
	    String inputString; //변수명을 명확하게
	      
	      do {
	         System.out.print("메시지를 입력해주세요 : ");
	         inputString = scan.nextLine();
	         System.out.println(inputString);
	      } while (!inputString.equals(no)); // 같지 않다면 반복
		 
	      System.out.println("프로그램 종료");
		/*
		 * while (true) { System.out.println("메시지를입력하세요 : "); String str =
		 * scan.nextLine();
		 * 
		 * if (str.equals(no)) { break; } } System.out.println("종료");
		 */
	      
	      

		scan.close();
	}

}
