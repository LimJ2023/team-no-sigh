package chapter03.WHILE;

import java.util.Scanner;

public class Example05 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		boolean run = true;
		int selectMenu;
		int input_Bbang_Number;
		String bbangMenu;
		
		while(run) {
			System.out.println("--------------------------");
			System.out.println("1.빵 개수만 선택 | 2.빵 개수와 종류 선택 | 3.종료");
			System.out.println("--------------------------");
			System.out.print("선택 >> ");
			selectMenu = scan.nextInt();
			
			switch (selectMenu) { // 메뉴선택시 케이스
			case 1:
				System.out.print("case1 빵 개수 입력 : ");
				input_Bbang_Number = scan.nextInt();
				for(int i =1; i <= input_Bbang_Number; i++) { //빵 개수만큼 출력
					System.out.println("빵 " + i + "개");
				}
				System.out.println("빵 " + input_Bbang_Number + "개가 완성되었습니다.");
				break;
				
			case 2:
				System.out.print("case2 빵 개수 입력 : ");
				input_Bbang_Number = scan.nextInt();
				
				scan.nextLine(); // nextInt()와nextLine()을 동시에 사용시 nextLine()이 스킵될 때 사용.
								// scan.nextLine() 대신 scan.next();를 사용해도 해결 가능.
				System.out.print("종류 선택 : ");
				bbangMenu = scan.nextLine();
				
				for(int i = 1; i <= input_Bbang_Number; i++) { // 빵 개수만큼 메세지 출력
					System.out.println(bbangMenu + "빵 " + i + "개");
				}
				System.out.println("요청하신 "+input_Bbang_Number + "개의 "+ bbangMenu + "빵이 완성되었습니다.");
				break;
				
			case 3:
				System.out.println("프로그램 종료");
				run = false; //while문 탈출
				break;
				
			default:
				System.out.println("잘못된 번호 선택입니다.");
				break;
			}//switch
		}//while
		scan.close();
	}//main

}
