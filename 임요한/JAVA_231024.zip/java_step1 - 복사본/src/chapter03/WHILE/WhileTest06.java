package chapter03.WHILE;

import java.util.Scanner;

public class WhileTest06 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int num;
		boolean isRunning = true;
		
		while(isRunning == true) {
			System.out.print("1.입력하기 \n2.출력하기 \n3.삭제하기 \n4.끝내기 \n작업할 번호를 선택하세요 > ");
			num = scan.nextInt();
			
			switch (num) {
			case 1:
				System.out.println("입력하기 선택하셨습니다.");
				break;
			case 2:
				System.out.println("출력하기 선택하셨습니다.");
				break;
			case 3:
				System.out.println("삭제하기 선택하셨습니다.");
				break;
			case 4:
				System.out.println("끝내기 선택하셨습니다.");
				isRunning = false;
				break;

			default:
				System.out.println("잘못된 번호입니다.");
				break;
			}//switch
			
			/*
			 * if(num == 4) { break; }
			 */
			
		}//while
		scan.close();
	}

}
