package chapter03.WHILE;

public class WhileTest02 {

	public static void main(String[] args) {

		int i = 1;
		
		while(i <= 10) {
			System.out.println(i);
			i++;
		}
		System.out.println("프로그램 종료");
	}

}
