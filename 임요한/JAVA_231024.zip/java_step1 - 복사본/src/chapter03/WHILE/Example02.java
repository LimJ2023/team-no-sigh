package chapter03.WHILE;

import java.util.Scanner;

public class Example02 {

	public static void main(String[] args) {

		boolean run = true;
		
		int balance = 0;
		
		Scanner scan = new Scanner(System.in);
		// 예외처리 -> 예금을 0원,-로 가능한점, 출금이 마이너스 통장이 되는점,
		while(run) {
			System.out.println("========================");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("=======================");
			System.out.print("선택 > ");
			
			int menuNumber = scan.nextInt();
			
			switch (menuNumber) {
			case 1:
				System.out.print("예금하기 > ");
				balance += scan.nextInt();
				break;
			case 2:
				System.out.print("출금하기 > ");
				balance -= scan.nextInt();
				break;
			case 3:
				System.out.print("잔고확인");
				System.out.println(balance);
				break;
			case 4:
				System.out.println("종료");
				run = false;
				break;

			default:
				System.out.println("잘못된 번호입니다.");
				break;
			}//switch
		}//while
		System.out.println("프로그램 종료");
		scan.close();
	}//main

}
