package chapter03.WHILE;

import javax.swing.JOptionPane;

public class WhileTest07 {

	public static void main(String[] args) {

		int num1;
		int num2;
		
		do {
			num1 = Integer.parseInt(JOptionPane.showInputDialog("OTB DB"));
			num2 = Integer.parseInt(JOptionPane.showInputDialog("OTB USER"));
			
			if(num1 == num2) {
				System.out.println("인증 성공!");
			}else {
				System.out.println("다시 입력하세요");
			}
		} while (num1 != num2); // db와 user의 값이 같을 떄까지 반복
	}
}
