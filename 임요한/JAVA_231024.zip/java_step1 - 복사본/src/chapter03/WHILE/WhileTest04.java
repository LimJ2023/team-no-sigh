package chapter03.WHILE;

import java.util.Scanner;

public class WhileTest04 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		
		while(true) {
			System.out.print("Java 과목 점수를 입력하세요 : ");
			int score = scan.nextInt();
			
			//점수가 0미만이거나 100초과면 중지
			if(score < 0 || score > 100) {
				break;
			}else if (score >= 60) {
				System.out.println("합격하셨습니다.");
				break;
			}else {
				System.out.println("불합격하셨습니다.");
				break;
			}
		}//while
		System.out.println("프로그램 종료");
		scan.close();
	}

}
