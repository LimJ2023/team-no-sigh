package chapter03.WHILE;

import java.util.Scanner;

public class Example06_2 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
	      int br1=0, br2=0, main=0, br3=0, br4=0;
	      String brName="";
	      
	      
	      while(true) {
	         
	      System.out.println("======================================");   
	      System.out.println("1.빵 개수만 선택 | 2.빵 개수와 종류 선택 | 3.종료");
	      System.out.println("======================================");
	      System.out.print("선택>>");
	      main=scan.nextInt();
	   
	      if(main == 1)
	      {   
	         System.out.print("빵 개수 입력 : ");
	         br1=scan.nextInt();
	         
	         for(br2=1; br2<=br1; br2++)
	         {
	            System.out.println("빵 " + br2 + "개");
	         }
	         System.out.println("빵 " + br1 + "개가 완성 되었습니다");
	      }
	      else if(main == 2)
	      {   
	         System.out.print("빵 개수 입력 : ");
	         br3=scan.nextInt();
	         
	         System.out.print("종류 선택 : ");
	         brName=scan.next();
	         
	         for(br4=1; br4<=br3; br4++)
	         {
	            System.out.println(brName + "빵 " + br4 + "개");
	         }
	         System.out.println(brName + "빵 " + br3 + "개가 완성 되었습니다");
	      }   
	      else if(main == 3)
	      {
	         System.out.println("프로그램 종료");
	         break;
	      }
	      else
	      {
	         System.out.println("잘못된 값입니다 다시 입력해 주세요.");
	      }
	      System.out.println();
	      }
	      scan.close();
	   }

}
