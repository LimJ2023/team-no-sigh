package chapter03.WHILE;

import java.util.Random;
import java.util.Scanner;

public class Example04 {

	public static void main(String[] args) {

		/* 숫자 맞추기 게임
		 * 1부터 100사이의 무작위 숫자를 선택하고, 당신은 그 숫자를 맞추는 게임입니다.
		 * 만약 당신이 입력한 숫자가 컴퓨터가 선택한 숫자보다 크면 "더 작은 숫자를 추측하세요."
		 * 입력한 숫자가 '''' 작으면 "더 큰 숫자를 추측하세요." 출력
		 * 선택한 숫자를 정확히 맞출떄까지 반복
		 * 걸린 시도 회수를 출력하여 축하 메시지 출력
		 */
		
		Scanner scan = new Scanner(System.in);
		Random random = new Random();
		
		int targetNumber = random.nextInt(100)+1;
		
		int guessNumber;
		int attempts = 0;
		
		System.out.println("1부터 100사이의 숫자를 맞춰보세요.");
		
		do {
			System.out.print("숫자를 입력해주세요 : ");
			guessNumber = scan.nextInt();
			
			if(guessNumber > targetNumber) {
				System.out.println("더 작은 숫자를 선택하세요.");
			}
			if(guessNumber < targetNumber) {
				System.out.println("더 큰 숫자를 선택하세요.");
			}
			attempts++;
		} while (guessNumber != targetNumber); 
		
			// 두번의 참/거짓 판별.
			//1.while의 동작 o x 판별
			//2.guess와 target의 동일함 판별
			// 논리연산자 != 는 두개를 비교해 다르면 true, 같으면 false를 반환( == 는 그 반대)
			// 목표숫자와 입력숫자가 다르면 true -> while(o/x)에도 true 작동 -> do를 다시 실행
			// 목표숫자와 입력숫자가 같다면 false -> while(o/x)에도 false작동 do while()을 탈출
		
		System.out.println("축하합니다. 목표 숫자는 : " + targetNumber );
		System.out.println("당신의 시도 회수는 " + attempts);
		
		scan.close();
		
	}

}
