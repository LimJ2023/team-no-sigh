package chapter03.WHILE;

public class WhileTest01 {

	public static void main(String[] args) {

		while(true) {
			int num = (int)(Math.random()*6)+1; //1에서 6까지 난수
			System.out.print("주사위의 눈 : " + num);
			System.out.println();
			
			if(num == 6) {
				break;
			}
		}//while
		System.out.println("프로그램 종료");
	}

}
