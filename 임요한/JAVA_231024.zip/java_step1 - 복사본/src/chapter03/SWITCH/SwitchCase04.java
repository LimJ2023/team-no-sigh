package chapter03.SWITCH;

public class SwitchCase04 {

	public static void main(String[] args) {

		//오전 9시부터 오후6시
		int time = (int) (Math.random()*10)+9;
		
		System.out.print("할 일: ");
		
		switch (time) {
		case 9: case 16:
			System.out.println("잠자기");
			break;
		case 10: case 17:
			System.out.println("휴식하기");
			break;
		case 11: case 18:
			System.out.println("잠자기2");
			break;
		case 12: case 19:
			System.out.println("밥먹기");
			break;
		case 13: case 20:
			System.out.println("롤");
			break;
		case 14: case 21:
			System.out.println("배그");
			break;
		case 15: case 22:
			System.out.println("발로란트");
			break;
		default:
			System.out.println("정해지지 않은 시간대입니다.");
			break;
		}//switch
		
	}

}
