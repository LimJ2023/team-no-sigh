package chapter03.SWITCH;

import java.util.Scanner;

public class Example01 {

	public static void main(String[] args) {

		//스캐너 사용해서 값 입력받기
		// A,a -> 우수 고객 / B,b : 일반회원 / 나머지 -> 일반고객
		// 스위치케이스 사용.
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("등급을 입력해주세요 : ");
		char customer = scanner.nextLine().charAt(0);
		//철자 수정
		switch (customer) {
		case 'a': case 'A':
			System.out.println("최우수 고객 입니다.");
			break;
		case 'B': case 'b':
			System.out.println("우수 고객 입니다.");
			break;
		default:
			System.out.println("일반 고객 입니다.");
			break;
		}//switch
		
		scanner.close();
	}//main

}
