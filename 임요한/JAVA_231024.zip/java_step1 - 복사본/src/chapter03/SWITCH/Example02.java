package chapter03.SWITCH;

import java.util.Scanner;

public class Example02 {

	public static void main(String[] args) {

		/*사용자로부터 월으 입력받아 해당 월의 계절을 출력하는 프로그램을 작성하세요
		 * 봄 3~5, 여름 6~8월 가을9~11 겨울 12~2월
		 */
		Scanner scan = new Scanner(System.in);
		
		System.out.print("월을 입력해주세요. : ");
		int month = scan.nextInt();
		
		switch (month) {
		case 3: case 4: case 5:
			System.out.println("봄 입니다.");
			break;
		case 6: case 7: case 8:
			System.out.println("여름 입니다.");
			break;
		case 9: case 10: case 11:
			System.out.println("가을 입니다.");
			break;
		case 12: case 1: case 2:
			System.out.println("겨울 입니다.");
			break;

		default:
			System.out.println("유효하지 않은 월입니다.");
			break;
		}
		
		scan.close();
	}

}
