package chapter03.IF;

import javax.swing.JOptionPane;

public class IfExample07 {

	public static void main(String[] args) {

		//서버
		String ID = "soldesk";
		int PW = 231108;
		
		//고객
		String id = JOptionPane.showInputDialog("아이디");
		int pass = Integer.parseInt(JOptionPane.showInputDialog("비밀번호"));
		
		
		
		if(ID.equals(id)) {
			if(PW == pass) {
				System.out.println(ID + " 로그인 성공");
			}else {
				System.out.println("비밀번호가 다릅니다.");
			}
		}else {
			System.out.println("아이디가 다릅니다.");
		}
		
		
		
		/*
		 * if(id == ID && pass == PW) { System.out.println("로그인 성공"); }else if (id ==
		 * ID) { System.out.println("비밀번호가 다릅니다."); ; }
		 */
	}

}
