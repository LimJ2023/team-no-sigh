package chapter03.IF;

import java.util.Scanner;

public class Example02 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		System.out.println("성별을 입력하세요. (F/M) : ");
		char gender = scanner.nextLine().charAt(0);
		
		if(gender == 'F') {
			System.out.println("여성 입니다.");
		}else {
			System.out.println("남성 입니다.");
		}
		
		System.out.println("===============");
		
		//ch에 y 또는 Y이면 메뉴를 입력하세요를 출력
		
		System.out.println("메뉴를 보시겠습니까 Y or y");
		char ch = scanner.nextLine().charAt(0);
		
		if(ch == 'Y' || ch == 'y') {
			System.out.print("메뉴를 입력하세요. : ");
			String menu = scanner.nextLine();
			System.out.println(menu);
		}else {
			System.out.println("이용해주셔서 감사합니다.");
		}
		
		scanner.close();
	}

}
