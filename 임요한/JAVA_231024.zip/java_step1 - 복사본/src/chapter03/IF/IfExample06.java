package chapter03.IF;

public class IfExample06 {

	public static void main(String[] args) {

		// 1부터 6까지 랜덤 정수 생성
		int num = (int) (Math.random()*6) + 1;
		
		if(num ==1) {
			System.out.println("초밥");
		}else if (num == 2) {
			System.out.println("피자");
		}else if (num == 3) {
			System.out.println("제육");
		}else if (num == 4) {
			System.out.println("돈가스");
		}else if (num == 5) {
			System.out.println("국밥");
		}else {
			System.out.println("프로틴");
		}
	}

}
