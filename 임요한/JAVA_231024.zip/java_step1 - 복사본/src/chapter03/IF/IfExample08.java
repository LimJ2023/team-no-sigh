package chapter03.IF;

import java.util.Scanner;

public class IfExample08 {
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("아이디 : ");
		String ID = scanner.nextLine();
		
		System.out.print("비밀번호 : ");
		String PW = scanner.nextLine();
		int pass = Integer.parseInt(PW);
		
		if(ID.equals("soldesk")) {
			if(pass == 1108) {
				System.out.println("로그인 성공");
			}else {
				System.out.println("비밀번호가 다릅니다.");
			}
		}else {
			System.out.println("로그인 실패");
		}
		
		scanner.close();
	}//main
}
