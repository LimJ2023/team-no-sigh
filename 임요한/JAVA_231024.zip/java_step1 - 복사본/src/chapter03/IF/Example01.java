package chapter03.IF;

import java.util.Scanner;

public class Example01 {

	public static void main(String[] args) {

		/*정보처리기사의 과목 정답 개수를 int형 타입 변수 5개에 입력받으세요(스캐너)
		 * 소프트웨어설계(soft1)
		 * 소프트웨어개발(soft2)
		 * 데이터베이스구축(DB)
		 * 프로그래밍언어활용(pro)
		 * 정보시스템구축(os)
		 * 한 과목이라도 8개 미만, 전체개수가(sum) 60개 미만일 경우 불합격입니다로 출력
		 * 그렇지 않으면 합격입니다로 출력.
		 */
		Scanner scanner = new Scanner(System.in);
		System.out.print("소프트웨어설계 점수 입력 : ");
		int soft1 = scanner.nextInt();
		System.out.print("소프트웨어개발 점수 입력 : ");
		int soft2 = scanner.nextInt();
		System.out.print("데이터베이스구축 점수 입력 : ");
		int DB = scanner.nextInt();
		System.out.print("프로그래밍언어활용 점수 입력 : ");
		int pro = scanner.nextInt();
		System.out.print("정보시스템구축 점수 입력 : ");
		int os = scanner.nextInt();
		
		int sum = soft1 + soft2 + DB + os + pro;
		
		if(soft1 >= 8 && soft2 >= 8 && DB >= 8 && pro >= 8 && os >= 8) {
			if(sum >= 60) {
				System.out.println("합격입니다.");
			}else {
				System.out.println("전체점수부족 입니다.");
			}
		}else {
			System.out.println("과목점수 부족 입니다.");
		}
		
		scanner.close();
	}

}
