package chapter03.FOR;

import java.util.Scanner;

public class ForTest09 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("숫자를 입력하세요 : ");
		int i,j;
		int n = scan.nextInt();
		
		for(i = 1; i <= n; i++) { // row의 개수 (줄의 개수) n번 생성.
			for(j = 1; j <= i; j++) { // col의 개수(찍히는 별의 개수) 줄 수만큼 찍음.
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
