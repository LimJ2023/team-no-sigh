package chapter03.FOR;

import java.util.Scanner;

public class ForTest05_1 {

	public static void main(String[] args) {

		//10개의 정수를 입력받아 3의 배수와 5의 배수를 출력하세요
		Scanner scan = new Scanner(System.in);
		
		int a, cnt3=0, cnt5=0;
		
		//10번 반복하기
		for (int i = 1; i <= 10; i++) { // cnt <- 카운트 하는 용도로 생각
			System.out.print("정수를 입력하세요. ");
			a = scan.nextInt();
			
			if(a%3 == 0) {
				System.out.println("3의 배수 " + a);
				cnt3++;
				System.out.println();
			}
			if(a%5 == 0) {
				System.out.println("5의 배수 " + a);
				cnt5++;
			}
		}//for
		System.out.println();
		System.out.println(cnt3 + " 3의 배수는 몇개");
		System.out.println(cnt5 + " 5의 배수는 몇개");
		scan.close();
	}//main

}
