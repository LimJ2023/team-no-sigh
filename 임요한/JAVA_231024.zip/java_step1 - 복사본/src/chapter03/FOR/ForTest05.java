package chapter03.FOR;

import java.util.Scanner;

public class ForTest05 {

	public static void main(String[] args) {

		//10개의 정수를 입력받아 3의 배수와 5의 배수를 출력하세요
		Scanner scan = new Scanner(System.in);
		
		int a, cnt3=0, cnt5=0;
		
		//10번 반복하기
		for (int i = 0; i < 10; i++) {
			System.out.print("정수를 입력하세요. ");
			a = scan.nextInt();
			
			if(a%3 == 0 && a != 0) { //a가 3의 배수일때 + a가 0일때의 예외처리
				if(a%5 == 0) { //a가 3과 5를 동시에 만족할 때의 처리
					cnt3 = a;
					cnt5 = a;
					System.out.println(cnt3 + "는 3과 5의 배수입니다.");
				}else {
					cnt3 = a;
					System.out.println(cnt3 + "는 3의 배수입니다.");
				}
			}
			else if (a%5 == 0 && a != 0) { // a5의 배수일때 + a가 0일때의 예외처리
				cnt5 = a;
				System.out.println( cnt5 + "는 5의 배수입니다.");
			}
			else {
				System.out.println("3,5의 배수가 아닙니다.");
			}
		}
		System.out.println("프로그램 종료");
		scan.close();
	}

}
