package chapter03.FOR;

import java.util.Scanner;

public class ForTest07 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.println("단을 입력하세요.");
		int dan = scan.nextInt();
		
		for (int i = 1; i < 10; i++) {
			System.out.println(dan + "*" + i + "=" + (dan*i));
		}
		
		scan.close();
	}

}
