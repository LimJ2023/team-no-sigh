package chapter03.FOR;

public class ForTest03 {

	public static void main(String[] args) {
		
		//0~100까지의 수 중 홀수값만 합하기
		int num;
		int total = 0;
		
		for (num = 0; num <= 100; num++) {
			if(num%2 == 0) {
				continue; // 넘어가기
			}
			System.out.print(num + " ");
			total += num;
		}
		System.out.println();
		System.out.println("0~100까지 홀수의 합은 " + total);
	}

}
