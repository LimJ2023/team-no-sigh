package chapter03.FOR;

import java.util.Scanner;

public class ForTest04 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		
		int i;
		System.out.print("0보다 크면서 11보다 작은 숫자를 입력하세요 : ");
		int a = scanner.nextInt();
		
		if(a > 0 && a < 11) {
			for(i = 1; i <= a; i++) {
				System.out.println("Java 프로그래밍");
			}
		}else {
			System.out.println("입력값이 잘못되었습니다.");
		}
		System.out.println("프로그램이 종료됩니다.");
		
		scanner.close();
	}

}
