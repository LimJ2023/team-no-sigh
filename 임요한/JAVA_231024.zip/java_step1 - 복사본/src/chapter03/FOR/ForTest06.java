package chapter03.FOR;

import java.util.Scanner;

public class ForTest06 {

	public static void main(String[] args) {
		//몇 명의 성적을 입력 받을 것인지 정수로 학생 수를 입력 받고,
		// 총점과 평균을 구하세요. (단, 평균은 실수로 출력할 것)
		
		Scanner scan = new Scanner(System.in);
		
		//int cnt = 0;
		int totalScore = 0;
		double totalAvg = 0;
		System.out.print("학생이 몇 명인가요? : ");
		int studentNumber = scan.nextInt();
		
		
		for(int i = 1; i <= studentNumber; i++) {
			System.out.print(i + "번째의 성적을 입력하세요. : ");
			int score = scan.nextInt();
			totalScore += score;
			//cnt++; // 학생수 증가
		}
		
		
		//계산 단계에서 실수형으로 출력하도록 형변환.
		totalAvg = (double) totalScore / studentNumber;
		
		System.out.println("학생의 총점은 : " + totalScore);
		System.out.printf("학생들의 평균은 : %10f", totalAvg);
		
		scan.close();
	}

}
