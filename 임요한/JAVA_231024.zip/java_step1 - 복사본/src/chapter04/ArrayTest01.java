package chapter04;

public class ArrayTest01 {

	public static void main(String[] args) {
		
		int number1[] = new int[10];
		System.out.println(number1);
		int[] number2 = new int[10];
		System.out.println(number2);
		
		int[] number3;
		number3 = new int[10];
		System.out.println(number3);
		
		int number4[] = new int[] {1,2,3,4,5,6,7,8,9,10};
		int number5[] = {1,2,3,4,5,6,7,8,9,10};
		System.out.println(number5);
		
		for (int i = 0; i < number4.length; i++) {
			System.out.println(number4[i]);
		}
	}//main

}
