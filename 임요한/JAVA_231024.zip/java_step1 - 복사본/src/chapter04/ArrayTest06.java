package chapter04;

public class ArrayTest06 {

	public static void main(String[] args) {

		//배열에 저장된 숫자들의 합과 평균 계산
		
		int[] numbers = {5,10,15,20,25};
		int sum = 0;
		
		for (int i = 0; i < numbers.length; i++) {
			sum += numbers[i];
			//int num에 number[i]를 대입하여 사용가능
		}
		
		double averager = (double) sum / numbers.length;
		System.out.println("총 합계는 : " + sum);
		System.out.println("평균 : " + averager);
	}

}
