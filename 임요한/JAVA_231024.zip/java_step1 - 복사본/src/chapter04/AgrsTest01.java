package chapter04;

public class AgrsTest01 {

	public static void main(String[] args) {

		//배열 선언과 초기화
		int[] number = new int[5];
		
		number[0] = 10;
		number[1] = 20;
		number[2] = 30;
		number[3] = 40;
		number[4] = 50;
		
		
		for(int i = 0; i < number.length; i++) { // 배열의 모든 요소를 전부 순회
			System.out.println("인덱스에 있는 요소" + i + " : " + number[i]);
		}
	}

}
