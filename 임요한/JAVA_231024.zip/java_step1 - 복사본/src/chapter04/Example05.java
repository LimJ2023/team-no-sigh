package chapter04;

public class Example05 {

	public static void main(String[] args) {

		//for문을 이용하여 다음 배열의 점수를 줄단위 평균 구하기
		
		int[][] array = {{95, 86},{83,92,96 },{78,83,93,87,88 }};
		
		double avg = 0;
		int count = 0;
		
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {
				count += array[i][j];
			}
			avg = (double) count / array[i].length;
			
			System.out.println("인덱스 " + i + "의 점수 합은 " + count);
			System.out.println("평균은 " + avg);
			count = 0;
			avg = 0;
		}
	}

}
