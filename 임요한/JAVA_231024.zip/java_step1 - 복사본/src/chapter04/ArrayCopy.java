package chapter04;

public class ArrayCopy {

	public static void main(String[] args) {
		
		int array1[] = {10,20,30,40,50};
		int array2[] = {1,2,3,4,5};
		
		
		for (int i : array1) {
			System.out.println(i);
		}
		System.out.println("=====================");
		
		for (int i : array2) {
			System.out.println(i);
		}
		System.out.println("=================");
		
		//배열 복사
		//복사할 배열, 첫위치, 대상배열, 붙여넣을 위치, 복사할요소 개수
		System.arraycopy(array1, 1, array2, 1, 3);
		
		for (int i = 0; i < array2.length; i++) {
			System.out.print(array2[i] + " ");
		}
		
	}

}
