package chapter04;

public class Example01 {

	public static void main(String[] args) {

		int score[] = {98,90,87};
		int sum = 0;
		
		for (int i = 0; i < score.length; i++) {
			sum += score[i];
		}
		double average = (double)sum / score.length;
		
		System.out.println(" 합계는 : " + sum + "입니다.");
		
		System.out.println("평균(반올림):" + Math.round(average));
		// 평균 반올림 
		System.out.printf(" 평균은 : %.3f 입니다.", average); 
				//printf 명령문 사용 %f -> 실수형
				// %.3f < -소수점 셋째자리까지 출력
		//반올림
		
	}//main

}
