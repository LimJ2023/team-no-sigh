package chapter04;

public class EnhancedForLoop03 {

	public static void main(String[] args) {

		int[] numbers = {5, 10, 15, 20, 25};
		int sum=0;
		
		for (int i : numbers) {
			sum += i;
		}
		
		System.out.println(" 합계 : " + sum);
		
		
	}

}
