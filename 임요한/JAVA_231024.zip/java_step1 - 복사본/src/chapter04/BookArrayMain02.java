package chapter04;

public class BookArrayMain02 {
	public static void main(String[] args) {
		
		Book[] library = new Book[5];
		
		//library[0].setBookName("데미안");
		//library[0].setAuthor("헤르만헤세");
		
		library[0] = new Book("데미안", "헤르만헤세");
		library[1] = new Book("빨간머리앤", "몽고메리");
		library[2] = new Book("백설공주", "그림형제");
		library[3] = new Book("카산드라의 거울", "베르나르베르베르");
		library[4] = new Book("어린왕자", "생택쥐페리");
		
		//library[2].bookName = "책3";
		//library[2].author = "저자3";
		
		//요소 하나씩 확인
		library[0].showBookInfo();
		
		//배열 요소 전체 추출
		for (Book book : library) {
			book.showBookInfo();
		}
		
	}
}
