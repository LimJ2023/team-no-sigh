package chapter04;

public class EnhancedForLoop01 {

	public static void main(String[] args) {
		
		String strArray[] = {"Java", "Oracle", "Html5", "CSS", "JSP", "Spring"};
		
		for (int i = 0; i < strArray.length; i++) {
			System.out.println(strArray[i]);
		}
		
		System.out.println();
		
		//간편한 반복문, 배열의 모든 요소들을 추출할 때 씀
		for (String string : strArray) {
			System.out.println(string);
		}
		
	}

}
