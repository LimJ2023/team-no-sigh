package chapter04;

public class BookArrayMain01 {

	public static void main(String[] args) {

		//Book book1 = new Book();
		Book[] books = new Book[5];
		
		for(Book bk : books) {
			bk.showBookInfo();
		}
		
		for (int i = 0; i < books.length; i++) {
			books[i].showBookInfo();
		}
		
	}

}
