package chapter04;

public class AgrsTest02 {

	public static void main(String[] args) {

		//배열 선언
		int a[] = new int[5];
		System.out.println(a);
		
		//배열선언2
		int[] b;
		b = new int[5];
		System.out.println(b);
		int aVal;
		int bVal;
		int Total;
		
		//배열 선언3
		args = new String[2];
		args[0] = "1";
		args[1] = "2";
		
		//String[] str; // String str[]; 가능
		//str = new String[10];
		
		if(args.length == 2) { //배열의 길이가 2라면.
			aVal = Integer.parseInt(args[0]); // [0]에 있는 1
			bVal = Integer.parseInt(args[1]);// [1]에 있는 2
		}else {
			aVal = 0;
			bVal = 0;
		}
		
		Total = aVal + bVal; // 1 + 2;
		System.out.println(Total);
		
	}

}
