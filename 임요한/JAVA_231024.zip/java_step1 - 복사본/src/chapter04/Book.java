package chapter04;

public class Book {
	
	
	//멤버변수
	public String bookName;
	public String author;
	
	//생성자
	public Book() {
		
	}
	//생성자 오버로딩
	public Book(String bookName, String author) {
		this.bookName = bookName;
		this.author = author;
	}
	
	//메서드
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public void showBookInfo() {
		System.out.println("책이름 : " + bookName + "| 저자 : " + author);
	}
	
	
}
