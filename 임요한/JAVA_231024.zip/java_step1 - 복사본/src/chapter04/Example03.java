package chapter04;

import java.util.Scanner;

public class Example03 {

	public static void main(String[] args) {

		//사용자에게 인덱스를 알고싶은 숫자를 1에서 10까지 입력받아
		//해당 숫자의 인덱스를 찾아 출력하는 프로그램을 만드세요.
		//사용자가 입력한 값이 인덱스로 나타낼수 없는 경우 찾을 수 없다는 문구를 출력하세요.
		
		int[] number = {10,3,2,1,4,8,7,9,5,6};
		int target;
		int index = -1; // 일반적으로 -1은 배열 인덱스를 나타낼 수 없는 값을 사용.
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("인덱스를 알고싶은 숫자 1~10사이로 입력하세요.");
		target = scan.nextInt();
		
		
		for (int i = 0; i < number.length; i++) {
			if(target == number[i]) { // 입력한 숫자와 배열의 데이터값이 일치할 떄
				index = i; // index의 값을 i번째 순서(현재 배열의 인덱스)로 대입
				System.out.println("해당 숫자의 인덱스 값은 " + index);
				break;
			}
		}
		if(index == -1) { // 만약 인덱스 값이 변하지 않았다면 -1임
			System.out.println("입력한 값과 맞는 인덱스를 찾을 수 없습니다.");
		}
		
		scan.close();
	}//main

}
