package chapter04;

public class Example02 {

	public static void main(String[] args) {

		
		//배열에서 최대값을 찾아 출력하세요.
		int max = 0;
		int max2 = 0;
		int array[] = {1, 6, 9, 2, 35, 178, 234, 4, 5, 11, };
		
		for (int i = 0; i < array.length; i++) {//비교하기
			
			if(max < array[i]) { // max값보다 현재 배열의값이 더 크면
				max = array[i]; // max값을 배열에 있던 수로 대입
			}
		}
		
		for (int i : array) {
			if(max2 < i)
				max2 = i;
		}
		System.out.println(max);
		System.out.println(max2);
		
		
	}
}
