package chapter04;

import java.util.Scanner;

public class Example04 {

	public static void main(String[] args) {
		//점수리스트 배열
		//학생수
		//분석 최고점수 총점 평균
		//점수입력 -> 학생수만큼
		// 
		boolean run = true; //while문 종료 트리거
		Scanner scan = new Scanner(System.in);
		int selectMenu; //입력받은 선택지 숫자 <-맨처음 scan.next로 초기화가 되었음
		int studentNumber = 0; // 학생수
		int[] studentArr = null; // 학생들이 모인 배열
		
		
		while(run) {
			System.out.println("========================");
			System.out.println("1.학생수 | 2.점수입력 | 3.점수리스트 | 4.분석 | 5.종료");
			System.out.println("=======================");
			System.out.print("선택 > ");
			selectMenu = scan.nextInt();
			if(studentArr == null && selectMenu != 1 && selectMenu != 5) { // 학생수를 입력한적이 없고, 맨처음 1과5을 누르지 않았다면.
				System.out.println("학생이 아무도 없습니다. 학생수를 입력해주세요.");
				continue;
			}
			else if( selectMenu == 5) { //아무것도 하지 않고  5. 종료키를 누를 시 예외처리
				System.out.println("종료합니다.");
				run = false;
			}
			else {
				switch (selectMenu) {
				case 1: // 학생수
					System.out.print("학생수는 : ");
					studentNumber = scan.nextInt();
					studentArr = new int[studentNumber]; // 입력받은 수만큼 학생의 배열 생성
					break;
				case 2: // 점수입력
					for (int i = 0; i < studentArr.length; i++) {
						System.out.print("score[" + i + "] : "); 
						int inputStdScore = scan.nextInt();
						studentArr[i] = inputStdScore; // 입력받은 수를 차례대로 점수에 대입
					}
					break;
				case 3: //점수리스트
					for (int i = 0; i < studentArr.length; i++) {
						System.out.println("score[" + i + "] : " + studentArr[i]);
					}
					break;
				case 4:// 분석
					int totalScore = 0; //총점
					double average = 0; // 평균
					
					System.out.println("학생수 : " + studentNumber); // 학생수 보여주기
					
					for (int i = 0; i < studentArr.length; i++) { // 총점수 계산을 위해 모든 학생의 점수를 차례대로 더해주기
						totalScore += studentArr[i];
					}
					System.out.println("학생 총점 :" + totalScore);
					
					average = (double) totalScore / studentNumber; // 총점수와 학생수를 이용해 평균 구하기
					System.out.println("평균 : " + average);
					break;
				case 5: //종료A
					System.out.println("종료합니다.");
					run = false; // while문을 종료하기 위한 boolean값
					break;
				default:
					System.out.println("번호를 잘못 입력하셨습니다.");
					break;
				}//switch
			}
		}//while
		
		scan.close();
		
	}//main

}
