package schoolInfo;

public class InfoMain {

	public static void main(String[] args) {

		Info kinderInfo = new Info(); // 객체생성

		kinderInfo.setSchoolAdd("서울특별시 종로구 종로12길 15"); // 유치원 주소 추가하기
		kinderInfo.setSchoolTel("010-4194-0138"); // 유치원 연락처 추가하기

		kinderInfo.showInfo(); // 유치원 정보 표시하기
	}

}
