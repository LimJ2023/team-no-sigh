package schoolInfo;

public class Info {
	
	private String schoolName = "한샘유치원"; //유치원 이름(고정)
	private String schoolTel; //유치원 연락처
	private String schoolAdd; //유치원 주소
	
	
	
	public String getSchoolName() {
		return schoolName;
	}
	
	public String getSchoolTel() {
		return schoolTel;
	}
	public void setSchoolTel(String schoolTel) { //유치원 연락처 등록하기
		this.schoolTel = schoolTel;
	}
	public String getSchoolAdd() {
		return schoolAdd;
	}
	public void setSchoolAdd(String schoolAdd) { // 유치원 주소 등록하기
		this.schoolAdd = schoolAdd;
	}
	
	
	public void showInfo() { //유치원 정보 표시하기
		System.out.println("기관 등록명 : " + schoolName);
		System.out.println("연락처 : " + schoolTel);
		System.out.println("주소 : " + schoolAdd);
	}
}
