package com.test;


public class Buys {
	public Item[] items;
	
	
	public Buys() {
		init();
	}
	public void init() {
		items = new Item[4];
		
		items[0] = new Item("1호", 10000);
		items[0].setCount(5);
		items[1] = new Item("2호", 20000);
		items[1].setCount(5);
		items[2] = new Item("3호", 30000);
		items[2].setCount(5);
		items[3] = new Item("4호", 40000);
		items[3].setCount(5);
	}
	
	public void showInfo() {
		for (int i = 0; i < items.length; i++) {
			System.out.println(items[i].getName() + "의 가격은 " + items[i].getPrice());
			System.out.println("재고는 " + items[i].getCount() + "개 있음");
		}
	}
	
	public String buyItem(int num, int count) {
		int index = num-1;
		if(items[index].getCount() > 0 && items[index].getCount() >= count) {
			items[index].subCount(count);
			return items[index].getName() + " " + count + "개 구매 완료!";
		}
		else if (items[index].getCount() < count) {
			return items[index].getName() + "의 재고 이상은 구입 불가";
		}
		else {
			return "재고가 없음";
		}
		
		
	}
}
