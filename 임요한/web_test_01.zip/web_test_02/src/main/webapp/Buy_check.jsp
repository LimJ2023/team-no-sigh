<%@page import="com.test.Buys"%>
<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1>구매완료</h1>
	<%
	Buys buy = new Buys();
	int num1 = Integer.parseInt(request.getParameter("count1")); //1호를 몇개
	int num2 = Integer.parseInt(request.getParameter("count2")); //2호를 몇개
	%>
	
	<div>
	<% out.print(buy.buyItem(1, num1)); %> <br />
	<% out.print(buy.buyItem(2, num2)); %> <br />
	</div>
	
	<div>
		<%for (int i = 0; i < buy.items.length; i++) {
			out.print(buy.items[i].getName() + "의 가격은 " + buy.items[i].getPrice());%> <br />
			<%
			out.print("재고는 " + buy.items[i].getCount() + "개 있음");%> <br />
		<%} %>
	</div>
</body>
</html>