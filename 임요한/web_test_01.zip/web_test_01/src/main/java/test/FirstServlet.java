package test;

import java.io.*;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/hello2")
public class FirstServlet extends HttpServlet{
	
	@Override
	public void init() throws ServletException {
		System.out.println(" init() 실행됨!");
	}
	
	
}
