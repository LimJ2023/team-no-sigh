<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<% if(session.isNew() || session.getAttribute("id") == null) {%>
<%
	String msg = (String)request.getAttribute("error");
	if(msg == null) msg = "";
%>
<%= msg %>

<h1>회원 가입</h1>
	<hr />
	<form action="testjsp01.jsp" method="post">
		<fieldset>
			<legend>계정 정보</legend>
			<div>
				<label for="id-account">아이디</label>
				<input type="text" name="id" id="id-account" />
			</div>
			<div>
				<label for="pw-account">비밀번호</label>
				<input type="password" name="pw" id="pw-account" />
			</div>
			<div>
				<label>비밀번호 확인</label>
				<input type="password" name="pw2" id="pw-account2" />
			</div>
		</fieldset>
		
		<fieldset>
			<legend>프로필</legend>
			
			<div>
				<label>이름</label>
			 	<input type="text" name="name"/><br />
			</div>
			
			<div>
				<label>성별</label>
				<input type="radio" id="gen-male" name="gender" value="male" /> 남
				<input type="radio" id="gen-female" name="gender" value="female" /> 여
				<input type="radio" id="gen-etc" name="gender"  value="etc" /> 기타
			</div>
			
			<div>
				<label>취미</label>
				<input type="checkbox" name="hobby" value="climbing" /> 등산
				<input type="checkbox" name="hobby" value="sports" /> 운동
				<input type="checkbox" name="hobby" value="reading" /> 독서
				<input type="checkbox" name="hobby" value="traveling" /> 여행
			</div>
			
			<div>
				<label for="">종교</label>
				<select name="religion" id="">
					<option value="Christianity">기독교</option>
					<option value="Buddhism">불교</option>
					<option value="Catholicism">천주교</option>
					<option value="atheism">무교</option>
				</select>
			</div>
			
			<div>
				자기소개: <br />
				<textarea name="introduction" id="" cols="30" rows="10"></textarea>
			</div>
		</fieldset>
		
		<div>
			<input type="submit" value="가입하기"/>
			<input type="reset" value="지우기" />
		</div>
		
	</form>
<%} else { %>
	<a href="testjsp01.jsp">로그아웃</a>
<% } %>
	
	
</body>
</html>