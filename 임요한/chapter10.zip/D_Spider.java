package chapter10;

public class D_Spider extends D_Animal{
	
	String web = "거미줄";

	@Override
	public int getEye() {
		return 8;
	}

	@Override
	public int getLeg() {
		return 8;
	}
	
	
}
