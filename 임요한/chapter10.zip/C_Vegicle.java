package chapter10;

public class C_Vegicle {
	
	private static final int price =1000;
	
	public int vehiclePrice() {
		return C_Vegicle.price; // 스테틱변수는 클래스로 바로 접근
	}
	
	public void run() {
		System.out.println("차량이 달립니다.");
	}
	
	
}
