package chapter10;

public class A_CustomerMain {

	public static void main(String[] args) {

		System.out.println("==========vip고객=========");
		int price = 10000;
		A_VIPCustomer vipCstmr = new A_VIPCustomer(1004, 1, "임요한1");
		
		int vipPrice = vipCstmr.calcPrice(price);
		
		System.out.println(vipCstmr.getCustomerName() + "님이 "+ vipPrice + "원을 지불하셨습니다.");
		System.out.println(vipCstmr.showCstmr());
		
		
		System.out.println("==========일반고객=========");
		price = 10000;
		A_Customer cstmr = new A_Customer(); //방법 1
		cstmr.setCustomerName("임요한2");
		System.out.println(cstmr.getCustomerName() + "님이 " + cstmr.calcPrice(price) + "원을 지불하였습니다.");
		System.out.println(cstmr.showCstmr());
		
		A_Customer cstmr2 = new A_Customer(2, "임요한3"); //방법 2
		//cstmr2.calcPrice(price);
		System.out.println(cstmr2.getCustomerName() + "님이 " + cstmr2.calcPrice(price) + "원을 지불하였습니다.");
		System.out.println(cstmr2.showCstmr() + " 회원번호 " + cstmr2.getCustomerID());
		
		System.out.println("==========vip고객=========");
		A_Customer vipCs2 = new A_VIPCustomer(1005,3,"임요한4");
		//상위 클래스의 형태로 하위 클래스에 있는 메서드를 생성(하위클래스만의 메서드 생성안됨)
		vipCs2.bonusPoint = 1000;
		int vipPrice2 = vipCs2.calcPrice(20000);
		System.out.println(vipCs2.getCustomerName() + "님이 "+ vipPrice2 + "원을 지불하셨습니다.");
		System.out.println(vipCs2.showCstmr());
	}
}
