package chapter10;

public class C_Taxi extends C_Vegicle{
	
	private int taxiNum = 1234;
	
	@Override
	public void run() {
		System.out.println(taxiNum + "번 택시가 달립니다.");
	}
	
}
