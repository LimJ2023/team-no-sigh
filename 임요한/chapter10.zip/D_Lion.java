package chapter10;

public class D_Lion extends D_Animal{
	
	String galgi = "카리스마";
}
