package chapter10;

public class C_Bus extends C_Vegicle{

private int busNum = 567;
	
	@Override
	public void run() {
		System.out.println(busNum + "번 버스가 달립니다.");
	}
}
