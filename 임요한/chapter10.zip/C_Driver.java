package chapter10;

public class C_Driver {
	
	//Vehicle 클래스의 상속 관계에 있는 클래스 객체를 매개변수에 넣어
	//같은 코드에서 다른 내용을 출력할 수 있다. (다형성을 이룰 수 있다.)
	public void drive(C_Vegicle vehicle) {
		vehicle.run();
	}
	
}
