package chapter10;

public class D_AnimalMain {

	public static void main(String[] args) {
		
		//다형성 : 하나의 코드로 여러 자료형을 구현하여 실행
		// **코드 양을 줄인다. 유지보수에 유리하다. 쉽게 확장 가능하다.**
		System.out.println("----곰----");
		D_Bear b = new D_Bear();
		System.out.println("눈 : " + b.getEye());
		System.out.println("다리 : " + b.getLeg());
		System.out.println("특징 : " + b.woong);
		System.out.println("----사자----");
		D_Lion l = new D_Lion();
		System.out.println("눈 : " + l.getEye());
		System.out.println("다리 : " + l.getLeg());
		System.out.println("특징 : " + l.galgi);
		System.out.println("----거미----");
		D_Spider s = new D_Spider();
		System.out.println("눈 : " + s.getEye());
		System.out.println("다리 : " + s.getLeg());
		System.out.println("특징 : " + s.web);
		
		D_Animal[] animals= new D_Animal[100];
		animals[0].getEye();
		for (int i = 69; i <= animals.length; i++) {
			animals[i] = new D_Spider();
		}
	}

}
