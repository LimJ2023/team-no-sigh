package chapter10;

public class A_Customer {
	
	protected int customerID;
	protected String customerName;
	protected String customerGrade;
	public double bonusPoint; //보너스 포인트 -> 고객이 구매시 누적
	protected double bonusRatio; // 보너스의 비율
	
	public A_Customer() {
		customerGrade = "SILVER"; // 기본등급
		bonusRatio = 0.01; // 기본 보너스 포인트 적립 비율
	}

	public A_Customer(int customerID, String customerName) {
		this.customerID = customerID;
		this.customerName = customerName;
		customerGrade = "SILVER"; // 기본등급
		bonusRatio = 0.01; // 기본 보너스 포인트 적립 비율
	}
	
	//지불금액 계산 메서드
	public int calcPrice(int price) {
		bonusPoint += bonusRatio * price;
		return price;
	}
	
	public String showCstmr() {
		return customerName+"님의 등급은 " + customerGrade + "이며 보너스 포인트는 " + 
				bonusPoint + "입니다.";
	}

	
	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerGrade() {
		return customerGrade;
	}

	public void setCustomerGrade(String customerGrade) {
		this.customerGrade = customerGrade;
	}

	public double getBonusPoint() {
		return bonusPoint;
	}

	public void setBonusPoint(double bonusPoint) {
		this.bonusPoint = bonusPoint;
	}

	public double getBonusRatio() {
		return bonusRatio;
	}

	public void setBonusRatio(double bonusRatio) {
		this.bonusRatio = bonusRatio;
	}
	
	
	
	
	
	
	
}
