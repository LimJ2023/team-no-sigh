package chapter10;

public class A_VIPCustomer extends A_Customer{
	
	int agentID;
	double saleRatio;
	
	//생성자
	public A_VIPCustomer(int agentID, int customerID, String customerName) {
		super.customerID = customerID;
		super.customerName = customerName;
		this.agentID = agentID;
		bonusRatio = 0.05; // 5% 적립
		saleRatio = 0.1; //할인율
	}

	@Override
	public int calcPrice(int price) {
		
		int finalPrice = (price - (int)(price * saleRatio)); // 할인율 적용한 최종가
		bonusPoint += finalPrice * bonusRatio; // 보너스 포인트 적용
		return finalPrice; // 최종가 반환
	}

	@Override
	public String showCstmr() {
		return super.showCstmr() + "\n전문상담원은 " + agentID + "입니다.";
	}

	public int getAgentID() {
		return agentID;
	}
	
	
	
	
	
	
	
}
