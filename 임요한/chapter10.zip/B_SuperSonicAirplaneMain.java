package chapter10;

public class B_SuperSonicAirplaneMain {

	public static void main(String[] args) {
		
		B_SuperSonicAirplane sa = new B_SuperSonicAirplane();
		
		sa.takeOff();
		sa.fly();
		
		//재정의 된 메서드와 부모의 메서드를 번갈아 사용중
		sa.flyMode = B_SuperSonicAirplane.SUPERSONIC;
		sa.fly();
		sa.flyMode = B_SuperSonicAirplane.NOMAL;
		sa.fly();
		sa.land();
	}

}
