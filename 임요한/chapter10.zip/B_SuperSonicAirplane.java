package chapter10;

public class B_SuperSonicAirplane extends B_Airplane{
	
	//멤버변수 final : 상수. 변경 못함
	public static final int NOMAL = 1;
	public static final int SUPERSONIC = 2;
	public int flyMode = NOMAL;
	
	@Override
	public void fly() {
		if(flyMode == SUPERSONIC) {
			System.out.println("초음속 비행기입니다.");
		}else {
			super.fly();
		}
	}
	
	
}
