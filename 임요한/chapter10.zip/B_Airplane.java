package chapter10;

public class B_Airplane {
	
	public final void land() {
		System.out.println("착륙 합니다.");
	}
	public void fly() {
		System.out.println("일반 비행입니다.");
	}
	public void takeOff() {
		System.out.println("이륙 합니다.");
	}
	
}
