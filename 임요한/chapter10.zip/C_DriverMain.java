package chapter10;

public class C_DriverMain {

	public static void main(String[] args) {

		C_Driver driver = new C_Driver();
		
		C_Taxi taxi = new C_Taxi();
		driver.drive(taxi); // 객체 초기화 후 매개변수로 전달하는 방법
		
		driver.drive(new C_Bus()); // 매개변수에 넣을때 초기화하는 방법
		
	}

}
