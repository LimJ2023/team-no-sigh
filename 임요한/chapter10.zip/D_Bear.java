package chapter10;

public class D_Bear extends D_Animal{
	String woong = "웅담";
	
}
