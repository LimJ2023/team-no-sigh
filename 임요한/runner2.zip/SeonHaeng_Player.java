package runner2;

public class SeonHaeng_Player extends Player{

    public SeonHaeng_Player() {
        super();
        bonusSpeed = 10;
        runType = "선행";
    }

    @Override
    public void jump(int jumpDistance) {
        System.out.print(playerJump);
        if(bonusSpeed > 0) {
            jumpDistance++;
            bonusSpeed--;
        }
        for (int i = 0; i < jumpDistance; i++) {
            System.out.print("=");
            playerJump.append(" ");
        }
        System.out.print(playerNumber + "\uD83C\uDFC3");
    }
}
