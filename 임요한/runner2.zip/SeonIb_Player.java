package runner2;

public class SeonIb_Player extends Player{

    public SeonIb_Player() {
        super();
        bonusSpeed = 5;
        runType = "선입";
    }

    @Override
    public void jump(int jumpDistance) {
        System.out.print(playerJump);
        if(bonusSpeed > 0) {
            jumpDistance += 2;
            bonusSpeed--;
        }

        for (int i = 0; i < jumpDistance; i++) {
            System.out.print("=");
            playerJump.append(" ");

        }
        System.out.print(playerNumber + "\uD83C\uDFC3");
    }
}
