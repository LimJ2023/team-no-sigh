package kindergarden;

import java.util.Scanner;

public class RegistChild{
	ChildData[] cData; //등록정보
	
	public RegistChild(ChildData[] cData) {
		this.cData = cData;
	}

	public void init() {
		Scanner scan = new Scanner(System.in);
		
		for(int i=0; i<cData.length; i++) {
			System.out.print("등록할 유치원생의 이름을 입력하세요 : ");
			String cName = scan.nextLine();
			
			System.out.print("유치원생의 나이를 입력하세요 : ");
			int cAge = scan.nextInt();
			scan.nextLine();
			
			cData[i] = new ChildData(cName, cAge);
		}
	}
	
	public void childData() {
		for(int i=0; i<cData.length; i++) {
			System.out.println("이름 : " + cData[i].name);
			System.out.println("나이 : " + cData[i].age);
			System.out.println("----------------------------");
		}
		
	}
}
