package kindergarden;

public class ChildData {	//예약정보 클래스
	String name;	//유치원생 이름
	int age;
	
	
	public ChildData(String name,  int age) {
		this.name = name;
		this.age = age;
	}
	
	
}
