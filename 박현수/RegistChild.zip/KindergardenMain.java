package kindergarden;

//import java.util.Scanner;

public class KindergardenMain {

	public static void main(String[] args) {
		
		/*Scanner scan = new Scanner(System.in);
		int i = scan.nextInt();*/
		
		ChildData[] datas = new ChildData[3];
		RegistChild test1 = new RegistChild(datas);
		
		
		test1.init();
		
		
		test1.childData();
		
		
		
	}

}
/*1.회원 가입
1-1 학부모 등록 (이름,번호,지역)
1-2 아이 등록 (이름,나이, 등록여부)
1-3 로그인

2. 회원 정보 출력
2-1 학부모 정보 출력(번호,지역)
2-2 아이 정보 출력(유치원 등록 여부필요)

3. 회원 정보 수정
3-1 전화번호 수정
3-2 지역 수정

4. 등록 기능
4-1 유치원 예약

5. 구매 기능
5-1 원복 구매
5-2 준비물 구매

6. 메인 화면 <- 프론트단
6-1 홈화면
6-2 상세페이지
6-3 마이페이지*/