package kindergarden;

import java.util.Scanner;

public class Store extends Membership{
	ReserData[] reser; //예약정보
	
	long totalSale; //총 매출
	
	
	
	public Store(ReserData[] reser) {
		super();	//확정시 상위 클래스의 정보
		this.reser = reser;
	}



	public void init() {
		Scanner scan = new Scanner(System.in);
		
		for(int i=0; i<reser.length; i++) {
			System.out.print("등록할 유치원생의 이름을 입력하세요 : ");
			String cName = scan.nextLine();
			System.out.print("유치원생이 등록할 과정을 적으세요 : ");
			String cPlan = scan.nextLine();
			reser[i] = new ReserData(cName, cPlan);
		}
	}
	
	public void childData() {
		for(int i=0; i<reser.length; i++) {
			System.out.println("이름 : " + reser[i].name);
			System.out.println("교육 : " + reser[i].plan);
		}
		
	}
}
