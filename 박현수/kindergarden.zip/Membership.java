package kindergarden;

public class Membership {

	private String name;	//이름 필드
	private int age;		//나이 필드
	private String member;	//무엇을 위한 멤버? 필드
	
	public void signUp() {
		
	}
	
}
/*회원 관리 <---필수
1.가입
2.회원정보

주문, 결제 <--- 필수
1.유치원 예약, 원복 등 추가 구매 기능
2.결제<-- 등원 등록, 입학금 등..

정보 출력 <--- 필수
1.메인 화면
2.시작, 종료

유치원(한샘 유치원)
1. 활동 기록 페이지 (수정 가능!)
2. 학원 소개 페이지
3. 활동 소개 페이지
4. 갤러리
5. 게시판
6. 공지사항
7. 오시는길
8. 방과후 활동 선택 기능*/