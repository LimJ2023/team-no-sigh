package kindergarden;

public class KindergardenMain {

	public static void main(String[] args) {
		ReserData[] datas = new ReserData[3];
		Store test1 = new Store(datas);
		test1.init();
		
		test1.childData();
		
	}

}
