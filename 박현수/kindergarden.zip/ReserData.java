package kindergarden;

public class ReserData {	//예약정보 클래스
	String name;	//유치원생 이름
	String plan;	//유치원생 교육 플랜?
	
	public ReserData(String name, String plan) {
		this.name = name;
		this.plan = plan;
	}
	
	
}
