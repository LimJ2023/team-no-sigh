package kindergarden;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class RegistChild{
	
	Scanner scan = new Scanner(System.in);
	private ArrayList<ChildData> arrayList;
	
	public RegistChild() {
		arrayList = new ArrayList<ChildData>();	//ChildData 클래스로 arrayList 사용
	}

	public void init() {	//유치원생 등록
		
		System.out.print("등록할 유치원생의 이름을 입력하세요 : ");
		String cName = scan.nextLine();
			
		System.out.print("유치원생의 나이를 입력하세요 : ");
		int cAge = scan.nextInt();
		scan.nextLine();
			
		ChildData cd = new ChildData(cName, cAge);	//ChildData 클래스 생성자에 값 전달
			
		arrayList.add(cd);	//값 등록
	}
	
	public void childData() {
		for(int i=0; i<arrayList.size(); i++) {		//arrayList의 길이 만큼
			System.out.println(arrayList.get(i));	//해당 값 출력
			System.out.println("----------------------------");
		}
		
	}

}
