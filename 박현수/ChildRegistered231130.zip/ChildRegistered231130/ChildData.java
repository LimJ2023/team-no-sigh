package kindergarden;

public class ChildData {
	String name;	//유치원생 이름
	int age;	//유치원생 나이
	
	public ChildData(String name,  int age) {
		this.name = name;		
		this.age = age;
	}

	public String getName() {	//각 getter, setter
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {	//값 출력
		return "이름 : " + name + "\n나이 : " + age;
	}
	
	
	
	
}
