package kindergarden;

import java.util.Scanner;

public class KindergardenMain {

	public static void main(String[] args) {
		
		boolean CSystem = true;	//시스템 가동용 CSystem = ChildSystem
		
		Scanner scan = new Scanner(System.in);
		
		RegistChild test1 = new RegistChild();	//RegistChild의 메소드 호출
		
		
		while(CSystem) {
			
			System.out.println("항목을 선택해 주세요.");
			System.out.println("1.유치원생 등록");
			System.out.println("2.유치원생 확인");
			System.out.println("3.종료");
			
			int menuSelect = scan.nextInt();
			
			switch(menuSelect){
				case 1:
					test1.init();		//유치원생 등록
					System.out.println("유치원생이 등록되었습니다.");
					break;
				case 2:
					System.out.println("등록된 유치원생 정보");
					System.out.println("----------------------------");
					test1.childData();	//등록원 확인
					break;
				case 3:
					System.out.println("시스템을 종료합니다.");
					CSystem = false;
					break;
				default:
					System.out.println("잘못 선택되었습니다.");
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
/*1.회원 가입
1-1 학부모 등록 (이름,번호,지역)
1-2 아이 등록 (이름,나이, 등록여부)
1-3 로그인

2. 회원 정보 출력
2-1 학부모 정보 출력(번호,지역)
2-2 아이 정보 출력(유치원 등록 여부필요)

3. 회원 정보 수정
3-1 전화번호 수정
3-2 지역 수정

4. 등록 기능
4-1 유치원 예약

5. 구매 기능
5-1 원복 구매
5-2 준비물 구매

6. 메인 화면 <- 프론트단
6-1 홈화면
6-2 상세페이지
6-3 마이페이지*/