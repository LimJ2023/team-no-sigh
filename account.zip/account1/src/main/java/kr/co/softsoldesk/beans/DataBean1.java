package kr.co.softsoldesk.beans;

import javax.validation.constraints.Email;
import javax.validation.constraints.Negative;
import javax.validation.constraints.NegativeOrZero;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;

public class DataBean1 {
   //공백을 인정함
   @NotEmpty
   private String data1;
   
   
   public DataBean1() {
      this.data1 = "abcd";
      
   }

   public String getData1() {
      return data1;
   }

   public void setData1(String data1) {
      this.data1 = data1;
   }

   
   
   
   
}